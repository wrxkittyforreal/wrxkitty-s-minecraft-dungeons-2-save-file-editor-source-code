param([string]$OutputName = "DungeonsIISaveEditor.exe")
$ErrorActionPreference = 'Stop'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$arguments = @('/nologo', '/target:winexe', ('/out:"{0}\{1}"' -f $PSScriptRoot,$OutputName), '/reference:System.Windows.Forms.dll', '/reference:System.Drawing.dll', '/reference:System.Web.Extensions.dll', '/reference:System.IO.Compression.dll')
foreach ($source in @('SaveFormat.cs','Editor.cs','CharacterProgress.cs','QuestProgress.cs','ProgressPages.cs','FastTravel.cs','ModsPage.cs','ItemPicker.cs','EquipmentCatalog.cs','EffectCatalog.cs','EffectPicker.cs','EffectArt.cs','GameSaveInstaller.cs','SaveVerification.cs','Tests.cs')) { $arguments += ('"{0}\{1}"' -f $PSScriptRoot,$source) }
foreach ($icon in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'Icons') -Filter '*.png' -File) { $arguments += ('/resource:"{0}",ItemIcons.{1}' -f $icon.FullName,$icon.Name) }
foreach ($art in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'Backgrounds') -Filter '*.jpg' -File | Where-Object { $_.Name -ne 'contact.jpg' }) { $arguments += ('/resource:"{0}",EditorBackgrounds.{1}' -f $art.FullName,$art.Name) }
$arguments += ('/resource:"{0}\EquipmentCatalog.json",EquipmentCatalog.json' -f $PSScriptRoot)
$arguments += ('/resource:"{0}\EffectCatalog.json",EffectCatalog.json' -f $PSScriptRoot)
$arguments += ('/resource:"{0}\AchievementCatalog.json",AchievementCatalog.json' -f $PSScriptRoot)
$arguments += ('/resource:"{0}\QuestCatalog.json",QuestCatalog.json' -f $PSScriptRoot)
$arguments += ('/resource:"{0}\VillagerCatalog.json",VillagerCatalog.json' -f $PSScriptRoot)
$arguments += ('/resource:"{0}\FastTravelCatalog.json",FastTravelCatalog.json' -f $PSScriptRoot)
$responseFile = Join-Path $PSScriptRoot '.build.rsp'
try {
    [IO.File]::WriteAllLines($responseFile,$arguments)
    & $compiler ("@" + $responseFile)
    if ($LASTEXITCODE -ne 0) { throw 'Build failed.' }
} finally { if (Test-Path -LiteralPath $responseFile) { Remove-Item -LiteralPath $responseFile } }

