using System;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;

public static class EffectArt {
 static readonly Dictionary<string,Image> cache=new Dictionary<string,Image>();
 public static Image Get(EffectDefinition definition){if(definition==null||string.IsNullOrEmpty(definition.Icon))return null;Image image;if(cache.TryGetValue(definition.Icon,out image))return image;using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("ItemIcons."+definition.Icon)){if(stream==null)return null;using(var source=Image.FromStream(stream))image=new Bitmap(source);}cache[definition.Icon]=image;return image;}
 public static void DrawRow(ListBox list,DrawItemEventArgs e){if(e.Index<0)return;object item=list.Items[e.Index];var definition=item as EffectDefinition;var saved=item as EffectChoice;if(saved!=null)definition=EffectCatalog.Find(saved.Effect["GeneratorData"]["GeneratorParentTemplate"].Text,saved.Batch["TypeTag"].Text);string name=definition!=null?definition.Name:saved!=null?SaveDocument.Name(saved.Effect["TypeTag"].Text):item.ToString();string detail=definition!=null?definition.ApplicabilityLabel+" · Tier "+definition.Tier:saved!=null?saved.Label+" · compatibility unknown":"Type unknown";bool selected=(e.State&DrawItemState.Selected)!=0;if(selected)using(var brush=new SolidBrush(Color.FromArgb(130,64,190,210)))e.Graphics.FillRectangle(brush,e.Bounds.X,e.Bounds.Y,3,e.Bounds.Height);
  int available=Math.Max(1,e.Bounds.Width-54);int width=Math.Min(available,TextRenderer.MeasureText(e.Graphics,name,list.Font,new Size(available,25),TextFormatFlags.SingleLine|TextFormatFlags.NoPadding).Width);var title=new Rectangle(e.Bounds.X+8,e.Bounds.Y+3,width,25);TextRenderer.DrawText(e.Graphics,name,list.Font,title,Color.White,TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.NoPadding|TextFormatFlags.VerticalCenter);Image icon=Get(definition);if(icon!=null){float scale=list is InventoryListBox?((InventoryListBox)list).HoverScale(e.Index):1f;int iconSize=(int)Math.Round(28*scale);e.Graphics.InterpolationMode=System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;e.Graphics.DrawImage(icon,new Rectangle(title.Right+8,e.Bounds.Y+1+(28-iconSize)/2,iconSize,iconSize));}using(var font=new Font(list.Font.FontFamily,8))TextRenderer.DrawText(e.Graphics,detail,font,new Rectangle(e.Bounds.X+8,e.Bounds.Y+29,e.Bounds.Width-16,20),Color.FromArgb(167,185,204),TextFormatFlags.SingleLine|TextFormatFlags.EndEllipsis|TextFormatFlags.VerticalCenter);e.DrawFocusRectangle();
 }
}
