using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public sealed class QuestDefinition { public string Id; public string Name; public string Category; public int Order; public string[] Tasks; public string[] Prerequisites; public bool TownUnlock; }
public sealed class QuestEdit { public string QuestId; public string State; }
public sealed class VillagerDefinition { public string Id; public string Name; public string Tag; public string QuestId; public string QuestState; public bool UseQuestState; public string TaskId; public string TaskState; }
public sealed class VillagerEdit { public VillagerDefinition Definition; public bool Unlocked; }
public sealed class QuestChoice {
 public QuestDefinition Definition; public J Data; public string State {get{return Data==null?"Not tracked":Data["State"].Text;}}
 public string Id {get{return Definition.Id;}} public string Name {get{return Definition.Name;}} public int Order {get{return Definition.Order;}}
 public override string ToString(){return Definition.Name+"   ·   "+(Definition.Category=="Main"?"MAIN":"SIDE")+"   ·   "+State;}
}
public sealed class VillagerChoice {
 public VillagerDefinition Definition; public bool Unlocked;
 public override string ToString(){return Definition.Name;}
}
public static class ProgressionCatalog {
 static List<T> Read<T>(string resource){using(Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream(resource)){if(stream==null)throw new InvalidDataException("Missing game progression catalog: "+resource);using(var reader=new StreamReader(stream)){return new JavaScriptSerializer().Deserialize<List<T>>(reader.ReadToEnd());}}}
 public static readonly List<QuestDefinition> Quests=Read<QuestDefinition>("QuestCatalog.json");
 public static readonly List<VillagerDefinition> Villagers=Read<VillagerDefinition>("VillagerCatalog.json");
 static ProgressionCatalog(){if(Quests.Count!=44||Quests.Select(x=>x.Id).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=Quests.Count||Quests.Any(x=>x.Tasks==null||x.Tasks.Length==0))throw new InvalidDataException("The game quest catalog is incomplete.");if(Villagers.Count<10||Villagers.Any(x=>string.IsNullOrEmpty(x.QuestId)))throw new InvalidDataException("The villager unlock catalog is incomplete.");}
}
public static class SaveQuestProgress {
 static J SaveQuest(SaveDocument document){J character=document.Root["CharacterSaveV1"];if(!character.Has("quest"))throw new FormatException("This save does not contain quest progress.");J quests=character["quest"];if(!quests.Has("Quests")||quests["Quests"].Kind!='a')throw new FormatException("This save does not contain quest progress.");return quests;}
 static J Find(SaveDocument document,string id){return SaveQuest(document)["Quests"].Values.FirstOrDefault(q=>q["QuestName"].Text.Equals(id,StringComparison.OrdinalIgnoreCase));}
 public static List<QuestChoice> Quests(SaveDocument document,string filter="All"){var saved=SaveQuest(document)["Quests"].Values.ToDictionary(q=>q["QuestName"].Text,StringComparer.OrdinalIgnoreCase);return ProgressionCatalog.Quests.Where(x=>filter=="All"||x.Category.Equals(filter,StringComparison.OrdinalIgnoreCase)).OrderBy(x=>x.Order).Select(definition=>{J data;saved.TryGetValue(definition.Id,out data);return new QuestChoice(){Definition=definition,Data=data};}).ToList();}
 static QuestDefinition Definition(string id){return ProgressionCatalog.Quests.FirstOrDefault(x=>x.Id.Equals(id,StringComparison.OrdinalIgnoreCase));}
 static J CreateQuest(QuestDefinition definition){var row=new Dictionary<string,object>();row["QuestName"]=definition.Id;row["State"]="Unavailable";row["TaskData"]=definition.Tasks.Select(task=>new Dictionary<string,object>{{"TaskName",task},{"State","NotSet"},{"PartialProgress",0}}).ToArray();return J.Parse(new JavaScriptSerializer().Serialize(row));}
 static J EnsureQuest(SaveDocument document,string id){J found=Find(document,id);if(found!=null)return found;QuestDefinition definition=Definition(id);if(definition==null)throw new FormatException("The game quest catalog does not include "+id+".");found=CreateQuest(definition);SaveQuest(document)["Quests"].Add(found);return found;}
 static J EnsureTask(J quest,string taskId){J tasks=quest["TaskData"];J task=tasks.Values.FirstOrDefault(x=>x["TaskName"].Text.Equals(taskId,StringComparison.OrdinalIgnoreCase));if(task!=null)return task;task=J.Parse(new JavaScriptSerializer().Serialize(new Dictionary<string,object>{{"TaskName",taskId},{"State","NotSet"},{"PartialProgress",0}}));tasks.Add(task);return task;}
 public static bool SetQuestState(SaveDocument document,string questId,string state){if(!new[]{"Unavailable","Available","Active","Completed"}.Contains(state))throw new ArgumentException("Unknown quest state.");J quest=EnsureQuest(document,questId);bool changed=quest["State"].Text!=state;if(changed)quest["State"]=J.Str(state);if(state=="Completed")foreach(J task in quest["TaskData"].Values)if(task["State"].Text!="Completed"){task["State"]=J.Str("Completed");changed=true;}if(state=="Active"){J save=SaveQuest(document);if(save["FocusedQuestId"].Text!=questId){save["FocusedQuestId"]=J.Str(questId);changed=true;}}return changed;}
 public static bool IsVillagerUnlocked(SaveDocument document,VillagerDefinition definition){J quest=Find(document,definition.QuestId);if(quest==null)return false;if(definition.UseQuestState&&quest["State"].Text!=definition.QuestState)return false;if(!string.IsNullOrEmpty(definition.TaskId)){J task=quest["TaskData"].Values.FirstOrDefault(x=>x["TaskName"].Text.Equals(definition.TaskId,StringComparison.OrdinalIgnoreCase));if(task==null||task["State"].Text!=definition.TaskState)return false;}return true;}
 public static List<VillagerChoice> Villagers(SaveDocument document){return ProgressionCatalog.Villagers.Select(x=>new VillagerChoice(){Definition=x,Unlocked=IsVillagerUnlocked(document,x)}).ToList();}
 public static bool SetVillagerUnlocked(SaveDocument document,VillagerDefinition definition,bool unlocked){J quest=EnsureQuest(document,definition.QuestId);bool changed=false;if(definition.UseQuestState){string desired=unlocked?definition.QuestState:"Available";if(quest["State"].Text!=desired){quest["State"]=J.Str(desired);changed=true;}if(unlocked&&desired=="Completed")foreach(J task in quest["TaskData"].Values)if(task["State"].Text!="Completed"){task["State"]=J.Str("Completed");changed=true;}}if(!string.IsNullOrEmpty(definition.TaskId)){J task=EnsureTask(quest,definition.TaskId);string desired=unlocked?definition.TaskState:"NotSet";if(task["State"].Text!=desired){task["State"]=J.Str(desired);changed=true;}}return changed;}
}
public sealed class QuestProgressDialog : Form {
 readonly Color bg=Color.FromArgb(18,23,30),surface=Color.FromArgb(29,37,48),muted=Color.FromArgb(167,185,204),mint=Color.FromArgb(111,230,190),blue=Color.FromArgb(57,119,190);
 readonly SaveDocument document;readonly ListBox quests=new ListBox();readonly ComboBox state=new ComboBox();readonly Dictionary<string,string> edits=new Dictionary<string,string>(StringComparer.OrdinalIgnoreCase);readonly Dictionary<string,Button> filters=new Dictionary<string,Button>();readonly string[] filterNames={"All","Main","Side"};string filter="All";
 public IEnumerable<QuestEdit> Edits {get{return edits.Select(x=>new QuestEdit(){QuestId=x.Key,State=x.Value});}}
 Label Txt(string text,int x,int y,int w,int h,Control parent,int size=10,Color? color=null){var l=new Label(){Text=text,Location=new Point(x,y),Size=new Size(w,h),ForeColor=color??muted,Font=new Font("Segoe UI",size)};parent.Controls.Add(l);return l;}
 Button Btn(string text,int x,int y,int w,Control parent,EventHandler click){var b=new Button(){Text=text,Location=new Point(x,y),Size=new Size(w,36),BackColor=surface,ForeColor=Color.White,FlatStyle=FlatStyle.Flat};b.FlatAppearance.BorderColor=Color.FromArgb(62,79,95);b.Click+=click;parent.Controls.Add(b);return b;}
 public QuestProgressDialog(SaveDocument doc){document=doc;Text="Quest progress";ClientSize=new Size(760,690);MinimumSize=new Size(776,729);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;BackColor=bg;ForeColor=Color.White;Font=new Font("Segoe UI",10);
  Txt("QUEST PROGRESS",24,18,700,32,this,18,Color.White);Txt("All 44 quests from the game catalog are listed in campaign order. Choose your current quest or set a saved quest's progress.",24,54,710,38,this,9);
  Txt("FILTER QUESTS",24,101,250,24,this,11,mint);int fx=24;foreach(string name in filterNames){string captured=name;int width=name=="All"?86:112;Button button=Btn("["+name.ToLowerInvariant()+"]",fx,128,width,this,(s,e)=>SetFilter(captured));filters.Add(name,button);fx+=width+10;}
  quests.Location=new Point(24,176);quests.Size=new Size(712,328);quests.BorderStyle=BorderStyle.None;quests.BackColor=surface;quests.ForeColor=Color.White;quests.Font=Font;quests.IntegralHeight=false;quests.SelectedIndexChanged+=(s,e)=>SelectQuest();Controls.Add(quests);
  Txt("Selected quest status",24,515,220,24,this,9);state.DropDownStyle=ComboBoxStyle.DropDownList;state.Items.AddRange(new object[]{"Not tracked","Unavailable","Available","Active","Completed"});state.Location=new Point(24,542);state.Size=new Size(220,32);state.BackColor=surface;state.ForeColor=Color.White;state.SelectedIndexChanged+=(s,e)=>{var q=quests.SelectedItem as QuestChoice;if(q==null||state.SelectedItem==null)return;string selected=(string)state.SelectedItem;if(selected=="Not tracked")edits.Remove(q.Id);else edits[q.Id]=selected;RefreshQuests(q.Id);};Controls.Add(state);
  Btn("Set as current quest",264,539,190,this,(s,e)=>{var q=quests.SelectedItem as QuestChoice;if(q==null)return;edits[q.Id]="Active";RefreshQuests(q.Id);});
  Txt("A quest marked Active becomes the character's focused quest. Choosing Available or Completed also adds the quest to the save when needed.",480,521,256,76,this,9);
  Txt("Export this character .sav, then load it in the game to refresh its progress.",24,619,710,24,this,9);Btn("Save changes",516,644,104,this,(s,e)=>{DialogResult=DialogResult.OK;Close();});Btn("Cancel",632,644,104,this,(s,e)=>{DialogResult=DialogResult.Cancel;Close();});SetFilter("All");
 }
 void SetFilter(string value){filter=value;foreach(var pair in filters)pair.Value.BackColor=pair.Key==filter?blue:surface;RefreshQuests(null);}
 void RefreshQuests(string keepId){string selectedId=keepId??(quests.SelectedItem as QuestChoice==null?null:((QuestChoice)quests.SelectedItem).Id);quests.BeginUpdate();quests.Items.Clear();foreach(var q in SaveQuestProgress.Quests(document,filter)){if(edits.ContainsKey(q.Id)){var pending=edits[q.Id];if(q.Data==null){q.Data=J.Parse("{\"QuestName\":"+new JavaScriptSerializer().Serialize(q.Id)+",\"State\":"+new JavaScriptSerializer().Serialize(pending)+",\"TaskData\":[]}");}else if(q.Data["State"].Text!=pending){q.Data=q.Data.Copy();q.Data["State"]=J.Str(pending);}}quests.Items.Add(q);if(q.Id==selectedId)quests.SelectedItem=q;}quests.EndUpdate();if(quests.SelectedIndex<0&&quests.Items.Count>0)quests.SelectedIndex=0;if(quests.SelectedItem!=null)SelectQuest();}
 void SelectQuest(){var q=quests.SelectedItem as QuestChoice;if(q==null)return;string value;if(!edits.TryGetValue(q.Id,out value))value=q.State;state.SelectedItem=value;}
}
public sealed class VillagerProgressDialog : Form {
 readonly Color bg=Color.FromArgb(18,23,30),surface=Color.FromArgb(29,37,48),muted=Color.FromArgb(167,185,204),mint=Color.FromArgb(111,230,190);
 readonly CheckedListBox villagers=new CheckedListBox();readonly List<VillagerChoice> choices;readonly List<VillagerEdit> edits=new List<VillagerEdit>();
 public IEnumerable<VillagerEdit> Edits {get{return edits;}}
 Label Txt(string text,int x,int y,int w,int h,Control parent,int size=10,Color? color=null){var l=new Label(){Text=text,Location=new Point(x,y),Size=new Size(w,h),ForeColor=color??muted,Font=new Font("Segoe UI",size)};parent.Controls.Add(l);return l;}
 Button Btn(string text,int x,int y,int w,Control parent,EventHandler click){var b=new Button(){Text=text,Location=new Point(x,y),Size=new Size(w,36),BackColor=surface,ForeColor=Color.White,FlatStyle=FlatStyle.Flat};b.FlatAppearance.BorderColor=Color.FromArgb(62,79,95);b.Click+=click;parent.Controls.Add(b);return b;}
 public VillagerProgressDialog(SaveDocument doc){Text="Villagers";ClientSize=new Size(760,690);MinimumSize=new Size(776,729);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;BackColor=bg;ForeColor=Color.White;Font=new Font("Segoe UI",10);
  Txt("VILLAGERS & MERCHANTS",24,18,700,32,this,18,Color.White);Txt("Select the characters and merchants you want available to talk to. Their unlock conditions are written to the matching quest progress in this save.",24,54,710,42,this,9);
  villagers.Location=new Point(24,106);villagers.Size=new Size(712,448);villagers.BorderStyle=BorderStyle.None;villagers.BackColor=surface;villagers.ForeColor=Color.White;villagers.Font=Font;villagers.CheckOnClick=true;villagers.IntegralHeight=false;choices=SaveQuestProgress.Villagers(doc);foreach(var choice in choices)villagers.Items.Add(choice,choice.Unlocked);villagers.ItemCheck+=(s,e)=>{var choice=choices[e.Index];var edit=edits.FirstOrDefault(x=>x.Definition.Id==choice.Definition.Id);if(edit==null)edits.Add(new VillagerEdit(){Definition=choice.Definition,Unlocked=e.NewValue==CheckState.Checked});else edit.Unlocked=e.NewValue==CheckState.Checked;};Controls.Add(villagers);
  Txt("Unlocks use the game's quest and objective flags. Unlocking a character may add a missing quest record; locking one can reset its linked quest state.",24,566,710,45,this,9);Txt("Export this character .sav, then load it in the game to refresh its villagers.",24,619,710,24,this,9);Btn("Save changes",516,644,104,this,(s,e)=>{DialogResult=DialogResult.OK;Close();});Btn("Cancel",632,644,104,this,(s,e)=>{DialogResult=DialogResult.Cancel;Close();});
 }
}
