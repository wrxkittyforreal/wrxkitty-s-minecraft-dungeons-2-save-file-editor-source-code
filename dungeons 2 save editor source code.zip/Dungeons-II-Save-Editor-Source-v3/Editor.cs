using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Windows.Forms;

public sealed class EntryChoice {public J Entry; public string Label; public override string ToString(){return Label;}}
public sealed class EffectChoice {public J Batch,Effect; public string Label; public override string ToString(){return Label;}}
public sealed class SaveEditor : Form
{
	private Color bg = Color.FromArgb(24, 43, 57);

	private Color surface = Color.FromArgb(35, 42, 50);

	private Color muted = Color.FromArgb(178, 196, 207);

	private Color mint = Color.FromArgb(71, 166, 239);

	private Color topBar = Color.FromArgb(21, 25, 32);

	private Color orange = Color.FromArgb(71, 166, 239);

	private Color panelHeader = Color.FromArgb(64, 119, 154);

	private static readonly Dictionary<string, Image> emptySlotIcons = new Dictionary<string, Image>(StringComparer.OrdinalIgnoreCase);

	private static readonly PropertyInfo DoubleBufferedProperty = typeof(Control).GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);

	private readonly HashSet<Control> bufferedControls = new HashSet<Control>();

	private SaveDocument doc;

	private J selected;

	private bool loading;

	private bool pageTransition;

	private bool exported = true;

	private string inventoryFilter = "All";

	private Button inventoryFilterButton;

	private ContextMenuStrip inventoryFilterMenu;

	private List<J> templates = new List<J>();

	private List<EffectChoice> effectTemplates = new List<EffectChoice>();

	private InventoryListBox inventory = new InventoryListBox();

	private InventoryListBox effects = new InventoryListBox();

	private ComboBox rarity = new ComboBox();

	private NumericUpDown power = new NumericUpDown();

	private Label fileLabel;

	private Label summary;

	private Label title;

	private Label tag;

	private Label slot;

	private Label status;

	private FlowLayoutPanel summaryDetails;

	private Panel details = new Panel();

	private CheckBox showMerchant = new CheckBox();

	private Button newButton;

	private Button duplicateButton;

	private Button deleteButton;

	private Button addEffectButton;

	private Button editEffectButton;

	private Button removeEffectButton;

	private Button progressButton;

	private Button questsButton;

	private Button villagersButton;

	private Button locationsButton;

	private Button modsButton;

	private Button menuButton;

	private Button inventoryButton;

	private Label levelHeader;

	private Label levelValue;

	private Label equipmentHeader;

	private Label inventoryHeader;

	private Label detailsHeader;

	private Label catalogNote;

	private Panel equipmentPanel;

	private Panel pageHost;

	private Panel inventoryFrame;

	private ToolTip equipmentTip;

	private readonly List<Button> equippedFilterButtons = new List<Button>();

	private readonly List<Control> inventoryViewControls = new List<Control>();

	private ToolStripMenuItem exportMenuItem;

	private ToolStripMenuItem importMenuItem;

	private Button settingsButton;

	private string backgroundPicturePath = "";

	private Image backgroundPicture;

	private Bitmap backgroundCache;

	private Timer backgroundResizeTimer;

	private int textScale = 100;

	private int interfaceScale = 100;

	private int backgroundDim = 42;

	private static readonly string[][] GameArtwork = new string[][]
	{
		new string[] { "Jungle", "T_UI_Loading_Background_1.jpg" },
		new string[] { "Island", "T_UI_Loading_Background_2.jpg" },
		new string[] { "Snowy Coast", "T_UI_Loading_Background_3.jpg" },
		new string[] { "Echoing Void", "T_UI_Loading_Background_4.jpg" },
		new string[] { "Launch Key Art 1", "Official-Key-Art-1.jpg" },
		new string[] { "Launch Key Art 2", "Official-Key-Art-2.jpg" },
		new string[] { "Launch Key Art 3", "Official-Key-Art-3.jpg" },
		new string[] { "Launch Key Art 4", "Official-Key-Art-4.jpg" },
		new string[] { "Xbox Key Art", "Official-Xbox-Key-Art.jpg" },
		new string[] { "Sift Heroes Key Art", "Official-Sift-Heroes.jpg" },
		new string[] { "Prime Enchanter", "Official-Prime-Enchanter.jpg" },
		new string[] { "Grand Illusioner", "Official-Grand-Illusioner.jpg" },
		new string[] { "Supreme Evoker", "Official-Supreme-Evoker.jpg" },
		new string[] { "Soul-Corrupted Creeper", "Official-Corrupted-Creeper.jpg" },
		new string[] { "Singer Concept Art", "Official-Sift-Singer-Concept.jpg" },
		new string[] { "Gameplay 1", "Official-Screenshot-1.jpg" },
		new string[] { "Gameplay 2", "Official-Screenshot-2.jpg" },
		new string[] { "Gameplay 3", "Official-Screenshot-3.jpg" },
		new string[] { "Gameplay 4", "Official-Screenshot-4.jpg" },
		new string[] { "Gameplay 5", "Official-Screenshot-5.jpg" },
		new string[] { "Gameplay 6", "Official-Screenshot-6.jpg" },
		new string[] { "Gameplay 7", "Official-Screenshot-7.jpg" },
		new string[] { "Gameplay 8", "Official-Screenshot-8.jpg" },
		new string[] { "Gameplay 9", "Official-Screenshot-9.jpg" }
	};

	private bool applyingTheme;

	private ContextMenuStrip appMenu;

	private Panel topBarPanel;

	private Panel navUnderline;

	private int CurrentPalette;

	private string ThemeFolder
	{
		get
		{
			return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UI Config");
		}
	}

	private string ThemeFile
	{
		get
		{
			return Path.Combine(ThemeFolder, "DungeonsIISaveEditor.UI.txt");
		}
	}

	public SaveEditor()
	{
		Text = "Dungeons II Save Editor";
		base.ClientSize = new Size(1320, 860);
		MinimumSize = new Size(1160, 780);
		base.StartPosition = FormStartPosition.CenterScreen;
		base.Opacity = 1.0;
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
		DoubleBuffered = true;
		UpdateStyles();
		BackColor = bg;
		ForeColor = Color.White;
		Font = new Font("Segoe UI", 10f);
		LoadThemePreferences();
		backgroundResizeTimer = new Timer();
		backgroundResizeTimer.Interval = 140;
		backgroundResizeTimer.Tick += delegate
		{
			backgroundResizeTimer.Stop();
			RefreshBackgroundCache();
		};
		Build();
		ApplyPalette();
		EnableDoubleBuffering(this);
		base.Paint += DrawInventoryWorkspaceOutline;
		EventHandler value = delegate
		{
			LayoutMain();
		};
		base.Resize += value;
		base.Resize += delegate
		{
			backgroundResizeTimer.Stop();
			backgroundResizeTimer.Start();
		};
		LayoutMain();
		base.FormClosing += delegate(object s, FormClosingEventArgs e)
		{
			if (!ConfirmLeave())
			{
				e.Cancel = true;
			}
			else
			{
				backgroundResizeTimer.Stop();
				backgroundResizeTimer.Dispose();
				if (backgroundCache != null) backgroundCache.Dispose();
				if (backgroundPicture != null) backgroundPicture.Dispose();
			}
		};
	}

	protected override CreateParams CreateParams
	{
		get
		{
			CreateParams parameters = base.CreateParams;
			parameters.ExStyle |= 0x02000000;
			return parameters;
		}
	}

	private Label L(string text, int x, int y, int w, int h, Control parent, int size)
	{
		Label label = new Label();
		label.Text = text;
		label.Location = new Point(x, y);
		label.Size = new Size(w, h);
		label.Font = new Font("Segoe UI", size);
		label.ForeColor = muted;
		Label label2 = label;
		parent.Controls.Add(label2);
		return label2;
	}

	private Button B(string text, int x, int y, int w, Control parent, EventHandler click)
	{
		TintDisabledButton tintDisabledButton = new TintDisabledButton();
		tintDisabledButton.Text = text;
		tintDisabledButton.Location = new Point(x, y);
		tintDisabledButton.Size = new Size(w, 36);
		tintDisabledButton.BackColor = Color.Transparent;
		tintDisabledButton.ForeColor = Color.White;
		tintDisabledButton.FlatStyle = FlatStyle.Flat;
		TintDisabledButton tintDisabledButton2 = tintDisabledButton;
		tintDisabledButton2.FlatAppearance.BorderColor = Color.FromArgb(62, 79, 95);
		tintDisabledButton2.FlatAppearance.MouseOverBackColor = Color.FromArgb(50, 77, 85);
		tintDisabledButton2.Click += click;
		parent.Controls.Add(tintDisabledButton2);
		HoverGrow.Attach(tintDisabledButton2);
		return tintDisabledButton2;
	}

	private void Input(Control c)
	{
		c.BackColor = surface;
		c.ForeColor = Color.White;
		c.Font = Font;
	}

	private void Build()
	{
		topBarPanel = new Panel
		{
			Location = new Point(0, 0),
			Size = new Size(base.ClientSize.Width, 46),
			BackColor = topBar,
			Anchor = (AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right)
		};
		base.Controls.Add(topBarPanel);
		menuButton = B("☰  MENU  ▾", 10, 5, 112, topBarPanel, delegate
		{
			appMenu.Show(menuButton, new Point(0, menuButton.Height));
		});
		menuButton.Size = new Size(112, 36);
		menuButton.FlatAppearance.BorderSize = 0;
		menuButton.BackColor = topBar;
		settingsButton = B("⚙  SETTINGS", 974, 5, 124, topBarPanel, delegate
		{
			OpenThemeSettings();
		});
		settingsButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
		settingsButton.FlatAppearance.BorderSize = 0;
		settingsButton.BackColor = surface;
		appMenu = new ContextMenuStrip
		{
			BackColor = surface,
			ForeColor = Color.White,
			ShowImageMargin = false
		};
		importMenuItem = new ToolStripMenuItem("Import character .sav…");
		importMenuItem.Click += delegate
		{
			Open();
		};
		appMenu.Items.Add(importMenuItem);
		exportMenuItem = new ToolStripMenuItem("Export .sav…");
		exportMenuItem.Click += delegate
		{
			Export();
		};
		appMenu.Items.Add(exportMenuItem);
		appMenu.Items.Add(new ToolStripSeparator());
		appMenu.Items.Add("Learn effects from save…", null, delegate
		{
			Learn();
		});
		appMenu.Items.Add(new ToolStripSeparator());
		appMenu.Items.Add("Help", null, delegate
		{
			Help();
		});
		inventoryButton = Nav("INVENTORY", 132, topBarPanel, delegate
		{
			Navigate(inventoryButton);
			ShowSection("Inventory");
		});
		questsButton = Nav("QUESTS", 232, topBarPanel, delegate
		{
			Navigate(questsButton);
			ShowSection("Quests");
		});
		villagersButton = Nav("MERCHANTS", 316, topBarPanel, delegate
		{
			Navigate(villagersButton);
			ShowSection("Merchants");
		});
		progressButton = Nav("ACHIEVEMENTS", 424, topBarPanel, delegate
		{
			Navigate(progressButton);
			ShowSection("Achievements");
		});
		locationsButton = Nav("STATION LOCATIONS", 570, topBarPanel, delegate
		{
			Navigate(locationsButton);
			ShowSection("FastTravel");
		});
		modsButton = Nav("MODS", 730, topBarPanel, delegate
		{
			Navigate(modsButton);
			ShowSection("Mods");
		});
		fileLabel = L("No save loaded", 1126, 10, 180, 26, topBarPanel, 10);
		fileLabel.Anchor = AnchorStyles.Top | AnchorStyles.Right;
		navUnderline = new Panel
		{
			BackColor = orange,
			Location = new Point(132, 43),
			Size = new Size(96, 3)
		};
		topBarPanel.Controls.Add(navUnderline);
		topBarPanel.Resize += delegate
		{
			topBarPanel.Controls.SetChildIndex(navUnderline, topBarPanel.Controls.Count - 1);
		};
		levelHeader = L("LEVEL", 24, 63, 130, 22, this, 9);
		levelHeader.ForeColor = muted;
		levelValue = new HoverTextLabel
		{
			Text = "—",
			Location = new Point(24, 83),
			Size = new Size(120, 48),
			Font = new Font("Segoe UI", 26),
			TextAlign = ContentAlignment.TopLeft
		};
		base.Controls.Add(levelValue);
		levelValue.ForeColor = Color.FromArgb(199, 92, 235);
		levelValue.Cursor = Cursors.Hand;
		levelValue.AccessibleName = "Hero level";
		levelValue.AccessibleDescription = "Click to edit the level";
		levelValue.Click += delegate
		{
			EditLevelValue();
		};
		summary = L("Load a Dungeons II character save to begin.", 24, 134, 850, 26, this, 10);
		summaryDetails = new FlowLayoutPanel
		{
			Location = new Point(24, 134),
			Size = new Size(850, 42),
			FlowDirection = FlowDirection.LeftToRight,
			WrapContents = false,
			BackColor = bg,
			Visible = false,
			Margin = Padding.Empty,
			Padding = Padding.Empty
		};
		base.Controls.Add(summaryDetails);
		summaryDetails.BringToFront();
		equipmentHeader = L("EQUIPMENT", 24, 178, 290, 28, this, 12);
		equipmentHeader.ForeColor = Color.White;
		inventoryHeader = L("INVENTORY", 362, 178, 300, 28, this, 12);
		inventoryHeader.ForeColor = Color.White;
		detailsHeader = L("ITEM DETAILS", 770, 178, 400, 28, this, 12);
		detailsHeader.ForeColor = Color.White;
		equipmentPanel = new Panel
		{
			Location = new Point(24, 211),
			Size = new Size(290, 548),
			BackColor = bg,
			AutoScroll = true,
			Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left)
		};
		base.Controls.Add(equipmentPanel);
		equipmentTip = new ToolTip
		{
			InitialDelay = 350,
			ShowAlways = true
		};
		inventoryFilterButton = B("Filters · All", 362, 211, 145, this, delegate
		{
			inventoryFilterMenu.Show(inventoryFilterButton, new Point(inventoryFilterButton.Width + 8, 0));
		});
		BuildInventoryFilters();
		showMerchant.Text = "Show merchant stock";
		showMerchant.Location = new Point(520, 215);
		showMerchant.Size = new Size(220, 28);
		showMerchant.ForeColor = muted;
		showMerchant.CheckedChanged += delegate
		{
			RefreshInventory(null);
		};
		base.Controls.Add(showMerchant);
		inventoryFrame = new Panel
		{
			Location = new Point(362, 250),
			Size = new Size(380, 508),
			BackColor = Color.Transparent,
			BorderStyle = BorderStyle.None,
			Padding = Padding.Empty,
			Anchor = (AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right)
		};
		base.Controls.Add(inventoryFrame);
		inventory.Dock = DockStyle.Fill;
		inventory.BorderStyle = BorderStyle.None;
		Input(inventory);
		inventory.BackColor = bg;
		inventory.DrawMode = DrawMode.OwnerDrawFixed;
		inventory.ItemHeight = 50;
		inventory.IntegralHeight = false;
		inventory.DrawItem += DrawInventoryRow;
		inventory.SelectedIndexChanged += delegate
		{
			if (!loading)
			{
				SelectEntry();
			}
		};
		inventoryFrame.Controls.Add(inventory);
		newButton = B("+ ADD ITEMS…", 820, 63, 126, this, delegate
		{
			Create();
		});
		newButton.BackColor = surface;
		newButton.ForeColor = Color.White;
		duplicateButton = B("Duplicate", 954, 63, 112, this, delegate
		{
			Duplicate();
		});
		details.Location = new Point(770, 211);
		details.Size = new Size(520, 547);
		details.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
		details.BackColor = surface;
		details.BorderStyle = BorderStyle.None;
		base.Controls.Add(details);
		Panel panel = new Panel();
		panel.Location = new Point(0, 0);
		panel.Size = new Size(520, 34);
		panel.BackColor = panelHeader;
		panel.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
		Panel value = panel;
		details.Controls.Add(value);
		L("·   INVENTORY   ·", 0, 5, 520, 24, value, 10).TextAlign = ContentAlignment.MiddleCenter;
		title = L("Select an item", 18, 48, 475, 38, details, 20);
		title.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
		title.ForeColor = Color.White;
		tag = L("", 18, 89, 475, 27, details, 10);
		tag.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
		slot = L("", 18, 119, 475, 27, details, 10);
		slot.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
		L("Rarity", 18, 151, 240, 24, details, 10);
		rarity.DropDownStyle = ComboBoxStyle.DropDownList;
		rarity.Location = new Point(18, 179);
		rarity.Size = new Size(220, 30);
		Input(rarity);
		rarity.DrawMode = DrawMode.OwnerDrawFixed;
		rarity.DrawItem += delegate(object s, DrawItemEventArgs e)
		{
			using (SolidBrush brush = new SolidBrush(surface))
			{
				e.Graphics.FillRectangle(brush, e.Bounds);
			}
			string text = ((e.Index >= 0) ? rarity.Items[e.Index].ToString() : rarity.Text);
			TextRenderer.DrawText(e.Graphics, text, Font, e.Bounds, Color.White, TextFormatFlags.VerticalCenter);
			e.DrawFocusRectangle();
		};
		details.Controls.Add(rarity);
		L("Item power", 260, 151, 125, 24, details, 10);
		power.Location = new Point(260, 179);
		power.Size = new Size(110, 30);
		power.Minimum = -1m;
		power.Maximum = 1000000m;
		Input(power);
		details.Controls.Add(power);
		deleteButton = B("Delete", 386, 175, 110, details, delegate
		{
			Delete();
		});
		L("ITEM EFFECTS", 18, 224, 400, 26, details, 10);
		effects.Location = new Point(18, 255);
		effects.Size = new Size(478, 155);
		effects.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
		effects.BorderStyle = BorderStyle.None;
		effects.DrawMode = DrawMode.OwnerDrawFixed;
		effects.ItemHeight = 49;
		effects.IntegralHeight = false;
		effects.DrawItem += delegate(object s, DrawItemEventArgs e)
		{
			DrawEffectRow(effects, e);
		};
		Input(effects);
		details.Controls.Add(effects);
		addEffectButton = B("Add effect…", 18, 423, 145, details, delegate
		{
			AddEffect();
		});
		addEffectButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
		editEffectButton = B("Edit selected…", 180, 423, 145, details, delegate
		{
			EditEffect();
		});
		editEffectButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
		removeEffectButton = B("Remove", 341, 423, 155, details, delegate
		{
			RemoveEffect();
		});
		removeEffectButton.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
		deleteButton.Anchor = AnchorStyles.Top | AnchorStyles.Right;
		effects.DoubleClick += delegate
		{
			EditEffect();
		};
		catalogNote = L("Full equipment catalog · New items start without rolled effects. Add effects in the item editor.", 24, 773, 850, 24, this, 9);
		catalogNote.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
		status = L("Game closed · Ready to edit", 24, 817, 1300, 26, this, 10);
		status.BackColor = topBar;
		status.Padding = new Padding(8, 4, 0, 0);
		status.Anchor = AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
		pageHost = new Panel
		{
			BackColor = bg,
			Visible = false
		};
		base.Controls.Add(pageHost);
		inventoryViewControls.AddRange(new Control[15]
		{
			levelHeader, levelValue, summary, summaryDetails, newButton, duplicateButton, equipmentHeader, inventoryHeader,
			detailsHeader, equipmentPanel, inventoryFilterButton, showMerchant, inventoryFrame, details, catalogNote
		});
		rarity.SelectedIndexChanged += delegate
		{
			if (!loading && selected != null && rarity.SelectedItem != null)
			{
				string text = (string)rarity.SelectedItem;
				if (SaveDocument.Data(selected)["RarityTag"].Text != text)
				{
					SaveDocument.Data(selected)["RarityTag"] = J.Str(text);
					Changed();
					RefreshInventory(selected);
				}
			}
		};
		power.ValueChanged += delegate
		{
			if (!loading && selected != null)
			{
				J j = SaveDocument.Data(selected)["GeneratorData"]["PowerGeneratorValues"];
				if (j["ItemPower"].Number != power.Value)
				{
					j["ItemPower"] = J.Num(power.Value);
					Changed();
				}
			}
		};
		RefreshEquippedFilters();
		Enable();
	}

	private void LoadThemePreferences()
	{
		try
		{
			Directory.CreateDirectory(ThemeFolder);
			if (File.Exists(ThemeFile))
			{
				string[] array = File.ReadAllLines(ThemeFile);
				int index = ((array.Length > 0) ? int.Parse(array[0]) : 0);
				SetPalette(index, false);
				if (array.Length > 1)
				{
					textScale = Math.Max(80, Math.Min(130, int.Parse(array[1])));
				}
				if (array.Length > 2)
				{
					interfaceScale = Math.Max(80, Math.Min(110, int.Parse(array[2])));
				}
				if (array.Length > 3)
				{
					backgroundDim = Math.Max(0, Math.Min(80, int.Parse(array[3])));
				}
				if (array.Length > 4 && (array[4].StartsWith("GameArt:", StringComparison.OrdinalIgnoreCase) || File.Exists(array[4])))
				{
					backgroundPicturePath = array[4];
				}
			}
		}
		catch
		{
		}
	}

	private void SaveThemePreferences()
	{
		try
		{
			Directory.CreateDirectory(Path.GetDirectoryName(ThemeFile));
			File.WriteAllLines(ThemeFile, new string[5]
			{
				CurrentPalette.ToString(CultureInfo.InvariantCulture),
				textScale.ToString(CultureInfo.InvariantCulture),
				interfaceScale.ToString(CultureInfo.InvariantCulture),
				backgroundDim.ToString(CultureInfo.InvariantCulture),
				backgroundPicturePath ?? ""
			});
		}
		catch
		{
		}
	}

	private void SetPalette(int index, bool refresh)
	{
		Color[] array = Palette(index);
		CurrentPalette = index;
		bg = array[0];
		surface = array[1];
		muted = array[2];
		mint = array[3];
		topBar = array[4];
		orange = array[5];
		panelHeader = array[6];
		if (refresh && base.IsHandleCreated)
		{
			ApplyPalette();
		}
	}

	private Color[] Palette(int i)
	{
		switch ((i % 8 + 8) % 8)
		{
		case 1:
			return new Color[7]
			{
				Color.FromArgb(23, 51, 43),
				Color.FromArgb(30, 43, 40),
				Color.FromArgb(176, 204, 190),
				Color.FromArgb(73, 202, 137),
				Color.FromArgb(22, 29, 27),
				Color.FromArgb(75, 205, 137),
				Color.FromArgb(53, 119, 91)
			};
		case 2:
			return new Color[7]
			{
				Color.FromArgb(39, 32, 58),
				Color.FromArgb(42, 38, 53),
				Color.FromArgb(197, 185, 214),
				Color.FromArgb(177, 117, 244),
				Color.FromArgb(26, 24, 33),
				Color.FromArgb(177, 117, 244),
				Color.FromArgb(111, 74, 151)
			};
		case 3:
			return new Color[7]
			{
				Color.FromArgb(53, 37, 30),
				Color.FromArgb(48, 41, 38),
				Color.FromArgb(210, 190, 177),
				Color.FromArgb(239, 148, 66),
				Color.FromArgb(31, 27, 25),
				Color.FromArgb(239, 148, 66),
				Color.FromArgb(153, 94, 54)
			};
		case 4:
			return new Color[7]
			{
				Color.FromArgb(52, 32, 38),
				Color.FromArgb(47, 39, 43),
				Color.FromArgb(210, 181, 188),
				Color.FromArgb(224, 100, 120),
				Color.FromArgb(29, 25, 28),
				Color.FromArgb(224, 100, 120),
				Color.FromArgb(140, 73, 86)
			};
		case 5:
			return new Color[7]
			{
				Color.FromArgb(24, 42, 59),
				Color.FromArgb(32, 41, 51),
				Color.FromArgb(178, 198, 216),
				Color.FromArgb(85, 169, 239),
				Color.FromArgb(22, 27, 34),
				Color.FromArgb(85, 169, 239),
				Color.FromArgb(57, 105, 145)
			};
		case 6:
			return new Color[7]
			{
				Color.FromArgb(49, 43, 29),
				Color.FromArgb(46, 42, 36),
				Color.FromArgb(210, 199, 171),
				Color.FromArgb(226, 185, 82),
				Color.FromArgb(30, 28, 24),
				Color.FromArgb(226, 185, 82),
				Color.FromArgb(145, 119, 57)
			};
		case 7:
			return new Color[7]
			{
				Color.FromArgb(31, 34, 39),
				Color.FromArgb(39, 43, 49),
				Color.FromArgb(181, 187, 194),
				Color.FromArgb(135, 153, 171),
				Color.FromArgb(22, 24, 28),
				Color.FromArgb(135, 153, 171),
				Color.FromArgb(78, 86, 96)
			};
		default:
			return new Color[7]
			{
				Color.FromArgb(24, 43, 57),
				Color.FromArgb(35, 42, 50),
				Color.FromArgb(178, 196, 207),
				Color.FromArgb(71, 166, 239),
				Color.FromArgb(21, 25, 32),
				Color.FromArgb(71, 166, 239),
				Color.FromArgb(64, 119, 154)
			};
		}
	}

	private void ApplyPalette()
	{
		if (applyingTheme)
		{
			return;
		}
		applyingTheme = true;
		try
		{
			BackColor = bg;
			ForeColor = Color.White;
			topBarPanel.BackColor = topBar;
			status.BackColor = topBar;
			equipmentPanel.BackColor = Color.Transparent;
			details.BackColor = Color.Transparent;
			inventory.BackColor = bg;
			effects.BackColor = bg;
			summaryDetails.BackColor = Color.Transparent;
			navUnderline.BackColor = orange;
			foreach (Control control in base.Controls)
			{
				ThemeControl(control);
			}
			// Prepare the next image and its dimmed display buffer first, then swap
			// them together so a failed/slow image load never flashes an empty frame.
			Image nextPicture = LoadBackgroundPicture();
			Bitmap nextCache = CreateBackgroundCache(nextPicture, backgroundDim, ClientSize);
			Image previousPicture = backgroundPicture;
			Bitmap previousCache = backgroundCache;
			backgroundPicture = nextPicture;
			backgroundCache = nextCache;
			if (previousPicture != null) previousPicture.Dispose();
			if (previousCache != null) previousCache.Dispose();
			SyncInventoryBackdrop();
			Invalidate(true);
		}
		finally
		{
			applyingTheme = false;
		}
	}

	private void SyncInventoryBackdrop()
	{
		if (inventory != null && inventoryFrame != null)
		{
			PaintListOnArtwork(inventory);
			PaintListOnArtwork(effects);
		}
	}

	private Image LoadBackgroundPicture()
	{
		if (string.IsNullOrEmpty(backgroundPicturePath)) return null;
		try
		{
			if (backgroundPicturePath.StartsWith("GameArt:", StringComparison.OrdinalIgnoreCase))
			{
				string resourceFile = ArtworkFileName(backgroundPicturePath.Substring(8));
				if (string.IsNullOrEmpty(resourceFile)) return null;
				using (Stream stream = GetType().Assembly.GetManifestResourceStream("EditorBackgrounds." + resourceFile))
				{
					if (stream == null) return null;
					using (Image original = Image.FromStream(stream)) return new Bitmap(original);
				}
			}
			if (File.Exists(backgroundPicturePath))
			{
				using (Image original = Image.FromFile(backgroundPicturePath)) return new Bitmap(original);
			}
		}
		catch { }
		return null;
	}

	private Bitmap CreateBackgroundCache(Image source, int dim, Size size)
	{
		if (source == null || size.Width < 1 || size.Height < 1) return null;
		Bitmap result = new Bitmap(size.Width, size.Height);
		using (Graphics graphics = Graphics.FromImage(result))
		{
			graphics.InterpolationMode = InterpolationMode.Bilinear;
			graphics.DrawImage(source, new Rectangle(0, 0, size.Width, size.Height));
			if (dim > 0)
			{
				using (SolidBrush brush = new SolidBrush(Color.FromArgb(Math.Max(0, Math.Min(255, dim * 255 / 100)), 0, 0, 0)))
					graphics.FillRectangle(brush, 0, 0, size.Width, size.Height);
			}
		}
		return result;
	}

	private void RefreshBackgroundCache()
	{
		if (IsDisposed) return;
		Bitmap nextCache = CreateBackgroundCache(backgroundPicture, backgroundDim, ClientSize);
		Bitmap previousCache = backgroundCache;
		backgroundCache = nextCache;
		if (previousCache != null) previousCache.Dispose();
		Invalidate(true);
		if (inventory != null) inventory.Invalidate();
		if (effects != null) effects.Invalidate();
	}

	private static string ArtworkFileName(string key)
	{
		int index;
		if (int.TryParse(key, out index) && index >= 1 && index <= 4)
		{
			return GameArtwork[index - 1][1];
		}
		for (int i = 0; i < GameArtwork.Length; i++)
		{
			if (string.Equals(GameArtwork[i][1], key, StringComparison.OrdinalIgnoreCase))
			{
				return GameArtwork[i][1];
			}
		}
		return null;
	}

	private static string ArtworkDisplayName(string key)
	{
		string fileName = ArtworkFileName(key);
		for (int i = 0; i < GameArtwork.Length; i++)
		{
			if (string.Equals(GameArtwork[i][1], fileName, StringComparison.OrdinalIgnoreCase))
			{
				return GameArtwork[i][0];
			}
		}
		return null;
	}

	private void PaintListOnArtwork(InventoryListBox list)
	{
		if (list == null)
		{
			return;
		}
		list.Tint = bg;
		list.PaintBackdrop = delegate(Graphics graphics)
		{
			graphics.Clear(bg);
			if (backgroundCache == null)
			{
				return;
			}
			Point origin = PointToClient(list.PointToScreen(Point.Empty));
			GraphicsState state = graphics.Save();
			graphics.TranslateTransform(-origin.X, -origin.Y);
			Rectangle bounds = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height);
			graphics.DrawImage(backgroundCache, bounds);
			graphics.Restore(state);
		};
		list.Invalidate();
	}

	internal void PaintHoverBackdrop(Control control, Graphics graphics)
	{
		for (Control parent = control.Parent; parent != null && parent != this; parent = parent.Parent)
		{
			if (parent.BackColor.A == 255)
			{
				graphics.Clear(parent.BackColor);
				return;
			}
		}
		if (backgroundCache == null || ClientSize.Width < 1 || ClientSize.Height < 1)
		{
			graphics.Clear(BackColor);
			return;
		}
		Point origin = PointToClient(control.PointToScreen(Point.Empty));
		Rectangle destination = new Rectangle(0, 0, control.ClientSize.Width, control.ClientSize.Height);
		PaintArtworkRegion(graphics, destination, origin);
	}

	private void PaintArtworkRegion(Graphics graphics, Rectangle destination, Point origin)
	{
		if (backgroundCache == null || ClientSize.Width < 1 || ClientSize.Height < 1)
		{
			graphics.Clear(bg);
			return;
		}
		RectangleF source = new RectangleF(
			(float)origin.X * backgroundCache.Width / ClientSize.Width,
			(float)origin.Y * backgroundCache.Height / ClientSize.Height,
			(float)destination.Width * backgroundCache.Width / ClientSize.Width,
			(float)destination.Height * backgroundCache.Height / ClientSize.Height);
		graphics.InterpolationMode = InterpolationMode.Bilinear;
		graphics.DrawImage(backgroundCache, destination, source, GraphicsUnit.Pixel);
	}

	private void DrawVignette(object sender, PaintEventArgs e)
	{
		Control control = (Control)sender;
		VignettePaint.Draw(e.Graphics, control.ClientRectangle, 18);
	}

	private void DrawInventoryWorkspaceOutline(object sender, PaintEventArgs e)
	{
		if (equipmentPanel == null || !equipmentPanel.Visible || base.ClientSize.Width < 40 || base.ClientSize.Height < 260)
		{
			return;
		}
		Rectangle rectangle = new Rectangle(16, 205, base.ClientSize.Width - 32, base.ClientSize.Height - 300);
		if (rectangle.Width < 2 || rectangle.Height < 2)
		{
			return;
		}
		using (Pen pen = new Pen(Color.FromArgb(66, 176, 193, 201), 1f))
		{
			e.Graphics.DrawRectangle(pen, rectangle);
		}
	}

	private void ThemeControl(Control c)
	{
		if (c == topBarPanel || c == status)
		{
			c.BackColor = topBar;
		}
		else if (c == inventoryFrame || c == equipmentPanel || c == pageHost || c == summaryDetails || c == details)
		{
			c.BackColor = Color.Transparent;
		}
		else if (c is Button)
		{
			Button button = (Button)c;
			button.BackColor = Color.Transparent;
			button.FlatAppearance.BorderSize = 0;
			button.FlatAppearance.BorderColor = bg;
			button.FlatAppearance.MouseOverBackColor = Color.Transparent;
		}
		else if (c is ListBox || c is ComboBox || c is NumericUpDown || c is TextBox)
		{
			c.BackColor = (((c == inventory) || (c == effects)) ? bg : surface);
		}
		else if (c is Label)
		{
			Label label = (Label)c;
			label.BackColor = Color.Transparent;
			label.ForeColor = ((label == levelValue) ? Color.FromArgb(199, 92, 235) : ((label == title || label == equipmentHeader || label == inventoryHeader || label == detailsHeader) ? Color.White : muted));
		}
		else if (c is Panel)
		{
			c.BackColor = Color.Transparent;
		}
		foreach (Control control in c.Controls)
		{
			ThemeControl(control);
		}
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		base.OnPaintBackground(e);
		if (backgroundCache != null)
		{
			Rectangle bounds = new Rectangle(0, 0, ClientSize.Width, ClientSize.Height);
			GraphicsState state = e.Graphics.Save();
			e.Graphics.InterpolationMode = InterpolationMode.Bilinear;
			e.Graphics.DrawImage(backgroundCache, bounds);
			e.Graphics.Restore(state);
		}
	}

	protected override void OnSizeChanged(EventArgs e)
	{
		base.OnSizeChanged(e);
		Invalidate();
	}

	private void OpenThemeSettings()
	{
		Form f = Dialog("UI Settings", 680);
		try
		{
			f.ClientSize = new Size(700, 680);
			L("EXPERIMENTAL APPEARANCE", 24, 18, 640, 30, f, 16).ForeColor = Color.White;
			L("Color the editor and choose one of the game’s own loading paintings.", 24, 52, 640, 24, f, 10);
			L("COLOR THEMES", 24, 96, 640, 22, f, 10).ForeColor = mint;
			string[] array = new string[8] { "Diamond", "Emerald", "Amethyst", "Ember", "Redstone", "Deep Blue", "Gold", "Graphite" };
			for (int i = 0; i < array.Length; i++)
			{
				int index = i;
				int num = 24 + i % 4 * 162;
				int num2 = 128 + i / 4 * 52;
				Button button = B(array[i], num, num2, 148, f, delegate
				{
					SetPalette(index, true);
				});
				button.Height = 40;
				button.BackColor = Palette(i)[4];
				button.FlatAppearance.BorderColor = Palette(i)[3];
				button.ForeColor = Color.White;
			}
			L("TEXT SIZE", 24, 245, 150, 22, f, 10);
			TrackBar textBar = new TrackBar
			{
				Location = new Point(160, 236),
				Size = new Size(430, 42),
				Minimum = 80,
				Maximum = 130,
				Value = textScale,
				TickFrequency = 10
			};
			f.Controls.Add(textBar);
			Label textNum = L(textScale + "%", 600, 244, 65, 22, f, 10);
			L("INTERFACE SIZE", 24, 297, 150, 22, f, 10);
			TrackBar uiBar = new TrackBar
			{
				Location = new Point(160, 288),
				Size = new Size(430, 42),
				Minimum = 80,
				Maximum = 110,
				Value = interfaceScale,
				TickFrequency = 5
			};
			f.Controls.Add(uiBar);
			Label uiNum = L(interfaceScale + "%", 600, 296, 65, 22, f, 10);
			L("OFFICIAL DUNGEONS II ARTWORK", 24, 350, 640, 22, f, 10).ForeColor = mint;
			FlowLayoutPanel artGallery = new FlowLayoutPanel
			{
				Location = new Point(24, 376),
				Size = new Size(640, 140),
				AutoScroll = true,
				WrapContents = true,
				BackColor = Color.Transparent,
				Padding = new Padding(0),
				Margin = new Padding(0)
			};
			f.Controls.Add(artGallery);
			Label pathLabel = L("No artwork selected", 132, 523, 388, 22, f, 9);
			for (int i = 0; i < GameArtwork.Length; i++)
			{
				string artworkName = GameArtwork[i][0];
				string artworkFile = GameArtwork[i][1];
				Panel tile = new Panel { Size = new Size(104, 92), Margin = new Padding(2), BackColor = Color.Transparent, Cursor = Cursors.Hand };
				PictureBox art = new PictureBox
				{
					Location = new Point(4, 2),
					Size = new Size(96, 58),
					SizeMode = PictureBoxSizeMode.Zoom,
					BorderStyle = BorderStyle.FixedSingle,
					Cursor = Cursors.Hand,
					Tag = "GameArt:" + artworkFile
				};
				using (Stream stream = GetType().Assembly.GetManifestResourceStream("EditorBackgrounds." + artworkFile))
				{
					if (stream != null)
					{
						using (Image original = Image.FromStream(stream))
						{
							art.Image = new Bitmap(original);
						}
					}
				}
				EventHandler chooseArtwork = delegate
				{
					backgroundPicturePath = "GameArt:" + artworkFile;
					pathLabel.Text = "Artwork selected";
					ApplyPalette();
				};
				tile.Click += chooseArtwork;
				art.Click += chooseArtwork;
				tile.Controls.Add(art);
				artGallery.Controls.Add(tile);
			}
			if (backgroundPicturePath.StartsWith("GameArt:", StringComparison.OrdinalIgnoreCase))
			{
				pathLabel.Text = "Artwork selected";
			}
			else if (File.Exists(backgroundPicturePath))
			{
				pathLabel.Text = "Custom artwork selected";
			}
			L("BACKGROUND PICTURE", 24, 523, 104, 22, f, 10);
			Button button2 = B("Choose your own…", 530, 488, 135, f, delegate
			{
				using (OpenFileDialog openFileDialog = new OpenFileDialog
				{
					Filter = "Pictures (*.png;*.jpg;*.jpeg;*.bmp)|*.png;*.jpg;*.jpeg;*.bmp",
					Title = "Choose an editor background picture"
				})
				{
					if (openFileDialog.ShowDialog(f) == DialogResult.OK)
					{
						backgroundPicturePath = openFileDialog.FileName;
						pathLabel.Text = "Custom artwork selected";
						ApplyPalette();
					}
				}
			});
			button2.Location = new Point(530, 518);
			button2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
			L("ARTWORK DARKNESS", 24, 562, 180, 22, f, 10);
			TrackBar dimBar = new TrackBar
			{
				Location = new Point(210, 550),
				Size = new Size(380, 42),
				Minimum = 0,
				Maximum = 80,
				Value = backgroundDim,
				TickFrequency = 10
			};
			f.Controls.Add(dimBar);
			Label dimNum = L(backgroundDim + "%", 600, 558, 65, 22, f, 10);
			textBar.ValueChanged += delegate
			{
				textNum.Text = textBar.Value + "%";
			};
			uiBar.ValueChanged += delegate
			{
				uiNum.Text = uiBar.Value + "%";
			};
			dimBar.ValueChanged += delegate
			{
				dimNum.Text = dimBar.Value + "%";
			};
			B("Reset", 24, f.ClientSize.Height - 80, 100, f, delegate
			{
				SetPalette(0, true);
				textBar.Value = 100;
				uiBar.Value = 100;
				dimBar.Value = 42;
				backgroundPicturePath = "";
				pathLabel.Text = "No artwork selected";
				ApplyPalette();
			});
			Button button3 = B("Apply settings", f.ClientSize.Width - 174, f.ClientSize.Height - 80, 150, f, delegate
			{
				textScale = textBar.Value;
				int num3 = interfaceScale;
				interfaceScale = uiBar.Value;
				backgroundDim = dimBar.Value;
				ApplyTextScale();
				if (num3 != interfaceScale)
				{
					base.ClientSize = new Size((int)((double)(1320 * interfaceScale) / 100.0), (int)((double)(860 * interfaceScale) / 100.0));
				}
				ApplyPalette();
				SaveThemePreferences();
				f.DialogResult = DialogResult.OK;
			});
			button3.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
			L("Settings are saved for this editor.", 24, f.ClientSize.Height - 42, 500, 22, f, 9);
			f.ShowDialog(this);
		}
		finally
		{
			if (f != null)
			{
				((IDisposable)f).Dispose();
			}
		}
	}

	private void ApplyTextScale()
	{
		float factor = (float)textScale / 100f * ((float)interfaceScale / 100f);
		foreach (Control control in base.Controls)
		{
			ScaleFont(control, factor);
		}
	}

	private void ScaleFont(Control c, float factor)
	{
		if (c.Font != null && !(c is Form))
		{
			try
			{
				float num = c.Font.Size;
				if (c.Tag == null)
				{
					c.Tag = num;
				}
				else if (c.Tag is float)
				{
					num = (float)c.Tag;
				}
				Font font = c.Font;
				c.Font = new Font(font.FontFamily, Math.Max(7f, num * factor), font.Style);
			}
			catch
			{
			}
		}
		foreach (Control control in c.Controls)
		{
			ScaleFont(control, factor);
		}
	}

	private void LayoutMain()
	{
		if (equipmentPanel != null)
		{
			int num = base.ClientSize.Width;
			int num2 = base.ClientSize.Height;
			int num3 = 362;
			int num4 = 24;
			int num5 = 28;
			int num6 = Math.Max(420, num - num3 - num4 - num5);
			int num7 = Math.Max(220, (int)Math.Round((double)num6 * 0.42));
			int num8 = num3 + num7 + num5;
			int num9 = Math.Max(200, num - num4 - num8);
			int num10 = Math.Max(240, num2 - 312);
			settingsButton.Left = num - 346;
			fileLabel.Left = num - 194;
			equipmentPanel.Height = num10;
			inventoryHeader.Location = new Point(num3, 178);
			inventoryHeader.Width = num7;
			detailsHeader.Location = new Point(num8, 178);
			detailsHeader.Width = num9;
			inventoryFilterButton.Left = num3;
			showMerchant.Left = num3 + 158;
			inventoryFrame.SetBounds(num3, 250, num7, num10 - 40);
			details.SetBounds(num8, 211, num9, num10 - 1);
			newButton.Left = num - 270;
			duplicateButton.Left = num - 136;
			catalogNote.Top = num2 - 87;
			status.Top = num2 - 43;
			if (pageHost != null)
			{
				pageHost.SetBounds(24, 60, Math.Max(400, num - 48), Math.Max(300, num2 - 115));
			}
		}
	}

	private void EnableDoubleBuffering(Control control)
	{
		if (control == null || !bufferedControls.Add(control))
		{
			return;
		}
		try
		{
			if (DoubleBufferedProperty != null)
			{
				DoubleBufferedProperty.SetValue(control, true, null);
			}
		}
		catch
		{
		}
		control.ControlAdded += delegate(object sender, ControlEventArgs e)
		{
			EnableDoubleBuffering(e.Control);
		};
		foreach (Control child in control.Controls)
		{
			EnableDoubleBuffering(child);
		}
	}

	private Button Nav(string text, int x, Control parent, EventHandler click)
	{
		int num;
		switch (text)
		{
		default:
			num = 105;
			break;
		case "INVENTORY":
			num = 96;
			break;
		case "QUESTS":
			num = 82;
			break;
		case "MERCHANTS":
			num = 106;
			break;
		case "MODS":
			num = 78;
			break;
		case "CHARACTER":
			num = 130;
			break;
		case "STATION LOCATIONS":
			num = 156;
			break;
		case "ACHIEVEMENTS":
			num = 142;
			break;
		}
		int w = num;
		Button button = B(text, x, 5, w, parent, click);
		button.Size = new Size(w, 36);
		button.FlatAppearance.BorderSize = 0;
		button.BackColor = topBar;
		button.ForeColor = Color.FromArgb(214, 222, 222);
		return button;
	}

	private void Navigate(Button button)
	{
		if (button == inventoryButton)
		{
			navUnderline.Location = new Point(132, 43);
			navUnderline.Width = 96;
		}
		else if (button == questsButton)
		{
			navUnderline.Location = new Point(232, 43);
			navUnderline.Width = 82;
		}
		else if (button == villagersButton)
		{
			navUnderline.Location = new Point(316, 43);
			navUnderline.Width = 106;
		}
		else if (button == progressButton)
		{
			navUnderline.Location = new Point(424, 43);
			navUnderline.Width = 142;
		}
		else if (button == locationsButton)
		{
			navUnderline.Location = new Point(570, 43);
			navUnderline.Width = 156;
		}
		else
		{
			navUnderline.Location = new Point(730, 43);
			navUnderline.Width = 78;
		}
	}

	private void ShowSection(string section)
	{
		if (pageTransition) return;
		pageTransition = true;
		try
		{
			using (Form overlay = CreateLoadingOverlay("Loading page…"))
			using (Timer timer = new Timer())
			{
				timer.Interval = 120;
				timer.Tick += delegate
				{
					timer.Stop();
					try { ShowSectionNow(section); }
					catch (Exception ex) { Error(ex); }
					finally { overlay.Close(); }
				};
				timer.Start();
				overlay.ShowDialog(this);
			}
		}
		finally { pageTransition = false; }
	}

	private void ShowSectionNow(string section)
	{
		foreach (Control item in pageHost.Controls.Cast<Control>().ToList())
		{
			pageHost.Controls.Remove(item);
			item.Dispose();
		}
		if (section == "Mods")
		{
			foreach (Control inventoryViewControl in inventoryViewControls) inventoryViewControl.Visible = false;
			pageHost.Controls.Add(new ModsPage { Dock = DockStyle.Fill });
			pageHost.Visible = true;
			pageHost.BringToFront();
			topBarPanel.BringToFront();
			status.BringToFront();
			return;
		}
		if (doc == null)
		{
			foreach (Control inventoryViewControl in inventoryViewControls) inventoryViewControl.Visible = true;
			pageHost.Visible = false;
			return;
		}
		if (section == "Inventory")
		{
			foreach (Control inventoryViewControl in inventoryViewControls)
			{
				inventoryViewControl.Visible = true;
			}
			pageHost.Visible = false;
			RefreshInventory(selected);
			return;
		}
		foreach (Control inventoryViewControl2 in inventoryViewControls)
		{
			inventoryViewControl2.Visible = false;
		}
		object obj;
		switch (section)
		{
		default:
			obj = new AchievementsPage(doc, ProgressPageChanged);
			break;
		case "FastTravel":
			obj = new FastTravelPage(doc, ProgressPageChanged);
			break;
		case "Merchants":
			obj = new VillagersPage(doc, ProgressPageChanged);
			break;
		case "Quests":
			obj = new QuestsPage(doc, ProgressPageChanged);
			break;
		}
		Control control = (Control)obj;
		control.Dock = DockStyle.Fill;
		pageHost.Controls.Add(control);
		pageHost.Visible = true;
		pageHost.BringToFront();
		topBarPanel.BringToFront();
		status.BringToFront();
	}

	private void ProgressPageChanged(bool changed, string label)
	{
		if (changed)
		{
			Changed();
			status.Text = label + " updated · Export your .sav when you're done.";
		}
	}

	private void RefreshEquippedFilters()
	{
		if (equipmentPanel != null)
		{
			equipmentPanel.Controls.Clear();
			equippedFilterButtons.Clear();
			List<J> equipped = ((doc == null) ? new List<J>() : doc.Entries.Values.Where((J e) => SaveDocument.Gear(e) && e["EquippedSlot"].Text != "None" && !SaveDocument.Merchant(e)).ToList());
			int num = 4;
			AddEquipmentGroup("WEAPONS", new string[2][]
			{
				new string[3] { "Melee", "Melee", "Melee" },
				new string[3] { "Bow", "Bow", "Bow" }
			}, equipped, ref num);
			AddEquipmentGroup("ARMOR", new string[4][]
			{
				new string[3] { "H", "H", "Helmet" },
				new string[3] { "C", "C", "Chest" },
				new string[3] { "L", "L", "Leggings" },
				new string[3] { "B", "B", "Boots" }
			}, equipped, ref num);
			AddEquipmentGroup("ARTIFACTS", new string[3][]
			{
				new string[3] { "Artifact1", "Artifact", "Artifact 1" },
				new string[3] { "Artifact2", "Artifact", "Artifact 2" },
				new string[3] { "Artifact3", "Artifact", "Artifact 3" }
			}, equipped, ref num);
			AddEquipmentGroup("TALISMANS", new string[3][]
			{
				new string[3] { "Talisman1", "Talisman", "Talisman 1" },
				new string[3] { "Talisman2", "Talisman", "Talisman 2" },
				new string[3] { "Talisman3", "Talisman", "Talisman 3" }
			}, equipped, ref num);
		}
	}

	private void AddEquipmentGroup(string heading, string[][] slots, List<J> equipped, ref int y)
	{
		Label label = L(heading, 4, y, 270, 20, equipmentPanel, 9);
		label.ForeColor = muted;
		y += 23;
		int num = 4;
		foreach (string[] array in slots)
		{
			string slotKey = array[0];
			string text = array[1];
			string slotLabel = array[2];
			J j = FindEquipped(equipped, slotKey);
			Image image = ((j == null) ? EmptySlotImage(slotKey) : ItemArt.Get(j));
			Button button = new Button
			{
				Location = new Point(num, y),
				Size = new Size(62, 62),
				FlatStyle = FlatStyle.Flat
			};
			Color backColor;
			if (j != null)
			{
				if (text.Length != 1)
				{
					switch (text)
					{
					default:
						backColor = Color.FromArgb(78, 72, 66);
						break;
					case "Melee":
						backColor = Color.FromArgb(42, 91, 119);
						break;
					case "Bow":
						backColor = Color.FromArgb(55, 103, 78);
						break;
					case "Artifact":
						backColor = Color.FromArgb(45, 94, 135);
						break;
					}
				}
				else
				{
					backColor = Color.FromArgb(56, 111, 76);
				}
			}
			else
			{
				backColor = Color.Black;
			}
			button.BackColor = Color.Transparent;
			button.Tag = j;
			button.Cursor = Cursors.Hand;
			button.AccessibleName = ((j == null) ? ("Empty " + slotLabel) : SaveDocument.Name(SaveDocument.Tag(j)));
			button.AccessibleDescription = ((j == null) ? "Empty equipment slot" : SaveDocument.Name(SaveDocument.Tag(j)));
			Button tile = button;
			HoverGrow.Attach(tile, 1.10f);
			tile.FlatAppearance.BorderColor = bg;
			tile.FlatAppearance.BorderSize = 0;
			tile.Paint += delegate(object s, PaintEventArgs e)
			{
				if (image != null)
				{
					e.Graphics.DrawImage(image, new Rectangle(0, 0, tile.Width, tile.Height));
				}
			};
			string chosenFilter = text;
			J captured = j;
			tile.Click += delegate
			{
				if (captured == null)
				{
					ChooseEquipment(slotKey, chosenFilter, slotLabel);
				}
				else
				{
					ToggleInventoryFilter(chosenFilter);
					foreach (object item in inventory.Items)
					{
						if (item is EntryChoice && ((EntryChoice)item).Entry == captured)
						{
							inventory.SelectedItem = item;
							break;
						}
					}
					Navigate(inventoryButton);
				}
			};
			equipmentTip.SetToolTip(tile, ((j == null) ? "Empty " : (SaveDocument.Name(SaveDocument.Tag(j)) + " · ")) + slotLabel + ((j == null) ? " slot · click to choose" : " slot · click to filter"));
			equipmentPanel.Controls.Add(tile);
			equippedFilterButtons.Add(tile);
			num += 70;
		}
		y += 88;
	}

	private void ChooseEquipment(string slotKey, string filter, string slotLabel)
	{
		if (doc == null)
		{
			return;
		}
		using (ItemPicker itemPicker = new ItemPicker(EquipmentCatalog.Templates(doc), doc.Entries.Values, filter, "ADD & EQUIP", true, "CHOOSE " + slotLabel.ToUpperInvariant()))
		{
			if (itemPicker.ShowDialog(this) == DialogResult.OK)
			{
				J j = doc.AddFrom(itemPicker.SelectedTemplate);
				j["EquippedSlot"] = J.Str(EquipmentSlot(slotKey));
				Changed();
				RefreshInventory(j);
			}
		}
	}

	public static string EquipmentSlot(string slotKey)
	{
		switch (slotKey)
		{
		case "Melee":
			return "SW.ItemSlot.Equipment.MeleeWeapon";
		case "Bow":
			return "SW.ItemSlot.Equipment.RangedWeapon";
		case "H":
			return "SW.ItemSlot.Equipment.Armor.Helmet";
		case "C":
			return "SW.ItemSlot.Equipment.Armor.Chest";
		case "L":
			return "SW.ItemSlot.Equipment.Armor.Leggings";
		case "B":
			return "SW.ItemSlot.Equipment.Armor.Boots";
		default:
			if (slotKey.StartsWith("Artifact", StringComparison.Ordinal))
			{
				return "SW.ItemSlot.Equipment.Artifact.Slot" + slotKey.Substring(8);
			}
			if (slotKey.StartsWith("Talisman", StringComparison.Ordinal))
			{
				return "SW.ItemSlot.Equipment.Talisman.Slot" + slotKey.Substring(8);
			}
			throw new ArgumentException("Unknown equipment slot: " + slotKey);
		}
	}

	private J FindEquipped(List<J> equipped, string slot)
	{
		foreach (J item in equipped)
		{
			string text = ItemArt.Category(item);
			if ((slot == "Melee" && text == "Melee") || (slot == "Bow" && text == "Bow"))
			{
				return item;
			}
			if (slot.Length == 1 && text == "Armor" && ItemArt.ArmorSlot(item) == slot)
			{
				return item;
			}
			if (slot.StartsWith("Artifact", StringComparison.Ordinal) && text == "Artifact" && EquippedIndex(item) == int.Parse(slot.Substring(8)))
			{
				return item;
			}
			if (slot.StartsWith("Talisman", StringComparison.Ordinal) && text == "Talisman" && EquippedIndex(item) == int.Parse(slot.Substring(8)))
			{
				return item;
			}
		}
		return null;
	}

	private static Image EmptySlotImage(string slotKey)
	{
		Image value;
		if (emptySlotIcons.TryGetValue(slotKey, out value))
		{
			return value;
		}
		string text = slotKey;
		switch (slotKey)
		{
		case "H":
			text = "Helmet";
			break;
		case "C":
			text = "Chest";
			break;
		case "L":
			text = "Leggings";
			break;
		case "B":
			text = "Boots";
			break;
		}
		string name = "ItemIcons.EmptySlot_" + text + ".png";
		using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
		{
			if (stream == null)
			{
				throw new InvalidDataException("Missing empty-slot art: " + slotKey);
			}
			using (Image original = Image.FromStream(stream))
			{
				value = new Bitmap(original);
			}
		}
		emptySlotIcons.Add(slotKey, value);
		return value;
	}

	private int EquippedIndex(J entry)
	{
		string input = entry["EquippedSlot"].Text;
		Match match = Regex.Match(input, "Slot(\\d+)$");
		int result;
		return (!match.Success || !int.TryParse(match.Groups[1].Value, out result)) ? 1 : result;
	}

	private void DrawInventoryRow(object sender, DrawItemEventArgs e)
	{
		if (e.Index < 0)
		{
			return;
		}
		EntryChoice entryChoice = inventory.Items[e.Index] as EntryChoice;
		if (entryChoice == null)
		{
			return;
		}
		J entry = entryChoice.Entry;
		bool flag = (e.State & DrawItemState.Selected) != 0;
		string text = ItemArt.Category(entry);
		string text2 = SaveDocument.Data(entry)["RarityTag"].Text;
		Image image = ItemArt.Get(entry);
		using (Bitmap row = new Bitmap(Math.Max(1, e.Bounds.Width), Math.Max(1, e.Bounds.Height)))
		{
			using (Graphics graphics = Graphics.FromImage(row))
			{
				Point origin = PointToClient(inventory.PointToScreen(e.Bounds.Location));
				PaintArtworkRegion(graphics, new Rectangle(0, 0, row.Width, row.Height), origin);
				if (image != null)
				{
					float scale = inventory.HoverScale(e.Index);
					int size = (int)Math.Round(38 * scale);
					int left = 7 + (38 - size) / 2;
					int top = (e.Bounds.Height - size) / 2;
					graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
					graphics.DrawImage(image, new Rectangle(left, top, size, size));
				}
				TextRenderer.DrawText(graphics, SaveDocument.Name(SaveDocument.Tag(entry)), Font, new Rectangle(55, 6, e.Bounds.Width - 62, 20), Color.White, TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
				using (Font subFont = new Font(Font.FontFamily, 8f))
				{
					TextRenderer.DrawText(graphics, ItemArt.TypeLabel(entry) + "  ·  " + SaveDocument.Name(text2), subFont, new Rectangle(55, 27, e.Bounds.Width - 62, 17), ItemArt.ColorFor(text), TextFormatFlags.EndEllipsis | TextFormatFlags.SingleLine);
				}
				if (flag)
				{
					using (SolidBrush brush = new SolidBrush(orange))
					{
						graphics.FillRectangle(brush, 0, 0, 3, e.Bounds.Height);
					}
				}
			}
			e.Graphics.DrawImageUnscaled(row, e.Bounds.Location);
		}
	}

	private void DrawEffectRow(InventoryListBox list, DrawItemEventArgs e)
	{
		if (e.Index < 0) return;
		using (Bitmap row = new Bitmap(Math.Max(1, e.Bounds.Width), Math.Max(1, e.Bounds.Height)))
		using (Graphics graphics = Graphics.FromImage(row))
		{
			Point origin = PointToClient(list.PointToScreen(e.Bounds.Location));
			PaintArtworkRegion(graphics, new Rectangle(0, 0, row.Width, row.Height), origin);
			DrawItemEventArgs bufferedArgs = new DrawItemEventArgs(graphics, list.Font,
				new Rectangle(0, 0, row.Width, row.Height), e.Index, e.State,
				list.ForeColor, list.BackColor);
			EffectArt.DrawRow(list, bufferedArgs);
			e.Graphics.DrawImageUnscaled(row, e.Bounds.Location);
		}
	}

	private void BuildInventoryFilters()
	{
		inventoryFilterMenu = new ContextMenuStrip
		{
			BackColor = surface,
			ForeColor = Color.White,
			ShowImageMargin = false,
			ShowCheckMargin = true
		};
		string[] array = new string[10] { "All", "Artifact", "Bow", "Melee", "Armor", "Talisman", "H", "C", "L", "B" };
		foreach (string text in array)
		{
			string filter = text;
			object obj;
			switch (text)
			{
			default:
				obj = text;
				break;
			case "B":
				obj = "B · Boots";
				break;
			case "L":
				obj = "L · Leggings";
				break;
			case "C":
				obj = "C · Chestplate";
				break;
			case "H":
				obj = "H · Helmet";
				break;
			case "All":
				obj = "All items";
				break;
			}
			string text2 = (string)obj;
			ToolStripMenuItem toolStripMenuItem = new ToolStripMenuItem(text2);
			toolStripMenuItem.Tag = text;
			toolStripMenuItem.Checked = text == "All";
			ToolStripMenuItem toolStripMenuItem2 = toolStripMenuItem;
			toolStripMenuItem2.Click += delegate
			{
				ToggleInventoryFilter(filter);
			};
			inventoryFilterMenu.Items.Add(toolStripMenuItem2);
		}
	}

	public void ToggleInventoryFilter(string key)
	{
		inventoryFilter = ((inventoryFilter == key || key == "All") ? "All" : key);
		inventoryFilterButton.Text = "Filters · " + inventoryFilter;
		foreach (ToolStripMenuItem item in inventoryFilterMenu.Items)
		{
			item.Checked = (string)item.Tag == inventoryFilter;
		}
		RefreshInventory(selected);
	}

	private void Help()
	{
		MessageBox.Show(this, "Open a character .sav to create or edit equipment, emeralds, Echo Shards, hero level, achievements, quests, and villagers. The item and effect catalogs come from the installed game's definition tables. They work independently of your inventory.\n\nClick the emerald, Echo Shard, or level number on the main screen to edit it inline. Use Achievements to complete or clear achievement progress. Use Quests to browse all main and side quests and choose the current quest. Use Merchants to unlock the game's merchant and villager characters through their saved quest and objective flags. These tabs open full pages in the editor; changes are kept in the loaded save until you export them.\n\nTo use your changes, choose Export .sav from Menu and save the edited character file. You can export over the loaded save or to another path.\n\nThe effect picker contains 106 enchantment tier variants, 262 gear effect variants, and 57 talisman variants. Search by name and select the desired tier. Equipment compatibility is shown where defined. Talisman effects may not work on equipment. Raw values can be adjusted with Edit selected.\n\nThe game's acceptance of generated equipment, quest changes, villager unlocks, and achievement refresh still needs an in-game test.", "Using the editor", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
	}

	private void AddEffect()
	{
		if (selected == null)
		{
			return;
		}
		using (EffectPicker effectPicker = new EffectPicker(effectTemplates.Select((EffectChoice t) => new EffectChoice
		{
			Batch = t.Batch,
			Effect = t.Effect,
			Label = EffectLabel(t.Batch, t.Effect)
		})))
		{
			if (effectPicker.ShowDialog(this) == DialogResult.OK)
			{
				J selectedBatch = effectPicker.SelectedBatch;
				if (selectedBatch != null)
				{
					SaveDocument.AddEffect(selected, selectedBatch);
					Changed();
					FillEffects();
				}
			}
		}
	}

	private void Enable()
	{
		bool enabled = doc != null;
		exportMenuItem.Enabled = enabled;
		importMenuItem.Enabled = true;
		progressButton.Enabled = enabled;
		questsButton.Enabled = enabled;
		villagersButton.Enabled = enabled;
		locationsButton.Enabled = enabled;
		newButton.Enabled = enabled;
		duplicateButton.Enabled = selected != null;
		details.Enabled = selected != null;
	}

	private void Changed()
	{
		exported = false;
		Text = "Dungeons II Save Editor *";
		status.Text = "Changes pending · Export to your chosen .sav path when you're done.";
	}

	private bool ConfirmLeave()
	{
		if (exported)
		{
			return true;
		}
		int result;
		switch (MessageBox.Show(this, "Export your changes before continuing?", "Unsaved edits", MessageBoxButtons.YesNoCancel))
		{
		case DialogResult.Yes:
			result = (Export() ? 1 : 0);
			break;
		default:
			result = 0;
			break;
		case DialogResult.No:
			result = 1;
			break;
		}
		return (byte)result != 0;
	}

	private void Open()
	{
		if (!ConfirmLeave())
		{
			return;
		}
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = "Dungeons II save (*.sav)|*.sav";
		openFileDialog.Title = "Open Dungeons II character save";
		using (OpenFileDialog openFileDialog2 = openFileDialog)
		{
			if (openFileDialog2.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			try
			{
				LoadFile(openFileDialog2.FileName);
			}
			catch (Exception ex)
			{
				Error(ex);
			}
		}
	}

	public void LoadFile(string path)
	{
		SaveDocument d = (doc = SaveDocument.Load(path));
		selected = null;
		templates.Clear();
		effectTemplates.Clear();
		Discover(d);
		exported = true;
		fileLabel.Text = "Save file loaded";
		RefreshCharacterSummary();
		Text = "Dungeons II Save Editor";
		RefreshInventory(null);
		status.Text = "Loaded .sav · Export writes changes to your chosen path.";
		Enable();
	}

	private Form CreateLoadingOverlay(string message)
	{
		Form overlay = new Form();
		overlay.FormBorderStyle = FormBorderStyle.None;
		overlay.StartPosition = FormStartPosition.Manual;
		overlay.ShowInTaskbar = false;
		overlay.BackColor = Color.Black;
		overlay.Bounds = Bounds;
		Label label = new Label();
		label.Text = message;
		label.ForeColor = Color.White;
		label.BackColor = Color.Black;
		label.Font = new Font(Font.FontFamily, 12f, FontStyle.Regular);
		label.TextAlign = ContentAlignment.MiddleCenter;
		label.Size = new Size(360, 30);
		ProgressBar bar = new ProgressBar();
		bar.Style = ProgressBarStyle.Marquee;
		bar.MarqueeAnimationSpeed = 28;
		bar.Size = new Size(360, 24);
		Action layout = delegate
		{
			int left = Math.Max(0, (overlay.ClientSize.Width - 360) / 2);
			int top = Math.Max(0, (overlay.ClientSize.Height - 64) / 2);
			label.Location = new Point(left, top);
			bar.Location = new Point(left, top + 38);
		};
		overlay.Controls.Add(label);
		overlay.Controls.Add(bar);
		overlay.Resize += delegate { layout(); };
		overlay.Shown += delegate { overlay.Bounds = Bounds; layout(); };
		layout();
		return overlay;
	}

	private void AddSummaryText(string text)
	{
		summaryDetails.Controls.Add(new Label
		{
			Text = text,
			AutoSize = true,
			ForeColor = muted,
			Font = Font,
			Margin = new Padding(0, 4, 5, 0)
		});
	}

	private Label SummaryAmountLabel(decimal value, bool emerald)
	{
		HoverTextLabel amount = new HoverTextLabel
		{
			Text = value.ToString("N0", CultureInfo.InvariantCulture),
			AutoSize = false,
			Size = new Size(86, 24),
			ForeColor = muted,
			Font = Font,
			TextAlign = ContentAlignment.MiddleLeft,
			Cursor = Cursors.Hand,
			Location = new Point(25, 0),
			AccessibleName = (emerald ? "Emerald amount" : "Echo Shard amount"),
			AccessibleDescription = "Click to edit this amount"
		};
		amount.Click += delegate
		{
			EditSummaryAmount(amount, emerald);
		};
		equipmentTip.SetToolTip(amount, "Click to edit this amount");
		return amount;
	}

	private void AddSummaryGroup(string resource, decimal value, bool emerald, string name)
	{
		Panel group = new Panel
		{
			Size = new Size(116, 42),
			Margin = new Padding(0, 0, 2, 0),
			BackColor = Color.Transparent,
			AccessibleName = name
		};
		using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("ItemIcons." + resource))
		{
			if (stream == null)
			{
				throw new InvalidDataException("Missing counter icon: " + resource);
			}
			using (Image original = Image.FromStream(stream))
			{
				group.Controls.Add(new HoverPictureBox
				{
					Image = new Bitmap(original),
					Location = new Point(1, 1),
					Size = new Size(22, 22),
					SizeMode = PictureBoxSizeMode.Zoom,
					AccessibleName = name
				});
			}
		}
		group.Controls.Add(SummaryAmountLabel(value, emerald));
		group.Controls.Add(new Label
		{
			Text = name,
			Location = new Point(0, 24),
			Size = new Size(116, 16),
			ForeColor = muted,
			Font = new Font(Font.FontFamily, 8.5f, FontStyle.Regular),
			TextAlign = ContentAlignment.MiddleCenter,
			BackColor = Color.Transparent
		});
		summaryDetails.Controls.Add(group);
	}

	private void EditSummaryAmount(Label amount, bool emerald)
	{
		Control parent = amount.Parent;
		if (doc == null || parent == null)
		{
			return;
		}
		int index = parent.Controls.GetChildIndex(amount);
		Rectangle bounds = amount.Bounds;
		decimal val = (emerald ? SaveProgression.Emeralds(doc) : SaveProgression.SpringStone(doc));
		NumericUpDown editor = new NumericUpDown
		{
			Minimum = 0m,
			Maximum = 999999999m,
			Value = Math.Max(0m, Math.Min(999999999m, val)),
			ThousandsSeparator = true,
			DecimalPlaces = 0,
			Size = bounds.Size,
			Location = bounds.Location,
			BackColor = surface,
			ForeColor = Color.White,
			Font = Font,
			AccessibleName = amount.AccessibleName
		};
		parent.Controls.Remove(amount);
		parent.Controls.Add(editor);
		parent.Controls.SetChildIndex(editor, index);
		bool finished = false;
		List<Control> watched = new List<Control>();
		MouseEventHandler outsideClick = null;
		Action<bool> finish = null;
		finish = delegate(bool commit)
		{
			if (!finished)
			{
				finished = true;
				foreach (Control item in watched)
				{
					item.MouseDown -= outsideClick;
				}
				bool flag = false;
				if (commit)
				{
					flag = (emerald ? SaveProgression.SetEmeralds(doc, editor.Value) : SaveProgression.SetSpringStone(doc, editor.Value));
				}
				decimal value = (emerald ? SaveProgression.Emeralds(doc) : SaveProgression.SpringStone(doc));
				parent.SuspendLayout();
				parent.Controls.Remove(editor);
				editor.Dispose();
				Label label = SummaryAmountLabel(value, emerald);
				parent.Controls.Add(label);
				parent.Controls.SetChildIndex(label, index);
				parent.ResumeLayout();
				if (flag)
				{
					Changed();
					status.Text = (emerald ? "Emeralds" : "Echo Shards") + " updated · Export the .sav, then load this character to use it.";
				}
			}
		};
		outsideClick = delegate
		{
			finish(true);
		};
		Action<Control> watch = null;
		watch = delegate(Control control)
		{
			if (control == editor)
			{
				return;
			}
			control.MouseDown += outsideClick;
			watched.Add(control);
			foreach (Control childControl in control.Controls)
			{
				watch(childControl);
			}
		};
		watch(this);
		editor.Leave += delegate
		{
			finish(true);
		};
		editor.KeyDown += delegate(object s, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				e.SuppressKeyPress = true;
				finish(true);
			}
			else if (e.KeyCode == Keys.Escape)
			{
				e.SuppressKeyPress = true;
				finish(false);
			}
		};
		editor.Focus();
		editor.Select(0, editor.Text.Length);
	}

	private void EditLevelValue()
	{
		if (doc == null || levelValue.Parent == null)
		{
			return;
		}
		Control parent = levelValue.Parent;
		int index = parent.Controls.GetChildIndex(levelValue);
		Rectangle bounds = levelValue.Bounds;
		decimal val = SaveProgression.Level(doc);
		NumericUpDown editor = new NumericUpDown
		{
			Location = bounds.Location,
			Size = new Size(bounds.Width, 42),
			Minimum = 0m,
			Maximum = 999999999m,
			Value = Math.Max(0m, Math.Min(999999999m, val)),
			ThousandsSeparator = false,
			DecimalPlaces = 0,
			BackColor = surface,
			ForeColor = Color.FromArgb(199, 92, 235),
			Font = new Font(Font.FontFamily, 20f, FontStyle.Regular),
			AccessibleName = "Hero level"
		};
		parent.Controls.Remove(levelValue);
		parent.Controls.Add(editor);
		parent.Controls.SetChildIndex(editor, index);
		bool finished = false;
		List<Control> watched = new List<Control>();
		MouseEventHandler outsideClick = null;
		Action<bool> finish = null;
		finish = delegate(bool commit)
		{
			if (!finished)
			{
				finished = true;
				foreach (Control item in watched)
				{
					item.MouseDown -= outsideClick;
				}
				bool flag = commit && SaveProgression.SetLevel(doc, editor.Value);
				parent.Controls.Remove(editor);
				editor.Dispose();
				levelValue.Text = SaveProgression.Level(doc).ToString(CultureInfo.InvariantCulture);
				parent.Controls.Add(levelValue);
				parent.Controls.SetChildIndex(levelValue, index);
				if (flag)
				{
					Changed();
					status.Text = "Hero level updated · Export the .sav, then load this character to use it.";
				}
			}
		};
		outsideClick = delegate
		{
			finish(true);
		};
		Action<Control> watch = null;
		watch = delegate(Control control)
		{
			if (control == editor)
			{
				return;
			}
			control.MouseDown += outsideClick;
			watched.Add(control);
			foreach (Control childControl in control.Controls)
			{
				watch(childControl);
			}
		};
		watch(this);
		editor.Leave += delegate
		{
			finish(true);
		};
		editor.KeyDown += delegate(object s, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Return)
			{
				e.SuppressKeyPress = true;
				finish(true);
			}
			else if (e.KeyCode == Keys.Escape)
			{
				e.SuppressKeyPress = true;
				finish(false);
			}
		};
		editor.Focus();
		editor.Select(0, editor.Text.Length);
	}

	private void RefreshCharacterSummary()
	{
		if (doc == null)
		{
			return;
		}
		levelValue.Text = SaveProgression.Level(doc).ToString(CultureInfo.InvariantCulture);
		summaryDetails.SuspendLayout();
		DisposeSummaryImages(summaryDetails);
		summaryDetails.Controls.Clear();
		AddSummaryText("Save file loaded");
		AddSummaryText("·");
		AddSummaryGroup("Emerald.png", SaveProgression.Emeralds(doc), true, "Emeralds");
		AddSummaryText("·");
		AddSummaryGroup("EchoShard.png", SaveProgression.SpringStone(doc), false, "Echo Shards");
		AddSummaryText("·");
		AddSummaryText(doc.Entries.Values.Count + " items");
		summaryDetails.ResumeLayout();
		summary.Visible = false;
		summaryDetails.Visible = true;
	}

	private void DisposeSummaryImages(Control parent)
	{
		foreach (Control child in parent.Controls)
		{
			DisposeSummaryImages(child);
			PictureBox pictureBox = child as PictureBox;
			if (pictureBox != null && pictureBox.Image != null)
			{
				Image image = pictureBox.Image;
				pictureBox.Image = null;
				image.Dispose();
			}
		}
	}

	private void ProgressChanged(bool changed, string label)
	{
		if (changed)
		{
			Changed();
			RefreshCharacterSummary();
			status.Text = label + " updated · Export the .sav, then load this character to use it.";
		}
	}

	private void EditCharacterProgress()
	{
		if (doc == null)
		{
			return;
		}
		try
		{
			using (CharacterProgressDialog characterProgressDialog = new CharacterProgressDialog(doc))
			{
				if (characterProgressDialog.ShowDialog(this) != DialogResult.OK)
				{
					return;
				}
				bool flag = false;
				foreach (AchievementEdit achievementEdit in characterProgressDialog.AchievementEdits)
				{
					flag = SaveProgression.SetComplete(doc, achievementEdit.Definition, achievementEdit.Completed) || flag;
				}
				ProgressChanged(flag, "Achievements");
			}
		}
		catch (Exception ex)
		{
			Error(ex);
		}
	}

	private void EditQuests()
	{
		if (doc == null)
		{
			return;
		}
		try
		{
			using (QuestProgressDialog questProgressDialog = new QuestProgressDialog(doc))
			{
				if (questProgressDialog.ShowDialog(this) != DialogResult.OK)
				{
					return;
				}
				bool flag = false;
				foreach (QuestEdit edit in questProgressDialog.Edits)
				{
					flag = SaveQuestProgress.SetQuestState(doc, edit.QuestId, edit.State) || flag;
				}
				ProgressChanged(flag, "Quest progress");
			}
		}
		catch (Exception ex)
		{
			Error(ex);
		}
	}

	private void EditVillagers()
	{
		if (doc == null)
		{
			return;
		}
		try
		{
			using (VillagerProgressDialog villagerProgressDialog = new VillagerProgressDialog(doc))
			{
				if (villagerProgressDialog.ShowDialog(this) != DialogResult.OK)
				{
					return;
				}
				bool flag = false;
				foreach (VillagerEdit edit in villagerProgressDialog.Edits)
				{
					flag = SaveQuestProgress.SetVillagerUnlocked(doc, edit.Definition, edit.Unlocked) || flag;
				}
				ProgressChanged(flag, "Villager unlocks");
			}
		}
		catch (Exception ex)
		{
			Error(ex);
		}
	}

	private void Discover(SaveDocument d)
	{
		foreach (J value in d.Entries.Values)
		{
			if (SaveDocument.Gear(value))
			{
				string signature = SaveDocument.Tag(value) + "|" + SaveDocument.Data(value)["RarityTag"].Text;
				if (!templates.Any((J t) => SaveDocument.Tag(t) + "|" + SaveDocument.Data(t)["RarityTag"].Text == signature))
				{
					templates.Add(value.Copy());
				}
			}
			foreach (J value2 in SaveDocument.Data(value)["Effects"].Values)
			{
				foreach (J value3 in value2["EffectsInThisBatch"].Values)
				{
					string signature2 = value2["TypeTag"].Text + "|" + value3.Json();
					if (!effectTemplates.Any((EffectChoice t) => t.Label == signature2))
					{
						effectTemplates.Add(new EffectChoice
						{
							Batch = value2.Copy(),
							Effect = value3.Copy(),
							Label = signature2
						});
					}
				}
			}
		}
	}

	private void Learn()
	{
		OpenFileDialog openFileDialog = new OpenFileDialog();
		openFileDialog.Filter = "Dungeons II save (*.sav)|*.sav";
		openFileDialog.Title = "Learn effects without modifying this save";
		using (OpenFileDialog openFileDialog2 = openFileDialog)
		{
			if (openFileDialog2.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			try
			{
				SaveDocument d = SaveDocument.Load(openFileDialog2.FileName);
				Discover(d);
				status.Text = "Effect library expanded · " + effectTemplates.Count + " observed effect variants.";
				if (selected != null)
				{
					SelectEntry();
				}
				Enable();
			}
			catch (Exception ex)
			{
				Error(ex);
			}
		}
	}

	private bool Export()
	{
		if (doc == null)
		{
			return false;
		}
		string text = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.UserProfile), "Downloads");
		SaveFileDialog saveFileDialog = new SaveFileDialog();
		saveFileDialog.Filter = "Dungeons II save (*.sav)|*.sav";
		saveFileDialog.DefaultExt = "sav";
		saveFileDialog.AddExtension = true;
		saveFileDialog.OverwritePrompt = true;
		saveFileDialog.FileName = Path.GetFileName(doc.SourcePath);
		saveFileDialog.InitialDirectory = (Directory.Exists(text) ? text : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile));
		saveFileDialog.Title = "Export edited character save";
		using (SaveFileDialog saveFileDialog2 = saveFileDialog)
		{
			if (saveFileDialog2.ShowDialog(this) != DialogResult.OK)
			{
				return false;
			}
			try
			{
				doc.Export(saveFileDialog2.FileName);
				exported = true;
				Text = "Dungeons II Save Editor";
				status.Text = "Exported .sav: " + saveFileDialog2.FileName;
				return true;
			}
			catch (Exception ex)
			{
				Error(ex);
				return false;
			}
		}
	}

	private void RefreshInventory(J keep)
	{
		RefreshEquippedFilters();
		loading = true;
		inventory.Items.Clear();
		if (doc != null)
		{
			foreach (J item in doc.Entries.Values.Where(SaveDocument.Gear))
			{
				if ((showMerchant.Checked || !SaveDocument.Merchant(item)) && (!(inventoryFilter != "All") || !((inventoryFilter.Length != 1) ? (ItemArt.Category(item) != inventoryFilter) : (ItemArt.Category(item) != "Armor" || ItemArt.ArmorSlot(item) != inventoryFilter))))
				{
					string text = SaveDocument.Name(SaveDocument.Tag(item)) + " · " + SaveDocument.Name(SaveDocument.Data(item)["RarityTag"].Text);
					if (ItemArt.Category(item) == "Armor" && ItemArt.ArmorSlot(item).Length > 0)
					{
						text = "[" + ItemArt.ArmorSlot(item) + "] " + text;
					}
					if (SaveDocument.Merchant(item))
					{
						text += " [shop]";
					}
					else if (item["EquippedSlot"].Text != "None")
					{
						text += " [equipped]";
					}
					EntryChoice entryChoice = new EntryChoice();
					entryChoice.Entry = item;
					entryChoice.Label = text;
					EntryChoice entryChoice2 = entryChoice;
					inventory.Items.Add(entryChoice2);
					if (item == keep)
					{
						inventory.SelectedItem = entryChoice2;
					}
				}
			}
		}
		if (inventory.SelectedIndex < 0 && inventory.Items.Count > 0)
		{
			inventory.SelectedIndex = 0;
		}
		loading = false;
		SelectEntry();
	}

	private void SelectEntry()
	{
		selected = ((inventory.SelectedItem == null) ? null : ((EntryChoice)inventory.SelectedItem).Entry);
		loading = true;
		rarity.Items.Clear();
		effects.Items.Clear();
		if (selected == null)
		{
			title.Text = "Select an item";
			tag.Text = "";
			slot.Text = "";
			power.Enabled = false;
		}
		else
		{
			J j = SaveDocument.Data(selected);
			title.Text = SaveDocument.Name(j["TypeTag"].Text);
			tag.Text = j["TypeTag"].Text;
			slot.Text = "Rarity: " + SaveDocument.Name(j["RarityTag"].Text) + "   ·   Slot: " + selected["EquippedSlot"].Text;
			foreach (string item in (from t in templates
				select SaveDocument.Data(t)["RarityTag"].Text into r
				where r != "SW.Rarity.None"
				select r).Concat(new string[4]
			{
				"SW.Rarity.Common",
				"SW.Rarity.Rare",
				"SW.Rarity.Unique",
				j["RarityTag"].Text
			}).Distinct())
			{
				rarity.Items.Add(item);
			}
			rarity.SelectedItem = j["RarityTag"].Text;
			decimal number = j["GeneratorData"]["PowerGeneratorValues"]["ItemPower"].Number;
			power.Minimum = Math.Min(-1m, number);
			power.Maximum = Math.Max(1000000m, number);
			power.Value = number;
			power.Enabled = true;
			FillEffects();
		}
		loading = false;
		Enable();
	}

	private void FillEffects()
	{
		effects.Items.Clear();
		if (selected == null)
		{
			return;
		}
		foreach (J value in SaveDocument.Data(selected)["Effects"].Values)
		{
			foreach (J value2 in value["EffectsInThisBatch"].Values)
			{
				effects.Items.Add(new EffectChoice
				{
					Batch = value,
					Effect = value2,
					Label = EffectLabel(value, value2)
				});
			}
		}
	}

	private string EffectLabel(J batch, J effect)
	{
		EffectDefinition effectDefinition = EffectCatalog.Find(effect["GeneratorData"]["GeneratorParentTemplate"].Text, batch["TypeTag"].Text);
		return ((effectDefinition == null) ? SaveDocument.Name(effect["TypeTag"].Text) : effectDefinition.Name) + " · intensity " + effect["Intensity"].Raw + " · " + SaveDocument.Name(batch["TypeTag"].Text) + " · " + effect["GeneratorData"]["GeneratorParentTemplate"].Text.Split('.').Last();
	}

	private Form Dialog(string text, int height)
	{
		Form form = new Form();
		form.Text = text;
		form.ClientSize = new Size(670, height);
		form.StartPosition = FormStartPosition.CenterParent;
		form.Opacity = 1.0;
		form.FormBorderStyle = FormBorderStyle.FixedDialog;
		form.MaximizeBox = false;
		form.MinimizeBox = false;
		form.BackColor = bg;
		form.ForeColor = Color.White;
		form.Font = Font;
		return form;
	}

	private void Create()
	{
		if (doc == null)
		{
			return;
		}
		using (ItemPicker itemPicker = new ItemPicker(EquipmentCatalog.Templates(doc), doc.Entries.Values))
		{
			if (itemPicker.ShowDialog(this) == DialogResult.OK)
			{
				J keep = doc.AddFrom(itemPicker.SelectedTemplate);
				Changed();
				RefreshInventory(keep);
			}
		}
	}

	private void Duplicate()
	{
		if (selected != null)
		{
			J keep = doc.AddFrom(selected);
			Changed();
			RefreshInventory(keep);
		}
	}

	private void Delete()
	{
		if (selected != null)
		{
			if (selected["EquippedSlot"].Text != "None")
			{
				MessageBox.Show(this, "Unequip this item in the game first. Equipped entries cannot be deleted in this build.", "Item is equipped");
			}
			else if (MessageBox.Show(this, "Remove this item from the exported inventory?", "Delete item", MessageBoxButtons.YesNo) == DialogResult.Yes)
			{
				doc.Entries.Remove(selected);
				Changed();
				RefreshInventory(null);
			}
		}
	}

	private void RemoveEffect()
	{
		EffectChoice effectChoice = effects.SelectedItem as EffectChoice;
		if (effectChoice != null)
		{
			effectChoice.Batch["EffectsInThisBatch"].Remove(effectChoice.Effect);
			if (effectChoice.Batch["EffectsInThisBatch"].Values.Count == 0)
			{
				SaveDocument.Data(selected)["Effects"].Remove(effectChoice.Batch);
			}
			Changed();
			FillEffects();
		}
	}

	private void EditEffect()
	{
		EffectChoice effectChoice = effects.SelectedItem as EffectChoice;
		if (effectChoice == null)
		{
			return;
		}
		Form d = Dialog("Edit effect parameters", 388);
		try
		{
			L(effectChoice.Effect["TypeTag"].Text, 18, 15, 635, 30, d, 12);
			L("Raw game values; these are not verified enchantment-level controls.", 18, 54, 635, 42, d, 10);
			Dictionary<string, TextBox> fields = new Dictionary<string, TextBox>();
			int num = 105;
			string[] array = new string[3] { "Intensity", "Quality", "EnchantmentPointsInvested" };
			foreach (string key in array)
			{
				L(key, 18, num, 290, 26, d, 10);
				TextBox textBox = new TextBox();
				textBox.Location = new Point(317, num);
				textBox.Width = 330;
				textBox.Text = effectChoice.Effect[key].Raw;
				TextBox textBox2 = textBox;
				Input(textBox2);
				d.Controls.Add(textBox2);
				fields.Add(key, textBox2);
				num += 43;
			}
			L("Generator template (preserved)", 18, 240, 630, 28, d, 10);
			L(effectChoice.Effect["GeneratorData"]["GeneratorParentTemplate"].Text, 18, 270, 630, 28, d, 10);
			Dictionary<string, decimal> values = new Dictionary<string, decimal>();
			B("Apply", 463, 328, 185, d, delegate
			{
				values.Clear();
				foreach (KeyValuePair<string, TextBox> item in fields)
				{
					decimal result;
					if (!decimal.TryParse(item.Value.Text, NumberStyles.Float, CultureInfo.InvariantCulture, out result) || (item.Key == "EnchantmentPointsInvested" && (result < 0m || decimal.Truncate(result) != result)))
					{
						MessageBox.Show(d, "Enter valid numbers. Invested points must be a nonnegative integer.");
						return;
					}
					values[item.Key] = result;
				}
				d.DialogResult = DialogResult.OK;
			});
			if (d.ShowDialog(this) != DialogResult.OK)
			{
				return;
			}
			bool flag = false;
			foreach (KeyValuePair<string, decimal> item2 in values)
			{
				if (effectChoice.Effect[item2.Key].Number != item2.Value)
				{
					effectChoice.Effect[item2.Key] = J.Num(item2.Value);
					flag = true;
				}
			}
			if (flag)
			{
				Changed();
				FillEffects();
			}
		}
		finally
		{
			if (d != null)
			{
				((IDisposable)d).Dispose();
			}
		}
	}

	private void Error(Exception ex)
	{
		MessageBox.Show(this, ex.Message, "Could not complete operation", MessageBoxButtons.OK, MessageBoxIcon.Hand);
	}

	[STAThread]
	public static int Main(string[] args)
	{
		Application.EnableVisualStyles();
		Application.SetCompatibleTextRenderingDefault(false);
		if (args.Length > 0 && args[0] == "--test")
		{
			return Tests.Run(args);
		}
		if (args.Length > 0 && args[0] == "--mod-test")
		{
			return Tests.RunModTest(args);
		}
		if (args.Length > 0 && args[0] == "--loading-test")
		{
			return Tests.RunLoadingTest(args);
		}
		using (SaveEditor saveEditor = new SaveEditor())
		{
			if (args.Length > 0)
			{
				try
				{
					saveEditor.LoadFile(args[0]);
				}
				catch (Exception ex)
				{
					MessageBox.Show(ex.Message, "Could not open save");
				}
			}
			Application.Run(saveEditor);
		}
		return 0;
	}
}


internal static class VignettePaint
{
	public static void DrawSurface(Graphics g, Rectangle r, Color baseColor, int depth)
	{
		if (r.Width < 2 || r.Height < 2)
		{
			return;
		}
	Color edge = Color.FromArgb(Math.Max(0, baseColor.R - depth), Math.Max(0, baseColor.G - depth), Math.Max(0, baseColor.B - depth));
		using (GraphicsPath path = new GraphicsPath())
		{
			path.AddRectangle(r);
			using (PathGradientBrush brush = new PathGradientBrush(path))
			{
				brush.CenterColor = baseColor;
				brush.SurroundColors = new Color[1] { edge };
				brush.CenterPoint = new PointF(r.Left + r.Width / 2f, r.Top + r.Height / 2f);
				g.FillRectangle(brush, r);
			}
		}
	}

	public static void Draw(Graphics g, Rectangle r, int edgeAlpha)
	{
		if (r.Width < 2 || r.Height < 2)
		{
			return;
		}
		try
		{
			using (GraphicsPath path = new GraphicsPath())
			{
				path.AddRectangle(r);
				using (PathGradientBrush brush = new PathGradientBrush(path))
				{
					brush.CenterColor = Color.FromArgb(0, 0, 0, 0);
					brush.SurroundColors = new Color[1] { Color.FromArgb(edgeAlpha, 0, 0, 0) };
					brush.CenterPoint = new PointF(r.Left + r.Width / 2f, r.Top + r.Height / 2f);
					g.FillRectangle(brush, r);
				}
			}
		}
		catch
		{
		}
	}
}


internal sealed class HoverPictureBox : PictureBox
{
	private readonly Timer hoverTimer = new Timer();
	private float scale = 0.72f;
	private bool hovered;

	public HoverPictureBox()
	{
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
		BackColor = Color.Transparent;
		Cursor = Cursors.Hand;
		hoverTimer.Interval = 15;
		hoverTimer.Tick += delegate
		{
			float target = hovered ? 1f : 0.72f;
			scale += (target - scale) * 0.30f;
			if (Math.Abs(target - scale) < 0.006f)
			{
				scale = target;
				hoverTimer.Stop();
			}
			Invalidate();
		};
		Disposed += delegate { hoverTimer.Stop(); hoverTimer.Dispose(); };
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		hovered = true;
		hoverTimer.Start();
		base.OnMouseEnter(e);
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		hovered = false;
		hoverTimer.Start();
		base.OnMouseLeave(e);
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		SaveEditor owner = FindForm() as SaveEditor;
		if (owner == null)
		{
			base.OnPaintBackground(e);
		}
		else
		{
			owner.PaintHoverBackdrop(this, e.Graphics);
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		if (Image == null)
		{
			base.OnPaint(e);
			return;
		}
		float fit = Math.Min((float)ClientSize.Width / Image.Width, (float)ClientSize.Height / Image.Height) * scale;
		int width = Math.Max(1, (int)Math.Round(Image.Width * fit));
		int height = Math.Max(1, (int)Math.Round(Image.Height * fit));
		Rectangle destination = new Rectangle((ClientSize.Width - width) / 2, (ClientSize.Height - height) / 2, width, height);
		e.Graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
		e.Graphics.DrawImage(Image, destination);
	}
}


internal sealed class HoverTextLabel : Label
{
	private readonly Timer hoverTimer = new Timer();
	private float scale = 1f;
	private bool hovered;

	public HoverTextLabel()
	{
		SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.SupportsTransparentBackColor, true);
		BackColor = Color.Transparent;
		hoverTimer.Interval = 15;
		hoverTimer.Tick += delegate
		{
			float target = hovered ? 1.12f : 1f;
			scale += (target - scale) * 0.30f;
			if (Math.Abs(target - scale) < 0.006f)
			{
				scale = target;
				hoverTimer.Stop();
			}
			Invalidate();
		};
		Disposed += delegate { hoverTimer.Stop(); hoverTimer.Dispose(); };
	}

	protected override void OnMouseEnter(EventArgs e)
	{
		hovered = true;
		hoverTimer.Start();
		base.OnMouseEnter(e);
	}

	protected override void OnMouseLeave(EventArgs e)
	{
		hovered = false;
		hoverTimer.Start();
		base.OnMouseLeave(e);
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		SaveEditor owner = FindForm() as SaveEditor;
		if (owner == null)
		{
			base.OnPaintBackground(e);
		}
		else
		{
			owner.PaintHoverBackdrop(this, e.Graphics);
		}
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		using (Font paintFont = new Font(Font.FontFamily, Font.Size * scale, Font.Style))
		{
			TextFormatFlags flags = TextFormatFlags.SingleLine | TextFormatFlags.NoPadding | TextFormatFlags.EndEllipsis | TextFormatFlags.NoPrefix;
			switch (TextAlign)
			{
				case ContentAlignment.TopCenter: flags |= TextFormatFlags.HorizontalCenter | TextFormatFlags.Top; break;
				case ContentAlignment.TopRight: flags |= TextFormatFlags.Right | TextFormatFlags.Top; break;
				case ContentAlignment.MiddleLeft: flags |= TextFormatFlags.Left | TextFormatFlags.VerticalCenter; break;
				case ContentAlignment.MiddleCenter: flags |= TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter; break;
				case ContentAlignment.MiddleRight: flags |= TextFormatFlags.Right | TextFormatFlags.VerticalCenter; break;
				case ContentAlignment.BottomLeft: flags |= TextFormatFlags.Left | TextFormatFlags.Bottom; break;
				case ContentAlignment.BottomCenter: flags |= TextFormatFlags.HorizontalCenter | TextFormatFlags.Bottom; break;
				case ContentAlignment.BottomRight: flags |= TextFormatFlags.Right | TextFormatFlags.Bottom; break;
				default: flags |= TextFormatFlags.Left | TextFormatFlags.Top; break;
			}
			TextRenderer.DrawText(e.Graphics, Text, paintFont, ClientRectangle, ForeColor, flags);
		}
	}
}


internal sealed class HoverGrow
{
	private readonly Control control;
	private readonly Timer timer = new Timer();
	private Rectangle home;
	private readonly Font baseFont;
	private Font animatedFont;
	private readonly bool animateText;
	private float scale = 1f;
	private bool hovered;
	private readonly float amount;

	private HoverGrow(Control target, float growAmount)
	{
		control = target;
		amount = growAmount;
		home = target.Bounds;
		animateText = target is Label;
		if (animateText)
			baseFont = new Font(target.Font, target.Font.Style);
		timer.Interval = 15;
		timer.Tick += Animate;
		target.MouseEnter += delegate
		{
			if (!timer.Enabled)
				home = target.Bounds;
			hovered = true;
			target.BringToFront();
			timer.Start();
		};
		target.MouseLeave += delegate
		{
			hovered = false;
			timer.Start();
		};
		target.ParentChanged += delegate
		{
			if (target.Parent == null)
			{
				hovered = false;
				timer.Start();
			}
		};
		EventHandler updateHome = delegate
		{
			if (!timer.Enabled)
				home = target.Bounds;
		};
		target.LocationChanged += updateHome;
		target.SizeChanged += updateHome;
		target.Disposed += delegate
		{
			timer.Stop();
			timer.Dispose();
			if (animatedFont != null)
				animatedFont.Dispose();
			if (baseFont != null)
				baseFont.Dispose();
		};
	}

	public static void Attach(Control control, float amount = 1.08f)
	{
		if (control != null)
			new HoverGrow(control, amount);
	}

	private void Animate(object sender, EventArgs e)
	{
		float target = hovered ? amount : 1f;
		scale += (target - scale) * 0.30f;
		if (Math.Abs(target - scale) < 0.006f)
		{
			scale = target;
			timer.Stop();
		}
		if (animateText)
		{
			Font next = new Font(baseFont.FontFamily, baseFont.Size * scale, baseFont.Style);
			Font previous = animatedFont;
			animatedFont = next;
			control.Font = next;
			if (previous != null)
				previous.Dispose();
		}
		else
		{
			int width = (int)Math.Round(home.Width * scale);
			int height = (int)Math.Round(home.Height * scale);
			control.Bounds = new Rectangle(home.Left + (home.Width - width) / 2, home.Top + (home.Height - height) / 2, width, height);
		}
	}
}


internal sealed class TintDisabledButton : Button
{
	public TintDisabledButton()
	{
		SetStyle(ControlStyles.SupportsTransparentBackColor, true);
		BackColor = Color.Transparent;
		FlatStyle = FlatStyle.Flat;
		FlatAppearance.BorderSize = 0;
		FlatAppearance.BorderColor = Color.FromArgb(24, 43, 57);
		FlatAppearance.MouseOverBackColor = Color.Transparent;
	}

	protected override void OnPaintBackground(PaintEventArgs e)
	{
		if (Enabled)
		{
			base.OnPaintBackground(e);
		}
		VignettePaint.Draw(e.Graphics, base.ClientRectangle, 16);
	}

	protected override void OnPaint(PaintEventArgs e)
	{
		base.OnPaint(e);
	}
}


internal sealed class InventoryListBox : ListBox
{
	public Color Tint = Color.FromArgb(57, 63, 70);
	public Action<Graphics> PaintBackdrop;
	private readonly Timer hoverTimer = new Timer();
	private int hoveredIndex = -1;
	private int animatingIndex = -1;
	private float hoverScale = 1f;
	public float HoverScale(int index) { return index == hoveredIndex ? hoverScale : 1f; }

	public InventoryListBox()
	{
		hoverTimer.Interval = 15;
		hoverTimer.Tick += delegate
		{
			float target = hoveredIndex >= 0 ? 1.22f : 1f;
			hoverScale += (target - hoverScale) * 0.30f;
			if (Math.Abs(target - hoverScale) < 0.008f)
			{
				hoverScale = target;
				hoverTimer.Stop();
			}
			if (animatingIndex >= 0 && animatingIndex < Items.Count)
				Invalidate(GetItemRectangle(animatingIndex));
			if (!hoverTimer.Enabled && hoveredIndex < 0)
				animatingIndex = -1;
		};
		MouseMove += delegate(object sender, MouseEventArgs e)
		{
			int index = IndexFromPoint(e.Location);
			if (index != hoveredIndex)
			{
				int previous = hoveredIndex;
				hoveredIndex = index;
				animatingIndex = index >= 0 ? index : previous;
				if (previous >= 0 && previous < Items.Count)
					Invalidate(GetItemRectangle(previous));
				if (index >= 0)
					hoverScale = 1f;
				hoverTimer.Start();
			}
		};
		MouseLeave += delegate { animatingIndex = hoveredIndex; hoveredIndex = -1; hoverTimer.Start(); };
		Disposed += delegate { hoverTimer.Stop(); hoverTimer.Dispose(); };
	}

	protected override void WndProc(ref Message m)
	{
		if (m.Msg == 20 && m.WParam != IntPtr.Zero)
		{
			if (hoverTimer.Enabled || hoveredIndex >= 0)
			{
				m.Result = (IntPtr)1;
				return;
			}
			try
			{
				using (Graphics graphics = Graphics.FromHdc(m.WParam))
				{
					if (PaintBackdrop != null)
					{
						PaintBackdrop(graphics);
					}
					else
					{
						graphics.Clear(Tint);
					}
				}
			}
			catch
			{
			}
			m.Result = (IntPtr)1;
		}
		else
		{
			base.WndProc(ref m);
		}
	}
}


