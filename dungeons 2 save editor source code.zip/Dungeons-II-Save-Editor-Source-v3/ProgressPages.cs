using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

static class ProgressPageStyle {
 public static readonly Color Background=Color.FromArgb(18,23,30),Surface=Color.FromArgb(29,37,48),Muted=Color.FromArgb(167,185,204),Mint=Color.FromArgb(111,230,190),Blue=Color.FromArgb(57,119,190);
 public static Label Label(string text,Point location,Size size,Control parent,int fontSize=10,Color? color=null){var label=new Label(){Text=text,Location=location,Size=size,ForeColor=color??Muted,Font=new Font("Segoe UI",fontSize)};parent.Controls.Add(label);return label;}
 public static Button Button(string text,Point location,Size size,Control parent,EventHandler click){var button=new Button(){Text=text,Location=location,Size=size,BackColor=Surface,ForeColor=Color.White,FlatStyle=FlatStyle.Flat};button.FlatAppearance.BorderColor=Color.FromArgb(62,79,95);button.Click+=click;parent.Controls.Add(button);return button;}
 public static ListBox List(Point location,Size size,Control parent){var list=new ListBox(){Location=location,Size=size,Anchor=AnchorStyles.Top|AnchorStyles.Bottom|AnchorStyles.Left|AnchorStyles.Right,BorderStyle=BorderStyle.None,BackColor=Surface,ForeColor=Color.White,IntegralHeight=false};parent.Controls.Add(list);return list;}
}

public sealed class AchievementsPage : UserControl {
 readonly SaveDocument document;readonly Action<bool,string> changed;readonly CheckedListBox list=new CheckedListBox();readonly List<AchievementChoice> choices;Button unlock;Label note;bool bulk;
 public int ItemCount {get{return list.Items.Count;}}
 public AchievementsPage(SaveDocument document,Action<bool,string> changed){this.document=document;this.changed=changed;BackColor=ProgressPageStyle.Background;choices=SaveProgression.Choices(document);
  ProgressPageStyle.Label("ACHIEVEMENTS",new Point(24,18),new Size(520,32),this,18,Color.White);
  ProgressPageStyle.Label("Check an achievement to complete it, or uncheck it to clear its progress.",new Point(24,56),new Size(740,24),this,9);
  unlock=ProgressPageStyle.Button("Unlock all",new Point(0,48),new Size(116,36),this,(s,e)=>UnlockAll());
  list.Location=new Point(24,96);list.Size=new Size(300,200);list.BorderStyle=BorderStyle.None;list.BackColor=ProgressPageStyle.Surface;list.ForeColor=Color.White;list.Font=new Font("Segoe UI",10);list.CheckOnClick=true;list.IntegralHeight=false;foreach(var choice in choices)list.Items.Add(choice,choice.IsComplete);list.ItemCheck+=(s,e)=>{if(bulk)return;bool changedValue=SaveProgression.SetComplete(document,choices[e.Index].Definition,e.NewValue==CheckState.Checked);if(changedValue)changed(true,"Achievements");};Controls.Add(list);
  note=ProgressPageStyle.Label("Changes apply to this save in the editor. Export the .sav when you're done.",new Point(24,0),new Size(400,24),this,9);Resize+=(s,e)=>LayoutPage();LayoutPage();
 }
 void LayoutPage(){unlock.Left=Width-140;list.SetBounds(24,96,Math.Max(300,Width-48),Math.Max(200,Height-162));note.SetBounds(24,Height-48,Math.Max(400,Width-48),24);}
 void UnlockAll(){bulk=true;for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,true);bulk=false;bool any=false;foreach(var choice in choices)any=SaveProgression.SetComplete(document,choice.Definition,true)||any;if(any)changed(true,"Achievements");}
}

public sealed class QuestsPage : UserControl {
 readonly SaveDocument document;readonly Action<bool,string> changed;readonly ListBox quests;readonly ComboBox state=new ComboBox();readonly Label stateNote;readonly Panel details;readonly Dictionary<string,Button> filters=new Dictionary<string,Button>();readonly string[] filterNames={"All","Main","Side"};string filter="All";bool updating;
 public int ItemCount {get{return quests.Items.Count;}}
 public QuestsPage(SaveDocument document,Action<bool,string> changed){this.document=document;this.changed=changed;BackColor=ProgressPageStyle.Background;
  ProgressPageStyle.Label("QUESTS",new Point(24,18),new Size(500,32),this,18,Color.White);
  ProgressPageStyle.Label("Browse all 44 quests in campaign order. Choose a status or set one as your current quest.",new Point(24,56),new Size(900,24),this,9);
  ProgressPageStyle.Label("FILTER QUESTS",new Point(24,101),new Size(250,24),this,11,ProgressPageStyle.Mint);int x=24;foreach(string name in filterNames){string captured=name;int width=name=="All"?86:112;var button=ProgressPageStyle.Button("["+name.ToLowerInvariant()+"]",new Point(x,128),new Size(width,36),this,(s,e)=>SetFilter(captured));filters[name]=button;x+=width+10;}
  quests=ProgressPageStyle.List(new Point(24,176),new Size(Width-430,Math.Max(220,Height-214)),this);quests.SelectedIndexChanged+=(s,e)=>SelectQuest();
  details=new Panel(){Location=new Point(0,176),Size=new Size(346,220),BackColor=ProgressPageStyle.Surface,Padding=new Padding(18)};Controls.Add(details);
  ProgressPageStyle.Label("SELECTED QUEST",new Point(18,18),new Size(300,26),details,12,ProgressPageStyle.Mint);
  stateNote=ProgressPageStyle.Label("Select a quest to view its status.",new Point(18,56),new Size(300,58),details,10,Color.White);
  ProgressPageStyle.Label("QUEST STATUS",new Point(18,132),new Size(300,22),details,9);
  state.DropDownStyle=ComboBoxStyle.DropDownList;state.Items.AddRange(new object[]{"Unavailable","Available","Active","Completed"});state.SetBounds(18,160,300,32);state.BackColor=ProgressPageStyle.Surface;state.ForeColor=Color.White;details.Controls.Add(state);state.SelectedIndexChanged+=(s,e)=>{if(updating)return;var quest=quests.SelectedItem as QuestChoice;if(quest==null||state.SelectedItem==null)return;SetState(quest,(string)state.SelectedItem);};
  ProgressPageStyle.Button("Set as current quest",new Point(18,207),new Size(300,38),details,(s,e)=>{var quest=quests.SelectedItem as QuestChoice;if(quest!=null)SetState(quest,"Active");});
  ProgressPageStyle.Label("A quest marked Active becomes the character's focused quest. Choosing a status for an untracked quest adds it to the save.",new Point(18,267),new Size(300,100),details,9);
  Resize+=(s,e)=>LayoutPage();SetFilter("All");LayoutPage();
 }
 void LayoutPage(){int height=Math.Max(220,Height-214);quests.SetBounds(24,176,Math.Max(300,Width-430),height);details.SetBounds(Width-370,176,346,height);}
 void SetFilter(string value){filter=value;foreach(var pair in filters)pair.Value.BackColor=pair.Key==filter?ProgressPageStyle.Blue:ProgressPageStyle.Surface;RefreshQuests(null);}
 void RefreshQuests(string keepId){string selectedId=keepId??(quests.SelectedItem as QuestChoice==null?null:((QuestChoice)quests.SelectedItem).Id);updating=true;quests.BeginUpdate();quests.Items.Clear();foreach(var quest in SaveQuestProgress.Quests(document,filter)){quests.Items.Add(quest);if(quest.Id==selectedId)quests.SelectedItem=quest;}quests.EndUpdate();if(quests.SelectedIndex<0&&quests.Items.Count>0)quests.SelectedIndex=0;updating=false;SelectQuest();}
 void SelectQuest(){var quest=quests.SelectedItem as QuestChoice;updating=true;if(quest==null){stateNote.Text="Select a quest to view its status.";state.SelectedIndex=-1;}else{stateNote.Text=quest.Name+"\n"+(quest.Definition.Category=="Main"?"Main quest":"Side quest")+"\nCurrent status: "+quest.State;state.SelectedItem=quest.State=="Not tracked"?null:quest.State;}updating=false;}
 void SetState(QuestChoice quest,string value){bool didChange=SaveQuestProgress.SetQuestState(document,quest.Id,value);RefreshQuests(quest.Id);if(didChange)changed(true,"Quest progress");}
}

public sealed class VillagersPage : UserControl {
 readonly SaveDocument document;readonly Action<bool,string> changed;readonly CheckedListBox list=new CheckedListBox();readonly List<VillagerChoice> choices;Label note;
 public int ItemCount {get{return list.Items.Count;}}
 public VillagersPage(SaveDocument document,Action<bool,string> changed){this.document=document;this.changed=changed;BackColor=ProgressPageStyle.Background;choices=SaveQuestProgress.Villagers(document);
  ProgressPageStyle.Label("MERCHANTS & VILLAGERS",new Point(24,18),new Size(700,32),this,18,Color.White);
  ProgressPageStyle.Label("Choose which merchants and villagers are unlocked and available to talk to.",new Point(24,56),new Size(850,24),this,9);
  list.Location=new Point(24,96);list.Size=new Size(380,220);list.BorderStyle=BorderStyle.None;list.BackColor=ProgressPageStyle.Surface;list.ForeColor=Color.White;list.Font=new Font("Segoe UI",10);list.CheckOnClick=true;list.IntegralHeight=false;foreach(var choice in choices)list.Items.Add(choice,choice.Unlocked);list.ItemCheck+=(s,e)=>{bool unlocked=e.NewValue==CheckState.Checked;bool didChange=SaveQuestProgress.SetVillagerUnlocked(document,choices[e.Index].Definition,unlocked);if(didChange)changed(true,"Villager unlocks");};Controls.Add(list);
  note=ProgressPageStyle.Label("Unlocks use the game's quest and objective flags. Changes apply to this save in the editor. Export the .sav when you're done.",new Point(24,0),new Size(400,64),this,9);Resize+=(s,e)=>LayoutPage();LayoutPage();
 }
 void LayoutPage(){list.SetBounds(24,96,Math.Max(380,Width-48),Math.Max(200,Height-206));note.SetBounds(24,Height-88,Math.Max(400,Width-48),64);}
}
