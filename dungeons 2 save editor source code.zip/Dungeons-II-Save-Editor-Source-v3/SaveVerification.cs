using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web.Script.Serialization;

public sealed class SaveReceipt {
 public string Target {get;set;} public string CharacterId {get;set;} public string WrittenUtc {get;set;}
 public Dictionary<string,int> Items {get;set;}
}
public static class SaveVerification {
 public static Dictionary<string,int> Counts(SaveDocument doc){return doc.Entries.Values.GroupBy(SaveDocument.Tag,StringComparer.OrdinalIgnoreCase).ToDictionary(g=>g.Key,g=>g.Count(),StringComparer.OrdinalIgnoreCase);}
 public static void VerifyBytes(string path,byte[] expected){if(!File.ReadAllBytes(path).SequenceEqual(expected))throw new IOException("The destination file does not match your edits after writing. Another program may have replaced it. Retry the export to the chosen .sav path.");SaveDocument.Load(path);}
 public static void Record(string path,SaveDocument doc,string receiptPath){var receipt=new SaveReceipt(){Target=Path.GetFullPath(path),CharacterId=GameSaveInstaller.CharacterId(doc),WrittenUtc=DateTime.UtcNow.ToString("O"),Items=Counts(doc)};File.WriteAllText(receiptPath,new JavaScriptSerializer().Serialize(receipt));}
 public static string Check(string receiptPath){if(!File.Exists(receiptPath))return "No prior export receipt exists for checking this save.";var receipt=new JavaScriptSerializer().Deserialize<SaveReceipt>(File.ReadAllText(receiptPath));var actual=SaveDocument.Load(receipt.Target);if(GameSaveInstaller.CharacterId(actual)!=receipt.CharacterId)throw new IOException("The save at this path now belongs to another character.");var counts=Counts(actual);var missing=new List<string>();foreach(var pair in receipt.Items){int count;counts.TryGetValue(pair.Key,out count);if(count<pair.Value)missing.Add((pair.Value-count)+" × "+SaveDocument.Name(pair.Key)+" ("+pair.Key+")");}return "Checked: "+receipt.Target+"\nApplied at: "+receipt.WrittenUtc+"\n\n"+(missing.Count==0?"All item types and quantities from the applied save are still present. This checks the file; it does not confirm visibility in the game.":"These items are now missing compared with the applied save:\n"+string.Join("\n",missing))+"\n\nCurrent inventory: "+actual.Entries.Values.Count+" entries.";}
}
