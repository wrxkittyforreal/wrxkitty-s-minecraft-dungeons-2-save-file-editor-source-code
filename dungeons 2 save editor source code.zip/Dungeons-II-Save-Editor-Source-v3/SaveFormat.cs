﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Script.Serialization;

// Keep original JSON tokens, including 64-bit numbers and floating-point spelling.
// Unchanged nodes serialize verbatim, rather than passing through floating point.
public sealed class J {
 public string Raw; public char Kind; public bool Changed;
 public Dictionary<string,J> Fields; public List<string> Keys; public List<J> Values;
 static readonly JavaScriptSerializer Strings = new JavaScriptSerializer();
 public J this[string key] {get {if(Fields==null||!Fields.ContainsKey(key))throw new FormatException("Missing field: "+key);return Fields[key];} set {if(Fields==null)throw new FormatException("Expected an object.");if(!Fields.ContainsKey(key))Keys.Add(key);Fields[key]=value;Changed=true;}}
 public bool Has(string key){return Fields!=null&&Fields.ContainsKey(key);}
 public string Text {get {if(Kind!='s')throw new FormatException("Expected a text value.");return Strings.Deserialize<string>(Raw);}}
 public decimal Number {get {if(Kind!='n')throw new FormatException("Expected a number.");return decimal.Parse(Raw,NumberStyles.Float,CultureInfo.InvariantCulture);}}
 public bool Dirty {get {return Changed||(Fields!=null&&Fields.Values.Any(v=>v.Dirty))||(Values!=null&&Values.Any(v=>v.Dirty));}}
 public string Json(){if(!Dirty)return Raw;if(Kind=='o')return "{"+string.Join(",",Keys.Select(k=>Strings.Serialize(k)+":"+Fields[k].Json()))+"}";if(Kind=='a')return "["+string.Join(",",Values.Select(v=>v.Json()))+"]";return Raw;}
 public J Copy(){return Parse(Json());}
 public void Add(J value){if(Kind!='a')throw new FormatException("Expected array.");Values.Add(value);Changed=true;}
 public void Remove(J value){if(Values.Remove(value))Changed=true;}
 public static J Str(string value){return new J(){Kind='s',Raw=Strings.Serialize(value),Changed=true};}
 public static J Num(decimal value){return new J(){Kind='n',Raw=value.ToString(CultureInfo.InvariantCulture),Changed=true};}
 public static J Bool(bool value){return new J(){Kind='b',Raw=value?"true":"false",Changed=true};}
 public static J Parse(string text){return new Parser(text).Read();}
 sealed class Parser {
  readonly string s;int p;int depth;
  public Parser(string text){s=text;}
  void White(){while(p<s.Length&&(s[p]==' '||s[p]=='\n'||s[p]=='\r'||s[p]=='\t'))p++;}
  void Expect(char c){White();if(p>=s.Length||s[p++]!=c)throw new FormatException("Invalid JSON near character "+p);}
  string StringToken(){int start=p;Expect('"');bool done=false;while(p<s.Length){char c=s[p++];if(c=='"'){done=true;break;}if(c<32)throw new FormatException("Invalid JSON string.");if(c=='\\'){if(p>=s.Length)throw new FormatException("Truncated escape.");char e=s[p++];if(e=='u'){if(p+4>s.Length||!Regex.IsMatch(s.Substring(p,4),"^[0-9a-fA-F]{4}$"))throw new FormatException("Invalid Unicode escape.");p+=4;}else if("\"\\/bfnrt".IndexOf(e)<0)throw new FormatException("Invalid escape.");}}if(!done)throw new FormatException("Unterminated string.");return s.Substring(start,p-start);}
  J Value(){White();if(++depth>128)throw new FormatException("Save nesting is too deep.");int start=p;if(p>=s.Length)throw new FormatException("Truncated JSON.");var n=new J();char c=s[p];if(c=='{'){p++;n.Kind='o';n.Fields=new Dictionary<string,J>();n.Keys=new List<string>();White();if(p<s.Length&&s[p]!='}')while(true){White();string k=Strings.Deserialize<string>(StringToken());Expect(':');if(n.Fields.ContainsKey(k))throw new FormatException("Duplicate JSON key: "+k);n.Keys.Add(k);n.Fields.Add(k,Value());White();if(p<s.Length&&s[p]==','){p++;continue;}break;}Expect('}');}else if(c=='['){p++;n.Kind='a';n.Values=new List<J>();White();if(p<s.Length&&s[p]!=']')while(true){n.Values.Add(Value());White();if(p<s.Length&&s[p]==','){p++;continue;}break;}Expect(']');}else if(c=='"'){n.Kind='s';StringToken();}else{while(p<s.Length&&",]} \t\r\n".IndexOf(s[p])<0)p++;string token=s.Substring(start,p-start);if(token=="true"||token=="false")n.Kind='b';else if(token=="null")n.Kind='z';else if(Regex.IsMatch(token,@"^-?(0|[1-9][0-9]*)(\.[0-9]+)?([eE][+-]?[0-9]+)?$"))n.Kind='n';else throw new FormatException("Invalid JSON token.");}n.Raw=s.Substring(start,p-start);depth--;return n;}
  public J Read(){J n=Value();White();if(p!=s.Length)throw new FormatException("Unexpected data after JSON.");return n;}
 }
}
public sealed class SaveDocument {
 public J Root, Entries; public string SourcePath; public byte[] OriginalBytes; string prefix,suffix;bool bom;
 public static SaveDocument Load(string path){byte[] bytes=File.ReadAllBytes(path);if(bytes.Length>64000000)throw new FormatException("Save is too large.");var d=new SaveDocument();d.OriginalBytes=bytes;d.SourcePath=Path.GetFullPath(path);d.bom=bytes.Length>=3&&bytes[0]==239&&bytes[1]==187&&bytes[2]==191;string text=new UTF8Encoding(false,true).GetString(bytes,d.bom?3:0,bytes.Length-(d.bom?3:0));d.Root=J.Parse(text);int start=0;while(start<text.Length&&char.IsWhiteSpace(text[start]))start++;d.prefix=text.Substring(0,start);d.suffix=text.Substring(start+d.Root.Raw.Length);if(d.Root["SerializeMeta"]["HardFormat"].Text!="FCharacterSaveV1"||d.Root["SerializeMeta"]["SoftVersion"].Number!=5)throw new FormatException("Only the observed FCharacterSaveV1 / SoftVersion 5 format is supported.");d.Entries=d.Root["CharacterSaveV1"]["Inventory"]["Entries"];if(d.Entries.Kind!='a')throw new FormatException("Inventory entries must be an array.");d.Validate();return d;}
 public void Validate(){foreach(J e in Entries.Values){J item=e["ItemData"];if(!item["TypeTag"].Text.StartsWith("SW.Item.",StringComparison.OrdinalIgnoreCase)||!item["RarityTag"].Text.StartsWith("SW.Rarity."))throw new FormatException("Invalid item or rarity tag.");if(item["Effects"].Kind!='a')throw new FormatException("Invalid effect list.");foreach(J batch in item["Effects"].Values){if(batch["EffectsInThisBatch"].Kind!='a')throw new FormatException("Invalid effect batch.");foreach(J effect in batch["EffectsInThisBatch"].Values){if(!effect["TypeTag"].Text.StartsWith("SW.Effect.")&&!effect["TypeTag"].Text.StartsWith("SW.Enchantment."))throw new FormatException("Invalid effect tag.");}}}}
 public byte[] Bytes(){Validate();if(!Root.Dirty)return OriginalBytes;byte[] body=new UTF8Encoding(false,true).GetBytes(prefix+Root.Json()+suffix);if(!bom)return body;return new byte[]{239,187,191}.Concat(body).ToArray();}
 public void Export(string path){path=Path.GetFullPath(path);byte[] bytes=Bytes();string tmp=path+"."+Guid.NewGuid().ToString("N")+".tmp";try{File.WriteAllBytes(tmp,bytes);SaveDocument.Load(tmp);if(File.Exists(path))File.Replace(tmp,path,null);else File.Move(tmp,path);SaveVerification.VerifyBytes(path,bytes);}finally{if(File.Exists(tmp))File.Delete(tmp);}}
 public static J Data(J entry){return entry["ItemData"];}
 public static void AddEffect(J entry,J incoming){J batches=Data(entry)["Effects"];J target=batches.Values.FirstOrDefault(b=>b["TypeTag"].Text==incoming["TypeTag"].Text);if(target==null){batches.Add(incoming.Copy());return;}foreach(J effect in incoming["EffectsInThisBatch"].Values){J values=target["EffectsInThisBatch"];foreach(J old in values.Values.Where(e=>e["TypeTag"].Text==effect["TypeTag"].Text).ToList())values.Remove(old);values.Add(effect.Copy());}}
 public static string Tag(J entry){return Data(entry)["TypeTag"].Text;}
 public static bool Gear(J entry){string t=Tag(entry);return !t.StartsWith("SW.Item.Cosmetic.")&&!t.StartsWith("SW.Item.EnchantmentBook.");}
 public static bool Merchant(J entry){return Data(entry)["TargetSlotOverride"].Text.IndexOf("Merchant",StringComparison.OrdinalIgnoreCase)>=0;}
 public static string Name(string tag){var definition=EquipmentCatalog.Find(tag);if(definition!=null)return definition.Name;string s=tag.Substring(tag.LastIndexOf('.')+1);return Regex.Replace(s,"([a-z])([A-Z])","$1 $2");}
 public J AddFrom(J template){J e=template.Copy();e["EquippedSlot"]=J.Str("None");e["StackCount"]=J.Num(1);e["MerchantItemSold"]=J.Bool(false);e["MerchantDiscount"]=J.Num(0);Data(e)["TargetSlotOverride"]=J.Str("None");Data(e)["PickupTimestamp"]=J.Num(decimal.Floor((decimal)(DateTime.UtcNow-new DateTime(1970,1,1)).TotalSeconds));Entries.Add(e);return e;}
}
