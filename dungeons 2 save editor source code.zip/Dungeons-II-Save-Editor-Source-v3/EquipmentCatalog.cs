﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Web.Script.Serialization;

public sealed class EquipmentDefinition {
 public string Tag {get;set;} public string Name {get;set;} public string Category {get;set;}
 public string ArmorSlot {get;set;} public string Icon {get;set;} public bool Unique {get;set;}
 public string Definition {get;set;} public string ProgressionJson {get;set;}
}
public static class EquipmentCatalog {
 static readonly Dictionary<string,EquipmentDefinition> definitions=Load();
 public static int Count {get{return definitions.Count;}}
 public static IEnumerable<EquipmentDefinition> All {get{return definitions.Values;}}
 static Dictionary<string,EquipmentDefinition> Load(){using(Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("EquipmentCatalog.json"))using(var reader=new StreamReader(stream)){var entries=new JavaScriptSerializer().Deserialize<List<EquipmentDefinition>>(reader.ReadToEnd());if(entries==null||entries.Count==0)throw new InvalidDataException("The embedded equipment catalog is missing.");var result=new Dictionary<string,EquipmentDefinition>(StringComparer.OrdinalIgnoreCase);foreach(var item in entries){if(!item.Tag.StartsWith("SW.Item.",StringComparison.OrdinalIgnoreCase)||!new[]{"Artifact","Bow","Melee","Armor","Talisman"}.Contains(item.Category)||string.IsNullOrWhiteSpace(item.Icon))throw new InvalidDataException("Invalid equipment definition.");result.Add(item.Tag,item);}return result;}}
 public static EquipmentDefinition Find(string tag){EquipmentDefinition item;return definitions.TryGetValue(tag,out item)?item:null;}
 public static List<J> Templates(SaveDocument document){decimal level=document.Root["CharacterSaveV1"]["MetaData"]["Level"].Number;decimal power=Math.Max(1,document.Root["CharacterSaveV1"]["MetaData"]["PowerLevel"].Number);return All.Select(item=>CreateTemplate(item,level,power)).ToList();}
 public static J CreateTemplate(EquipmentDefinition definition,decimal level,decimal power){
  // Construct an independent inventory entry using the observed V1 save schema.
  // No item or effect is copied from the character's existing inventory.
  J entry=J.Parse("{\"ItemData\":{\"TypeTag\":\"\",\"RarityTag\":\"\",\"Effects\":[],\"ItemProgression\":{\"CurrentLevel\":0,\"CurrentXP\":0,\"ItemLevels\":[]},\"GeneratorData\":{\"GenesisRandomSeed\":0,\"PowerGeneratorValues\":{\"PlayerLevel\":1,\"AreaThreatLevel\":1,\"RecommendedThreatLevel\":1,\"ThreatSliderOffset\":0,\"ItemPowerMin\":1,\"ItemPowerMax\":1,\"RNGRoll\":0,\"ItemPower\":1,\"ItemPowerOriginal\":1}},\"DynamicPropertyTags\":[\"SW.Item.Property.Dynamic.Unseen\"],\"TargetSlotOverride\":\"None\",\"PickupTimestamp\":0,\"EffectRerolls\":0},\"StackCount\":1,\"EquippedSlot\":\"None\",\"MerchantItemSold\":false,\"MerchantDiscount\":0}");
  J data=SaveDocument.Data(entry);data["TypeTag"]=J.Str(definition.Tag);data["RarityTag"]=J.Str(definition.Unique?"SW.Rarity.Unique":"SW.Rarity.Common");byte[] seed=new byte[4];using(var rng=RandomNumberGenerator.Create())rng.GetBytes(seed);data["GeneratorData"]["GenesisRandomSeed"]=J.Num(BitConverter.ToUInt32(seed,0));J values=data["GeneratorData"]["PowerGeneratorValues"];values["PlayerLevel"]=J.Num(Math.Max(1,level));power=Math.Max(1,power);foreach(string field in new[]{"ItemPowerMin","ItemPowerMax","ItemPower","ItemPowerOriginal"})values[field]=J.Num(power);if(definition.Category=="Talisman"){data["RarityTag"]=J.Str("SW.Rarity.None");data["ItemProgression"]=J.Parse(definition.ProgressionJson);J initial=data["ItemProgression"]["ItemLevels"].Values[0];if(initial["LevelEffects"].Values.Count>0){J batch=J.Parse("{\"TypeTag\":\"SW.Item.Effect.Upgradable\",\"EffectsInThisBatch\":[]}");batch["EffectsInThisBatch"]=initial["LevelEffects"].Copy();data["Effects"].Add(batch);}values["ItemPower"]=J.Num(-1);values["ItemPowerOriginal"]=J.Num(0);}return entry;
 }
}
