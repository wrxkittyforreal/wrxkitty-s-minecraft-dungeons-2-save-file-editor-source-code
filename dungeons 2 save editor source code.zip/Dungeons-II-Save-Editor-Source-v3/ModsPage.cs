using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using Microsoft.Win32;

internal sealed class InstalledMod
{
	public string Name;
	public string Path;
	public bool IsDirectory;
	public int FileCount;
	public override string ToString() { return Name + "   ·   " + FileCount + " file" + (FileCount == 1 ? "" : "s"); }
}

internal static class ModArchiveService
{
	private static readonly string[] PayloadExtensions = new string[] { ".pak", ".utoc", ".ucas", ".mp4", ".locres", ".ini", ".json" };
	private static readonly string[] BlockedExtensions = new string[] { ".exe", ".dll", ".com", ".scr", ".msi", ".bat", ".cmd", ".ps1", ".psm1", ".vbs", ".js", ".jse", ".wsf", ".hta", ".reg", ".lnk" };

	public static string NormalizePaksPath(string path)
	{
		if (string.IsNullOrWhiteSpace(path)) return null;
		string full = System.IO.Path.GetFullPath(path.Trim().Trim('"'));
		if (System.IO.Path.GetFileName(full).Equals("Paks", StringComparison.OrdinalIgnoreCase)) return full;
		string[] candidates = new string[] {
			System.IO.Path.Combine(full, "Dungeons", "Content", "Paks"),
			System.IO.Path.Combine(full, "Content", "Dungeons", "Content", "Paks"),
			System.IO.Path.Combine(full, "Dungeons", "Content", "Paks")
		};
		foreach (string candidate in candidates) if (Directory.Exists(candidate)) return candidate;
		return null;
	}

	public static string DetectPaksPath()
	{
		List<string> roots = new List<string>();
		try
		{
			using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam"))
				if (key != null) AddSteamRoot(roots, Convert.ToString(key.GetValue("SteamPath")));
		}
		catch { }
		try
		{
			using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\WOW6432Node\Valve\Steam"))
				if (key != null) AddSteamRoot(roots, Convert.ToString(key.GetValue("InstallPath")));
		}
		catch { }
		try
		{
			foreach (DriveInfo drive in DriveInfo.GetDrives())
			{
				if (!drive.IsReady) continue;
				string common = System.IO.Path.Combine(drive.RootDirectory.FullName, "steamapps", "common");
				if (Directory.Exists(common)) roots.Add(drive.RootDirectory.FullName);
			}
		}
		catch { }
		foreach (string root in roots.Distinct(StringComparer.OrdinalIgnoreCase))
		{
			string paks = System.IO.Path.Combine(root, "steamapps", "common", "Minecraft Dungeons II", "Dungeons", "Content", "Paks");
			if (Directory.Exists(paks)) return paks;
			string libraries = System.IO.Path.Combine(root, "steamapps", "libraryfolders.vdf");
			if (!File.Exists(libraries)) continue;
			try
			{
				string text = File.ReadAllText(libraries);
				MatchCollection matches = Regex.Matches(text, "\\\"path\\\"\\s*\\\"([^\\\"]+)\\\"", RegexOptions.IgnoreCase);
				foreach (Match match in matches)
				{
					string library = match.Groups[1].Value.Replace("\\\\", "\\");
					paks = System.IO.Path.Combine(library, "steamapps", "common", "Minecraft Dungeons II", "Dungeons", "Content", "Paks");
					if (Directory.Exists(paks)) return paks;
				}
			}
			catch { }
		}
		return null;
	}

	private static void AddSteamRoot(List<string> roots, string path)
	{
		if (!string.IsNullOrWhiteSpace(path))
		{
			path = path.Replace('/', '\\');
			if (Directory.Exists(path)) roots.Add(path);
		}
	}

	public static List<InstalledMod> Scan(string paksPath)
	{
		List<InstalledMod> result = new List<InstalledMod>();
		if (string.IsNullOrWhiteSpace(paksPath)) return result;
		foreach (string modRoot in ModRoots(paksPath))
		{
			if (!Directory.Exists(modRoot)) continue;
			foreach (string folder in Directory.GetDirectories(modRoot))
			{
				if ((File.GetAttributes(folder) & FileAttributes.ReparsePoint) != 0) continue;
				int count = SafePayloadFiles(folder).Count;
				if (count > 0) result.Add(new InstalledMod { Name = System.IO.Path.GetFileName(folder), Path = folder, IsDirectory = true, FileCount = count });
			}
			Dictionary<string, List<string>> loose = new Dictionary<string, List<string>>(StringComparer.OrdinalIgnoreCase);
			foreach (string file in Directory.GetFiles(modRoot))
			{
				if (!PayloadExtensions.Contains(System.IO.Path.GetExtension(file), StringComparer.OrdinalIgnoreCase)) continue;
				string stem = System.IO.Path.GetFileNameWithoutExtension(file).Replace("_P", "");
				if (!loose.ContainsKey(stem)) loose[stem] = new List<string>();
				loose[stem].Add(file);
			}
			foreach (KeyValuePair<string, List<string>> pair in loose)
				result.Add(new InstalledMod { Name = pair.Key + " (loose files)", Path = string.Join("|", pair.Value.ToArray()), IsDirectory = false, FileCount = pair.Value.Count });
		}
		return result.OrderBy(m => m.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
	}

	private static IEnumerable<string> ModRoots(string paksPath)
	{
		yield return System.IO.Path.Combine(paksPath, "~mods");
		yield return System.IO.Path.Combine(paksPath, "mods");
	}

	public static void Install(string archivePath, string paksPath)
	{
		string extension = System.IO.Path.GetExtension(archivePath);
		if (!extension.Equals(".zip", StringComparison.OrdinalIgnoreCase) && !extension.Equals(".rar", StringComparison.OrdinalIgnoreCase))
			throw new InvalidDataException("Choose a .zip or .rar mod archive.");
		string mods = System.IO.Path.Combine(paksPath, "~mods");
		string stage = System.IO.Path.Combine(System.IO.Path.GetTempPath(), "DungeonsII-ModInstall-" + Guid.NewGuid().ToString("N"));
		Directory.CreateDirectory(stage);
		try
		{
			if (extension.Equals(".zip", StringComparison.OrdinalIgnoreCase)) ExtractZipSafely(archivePath, stage);
			else ExtractRarSafely(archivePath, stage);
			RejectLinks(stage);
			List<string> files = SafePayloadFiles(stage);
			foreach (string file in Directory.GetFiles(stage, "*", SearchOption.AllDirectories))
				if (BlockedExtensions.Contains(System.IO.Path.GetExtension(file), StringComparer.OrdinalIgnoreCase))
					throw new InvalidDataException("This archive contains an executable or script (" + System.IO.Path.GetFileName(file) + "). For safety, the editor only installs data files and will not run mod installers.");
			if (!files.Any(f => System.IO.Path.GetExtension(f).Equals(".pak", StringComparison.OrdinalIgnoreCase) || System.IO.Path.GetExtension(f).Equals(".utoc", StringComparison.OrdinalIgnoreCase) || System.IO.Path.GetExtension(f).Equals(".ucas", StringComparison.OrdinalIgnoreCase)))
				throw new InvalidDataException("I couldn't find any .pak, .utoc, or .ucas mod files in that archive.");
			string sourceRoot = FindInstallSource(stage);
			files = SafePayloadFiles(sourceRoot);
			if (files.Count == 0) throw new InvalidDataException("The archive doesn't contain supported mod files in a recognizable game-mod folder.");
			Directory.CreateDirectory(mods);
			InstallPayloads(stage, sourceRoot, files, mods);
		}
		finally
		{
			try { Directory.Delete(stage, true); } catch { }
		}
	}

	private sealed class InstallBundle
	{
		public string Name;
		public bool IsDirectory;
		public string StagedPath;
		public List<string> LooseFiles = new List<string>();
		public List<string> LooseFilesDeployed = new List<string>();
		public string TargetPath;
		public string BackupPath;
		public bool Deployed;
	}

	private static void InstallPayloads(string stage, string sourceRoot, List<string> files, string mods)
	{
		string fullMods = System.IO.Path.GetFullPath(mods);
		string installRoot = System.IO.Path.Combine(fullMods, ".dungeonsii-install-" + Guid.NewGuid().ToString("N"));
		string rollbackRoot = System.IO.Path.Combine(installRoot, "rollback");
		Directory.CreateDirectory(installRoot);
		List<string> relatives = files.Select(f => f.Substring(sourceRoot.TrimEnd(System.IO.Path.DirectorySeparatorChar).Length).TrimStart(System.IO.Path.DirectorySeparatorChar)).ToList();
		bool hasRootFiles = relatives.Any(r => r.IndexOf(System.IO.Path.DirectorySeparatorChar) < 0);
		List<string> firstFolders = relatives.Where(r => r.IndexOf(System.IO.Path.DirectorySeparatorChar) >= 0).Select(r => r.Split(System.IO.Path.DirectorySeparatorChar)[0]).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
		bool wrapperFolder = !hasRootFiles && firstFolders.Count == 1 && !firstFolders[0].Equals("~mods", StringComparison.OrdinalIgnoreCase);
		List<InstallBundle> bundles = new List<InstallBundle>();
		if (wrapperFolder)
		{
			string name = firstFolders[0];
			string prepared = System.IO.Path.Combine(installRoot, name);
			Directory.CreateDirectory(prepared);
			for (int i = 0; i < relatives.Count; i++)
			{
				string inner = relatives[i].Substring(name.Length).TrimStart(System.IO.Path.DirectorySeparatorChar);
				CopyPrepared(files[i], prepared, inner);
			}
			bundles.Add(new InstallBundle { Name = name, IsDirectory = true, StagedPath = prepared });
		}
		else
		{
			Dictionary<string, List<int>> folderGroups = new Dictionary<string, List<int>>(StringComparer.OrdinalIgnoreCase);
			Dictionary<string, List<int>> looseGroups = new Dictionary<string, List<int>>(StringComparer.OrdinalIgnoreCase);
			for (int i = 0; i < relatives.Count; i++)
			{
				string relative = relatives[i];
				if (relative.IndexOf(System.IO.Path.DirectorySeparatorChar) >= 0)
				{
					string name = relative.Split(System.IO.Path.DirectorySeparatorChar)[0];
					if (!folderGroups.ContainsKey(name)) folderGroups[name] = new List<int>();
					folderGroups[name].Add(i);
				}
				else
				{
					string name = System.IO.Path.GetFileNameWithoutExtension(relative).Replace("_P", "");
					if (!looseGroups.ContainsKey(name)) looseGroups[name] = new List<int>();
					looseGroups[name].Add(i);
				}
			}
			foreach (KeyValuePair<string, List<int>> group in folderGroups)
			{
				string prepared = System.IO.Path.Combine(installRoot, group.Key);
				Directory.CreateDirectory(prepared);
				foreach (int index in group.Value)
				{
					string inner = relatives[index].Substring(group.Key.Length).TrimStart(System.IO.Path.DirectorySeparatorChar);
					CopyPrepared(files[index], prepared, inner);
				}
				bundles.Add(new InstallBundle { Name = group.Key, IsDirectory = true, StagedPath = prepared });
			}
			foreach (KeyValuePair<string, List<int>> group in looseGroups)
			{
				if (string.IsNullOrWhiteSpace(group.Key) || group.Key == "." || group.Key == "..") throw new InvalidDataException("The archive contains a mod file with an invalid package name.");
				InstallBundle bundle = new InstallBundle { Name = group.Key, IsDirectory = false };
				foreach (int index in group.Value) bundle.LooseFiles.Add(files[index]);
				bundles.Add(bundle);
			}
		}
		foreach (InstallBundle bundle in bundles)
		{
			if (bundle.Name.IndexOfAny(System.IO.Path.GetInvalidFileNameChars()) >= 0 || bundle.Name.Equals(".") || bundle.Name.Equals("..")) throw new InvalidDataException("The archive contains an invalid mod folder name.");
			bundle.TargetPath = System.IO.Path.GetFullPath(System.IO.Path.Combine(fullMods, bundle.Name));
			if (!bundle.TargetPath.StartsWith(fullMods.TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("The archive contains a path outside the mod folder.");
		}
		try
		{
			foreach (InstallBundle bundle in bundles)
			{
				bundle.BackupPath = System.IO.Path.Combine(rollbackRoot, bundle.Name + (bundle.IsDirectory ? "-folder" : "-loose"));
				if (bundle.IsDirectory)
				{
					if (Directory.Exists(bundle.TargetPath)) { Directory.CreateDirectory(rollbackRoot); Directory.Move(bundle.TargetPath, bundle.BackupPath); }
					else if (File.Exists(bundle.TargetPath)) throw new IOException("A file already uses the mod folder name " + bundle.Name + ".");
					Directory.Move(bundle.StagedPath, bundle.TargetPath);
					bundle.Deployed = true;
				}
				else
				{
					string[] previous = Directory.GetFiles(fullMods).Where(f => LooseModName(System.IO.Path.GetFileName(f)).Equals(bundle.Name, StringComparison.OrdinalIgnoreCase) && PayloadExtensions.Contains(System.IO.Path.GetExtension(f), StringComparer.OrdinalIgnoreCase)).ToArray();
					if (previous.Length > 0)
					{
						Directory.CreateDirectory(bundle.BackupPath);
						foreach (string old in previous) File.Move(old, System.IO.Path.Combine(bundle.BackupPath, System.IO.Path.GetFileName(old)));
					}
					foreach (string source in bundle.LooseFiles)
					{
						string destination = System.IO.Path.Combine(fullMods, System.IO.Path.GetFileName(source));
						if (File.Exists(destination)) throw new IOException("A mod file already exists here and belongs to another package: " + destination);
					File.Copy(source, destination, false);
					bundle.LooseFilesDeployed.Add(destination);
				}
					bundle.Deployed = true;
				}
			}
		}
		catch
		{
			foreach (InstallBundle bundle in bundles.AsEnumerable().Reverse())
			{
				try
				{
					if (bundle.IsDirectory && bundle.Deployed && Directory.Exists(bundle.TargetPath)) Directory.Delete(bundle.TargetPath, true);
					if (!bundle.IsDirectory) foreach (string path in bundle.LooseFilesDeployed) if (File.Exists(path)) File.Delete(path);
					if (bundle.BackupPath != null && bundle.IsDirectory && Directory.Exists(bundle.BackupPath)) Directory.Move(bundle.BackupPath, bundle.TargetPath);
					if (bundle.BackupPath != null && !bundle.IsDirectory && Directory.Exists(bundle.BackupPath)) foreach (string old in Directory.GetFiles(bundle.BackupPath)) File.Move(old, System.IO.Path.Combine(fullMods, System.IO.Path.GetFileName(old)));
				}
				catch { }
			}
			try { Directory.Delete(installRoot, true); } catch { }
			throw;
		}
		try { Directory.Delete(installRoot, true); } catch { }
	}

	private static string LooseModName(string fileName)
	{
		string name = System.IO.Path.GetFileNameWithoutExtension(fileName);
		return name.Replace("_P", "");
	}

	private static void CopyPrepared(string source, string folder, string relative)
	{
		string target = System.IO.Path.GetFullPath(System.IO.Path.Combine(folder, relative));
		string prefix = System.IO.Path.GetFullPath(folder).TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar;
		if (!target.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("The archive contains a path outside the mod folder.");
		Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target));
		File.Copy(source, target, false);
	}

	private static string FindInstallSource(string stage)
	{
		DirectoryInfo[] mods = new DirectoryInfo(stage).GetDirectories("~mods", SearchOption.AllDirectories);
		if (mods.Length > 0) return mods[0].FullName;
		DirectoryInfo[] paks = new DirectoryInfo(stage).GetDirectories("Paks", SearchOption.AllDirectories);
		foreach (DirectoryInfo folder in paks)
			if (SafePayloadFiles(folder.FullName).Any()) return folder.FullName;
		string[] topFiles = SafePayloadFiles(stage).Where(f => f.IndexOf(System.IO.Path.DirectorySeparatorChar, stage.Length) < 0).ToArray();
		if (topFiles.Any()) return stage;
		string[] topDirs = Directory.GetDirectories(stage);
		if (topDirs.Length == 1 && SafePayloadFiles(topDirs[0]).Count > 0) return stage;
		return stage;
	}

	private static List<string> SafePayloadFiles(string root)
	{
		List<string> result = new List<string>();
		if (!Directory.Exists(root)) return result;
		foreach (string file in Directory.GetFiles(root, "*", SearchOption.AllDirectories))
			if (PayloadExtensions.Contains(System.IO.Path.GetExtension(file), StringComparer.OrdinalIgnoreCase)) result.Add(file);
		return result;
	}

	private static void ExtractZipSafely(string archivePath, string destination)
	{
		long total = 0;
		int count = 0;
		using (FileStream stream = File.OpenRead(archivePath))
		using (ZipArchive archive = new ZipArchive(stream, ZipArchiveMode.Read))
		{
			foreach (ZipArchiveEntry entry in archive.Entries)
			{
				if (string.IsNullOrEmpty(entry.FullName)) continue;
				if (++count > 20000) throw new InvalidDataException("The archive has too many files.");
				if (entry.Length < 0 || entry.Length > 1024L * 1024L * 1024L || (total += entry.Length) > 2L * 1024L * 1024L * 1024L) throw new InvalidDataException("The archive is too large to install safely.");
				string normalized = entry.FullName.Replace('/', '\\');
				if (System.IO.Path.IsPathRooted(normalized) || Regex.IsMatch(normalized, "^[A-Za-z]:") || normalized.Split('\\').Any(part => part == "..")) throw new InvalidDataException("The archive contains an unsafe file path.");
				int mode = (entry.ExternalAttributes >> 16) & 0xF000;
				if (mode == 0xA000) throw new InvalidDataException("The archive contains a symbolic link, which cannot be installed safely.");
				string target = System.IO.Path.GetFullPath(System.IO.Path.Combine(destination, normalized));
				if (!target.StartsWith(System.IO.Path.GetFullPath(destination).TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase)) throw new InvalidDataException("The archive contains an unsafe file path.");
				if (entry.Name.Length == 0) { Directory.CreateDirectory(target); continue; }
				Directory.CreateDirectory(System.IO.Path.GetDirectoryName(target));
				using (Stream input = entry.Open())
				using (FileStream output = new FileStream(target, FileMode.CreateNew, FileAccess.Write, FileShare.None)) input.CopyTo(output);
			}
		}
	}

	private static void ExtractRarSafely(string archivePath, string destination)
	{
		string extractor = FindExtractor();
		if (extractor == null) throw new InvalidOperationException("RAR files need 7-Zip or WinRAR installed. Install one, restart the editor, and drop the .rar again. The editor never runs files from a mod archive.");
		string name = System.IO.Path.GetFileName(extractor);
		ProcessStartInfo info = new ProcessStartInfo();
		info.FileName = extractor;
		if (name.Equals("WinRAR.exe", StringComparison.OrdinalIgnoreCase)) info.Arguments = "x -ibck -y -o- " + Quote(archivePath) + " " + Quote(destination.TrimEnd('\\') + "\\");
		else if (name.StartsWith("UnRAR", StringComparison.OrdinalIgnoreCase)) info.Arguments = "x -o- " + Quote(archivePath) + " " + Quote(destination.TrimEnd('\\') + "\\");
		else info.Arguments = "x -y -o" + Quote(destination) + " " + Quote(archivePath);
		info.UseShellExecute = false;
		info.CreateNoWindow = true;
		info.WindowStyle = ProcessWindowStyle.Hidden;
		using (Process process = Process.Start(info))
		{
			if (process == null) throw new IOException("The archive extractor did not start.");
			process.WaitForExit();
			if (process.ExitCode != 0) throw new InvalidDataException("The .rar archive could not be extracted. Check that it is complete and that WinRAR or 7-Zip can open it.");
		}
	}

	private static string FindExtractor()
	{
		List<string> candidates = new List<string>();
		string pf = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles);
		string pf86 = Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86);
		foreach (string root in new string[] { pf, pf86 })
		{
			if (string.IsNullOrEmpty(root)) continue;
			candidates.Add(System.IO.Path.Combine(root, "7-Zip", "7z.exe"));
			candidates.Add(System.IO.Path.Combine(root, "WinRAR", "WinRAR.exe"));
			candidates.Add(System.IO.Path.Combine(root, "WinRAR", "UnRAR.exe"));
		}
		string path = Environment.GetEnvironmentVariable("PATH") ?? "";
		foreach (string folder in path.Split(System.IO.Path.PathSeparator))
		{
			if (string.IsNullOrWhiteSpace(folder)) continue;
			foreach (string file in new string[] { "7z.exe", "7za.exe", "WinRAR.exe", "UnRAR.exe" }) candidates.Add(System.IO.Path.Combine(folder.Trim('"'), file));
		}
		return candidates.FirstOrDefault(File.Exists);
	}

	private static string Quote(string value) { return "\"" + value.Replace("\"", "\\\"") + "\""; }

	private static void RejectLinks(string root)
	{
		foreach (string path in Directory.GetFileSystemEntries(root, "*", SearchOption.AllDirectories))
			if ((File.GetAttributes(path) & FileAttributes.ReparsePoint) != 0) throw new InvalidDataException("The archive contains a symbolic link, which cannot be installed safely.");
	}

	public static void Remove(InstalledMod mod, string paksPath)
	{
		if (mod == null) return;
		List<string> roots = ModRoots(paksPath).Select(p => System.IO.Path.GetFullPath(p).TrimEnd(System.IO.Path.DirectorySeparatorChar) + System.IO.Path.DirectorySeparatorChar).ToList();
		if (mod.IsDirectory)
		{
			string full = System.IO.Path.GetFullPath(mod.Path);
			if (!roots.Any(root => full.StartsWith(root, StringComparison.OrdinalIgnoreCase))) throw new InvalidOperationException("That folder is outside the game's mod folder.");
			Directory.Delete(full, true);
		}
		else
		{
			foreach (string file in mod.Path.Split('|'))
			{
				string full = System.IO.Path.GetFullPath(file);
				if (!roots.Any(root => full.StartsWith(root, StringComparison.OrdinalIgnoreCase))) throw new InvalidOperationException("That file is outside the game's mod folder.");
				if (File.Exists(full)) File.Delete(full);
			}
		}
	}
}

public sealed class ModsPage : UserControl
{
	private readonly ListBox mods = new ListBox();
	private readonly Label pathLabel;
	private readonly Label note;
	private string paksPath;

	public ModsPage()
	{
		BackColor = ProgressPageStyle.Background;
		AllowDrop = true;
		DragEnter += OnDragEnter;
		DragDrop += OnDragDrop;
		ProgressPageStyle.Label("MODS", new Point(24, 18), new Size(500, 32), this, 18, Color.White);
		ProgressPageStyle.Label("Drop a .zip or .rar mod archive here to install it. Existing mods in the game folder appear below.", new Point(24, 56), new Size(1060, 24), this, 9);
		ProgressPageStyle.Label("GAME MOD FOLDER", new Point(24, 100), new Size(240, 22), this, 10, ProgressPageStyle.Mint);
		pathLabel = ProgressPageStyle.Label("Looking for Minecraft Dungeons II…", new Point(24, 128), new Size(800, 28), this, 9, Color.White);
		Button browse = ProgressPageStyle.Button("Choose game folder…", new Point(0, 120), new Size(164, 36), this, (s, e) => ChooseGameFolder());
		Button refresh = ProgressPageStyle.Button("Refresh", new Point(0, 120), new Size(100, 36), this, (s, e) => RefreshMods());
		Button install = ProgressPageStyle.Button("Install archive…", new Point(0, 120), new Size(150, 36), this, (s, e) => ChooseArchive());
		Button openFolder = ProgressPageStyle.Button("Open ~mods folder", new Point(0, 120), new Size(160, 36), this, (s, e) => OpenModsFolder());
		Button remove = ProgressPageStyle.Button("Remove selected", new Point(0, 120), new Size(150, 36), this, (s, e) => RemoveSelected());
		mods.Location = new Point(24, 178);
		mods.Size = new Size(500, 240);
		mods.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
		mods.BorderStyle = BorderStyle.None;
		mods.BackColor = ProgressPageStyle.Surface;
		mods.ForeColor = Color.White;
		mods.IntegralHeight = false;
		mods.AllowDrop = true;
		mods.DragEnter += OnDragEnter;
		mods.DragDrop += OnDragDrop;
		Controls.Add(mods);
		note = ProgressPageStyle.Label("Mods are extracted as data files only. The editor does not run installers, scripts, or files from archives. Close the game before installing or removing mods.", new Point(24, 0), new Size(900, 48), this, 9);
		paksPath = LoadPath();
		if (string.IsNullOrEmpty(paksPath)) paksPath = ModArchiveService.DetectPaksPath();
		if (string.IsNullOrEmpty(paksPath)) pathLabel.Text = "Game folder not found automatically. Choose the game's Paks folder to continue.";
		else pathLabel.Text = paksPath;
		Resize += (s, e) => LayoutPage();
		LayoutPage();
		RefreshMods();
	}

	private string ConfigPath { get { return System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "UI Config", "ModsPaksPath.txt"); } }
	private string ModsFolder { get { return string.IsNullOrEmpty(paksPath) ? null : System.IO.Path.Combine(paksPath, "~mods"); } }

	private string LoadPath()
	{
		try { string p = File.ReadAllText(ConfigPath).Trim(); return ModArchiveService.NormalizePaksPath(p); } catch { return null; }
	}

	private void SavePath()
	{
		try { Directory.CreateDirectory(System.IO.Path.GetDirectoryName(ConfigPath)); File.WriteAllText(ConfigPath, paksPath ?? ""); } catch { }
	}

	private void LayoutPage()
	{
		int right = Width - 24;
		int x = right - 164;
		foreach (Control control in Controls.OfType<Button>().Reverse())
		{
			control.Top = 120;
			control.Left = x;
			x -= control.Width + 8;
		}
		mods.SetBounds(24, 178, Math.Max(360, Width - 48), Math.Max(180, Height - 250));
		note.SetBounds(24, Height - 56, Math.Max(500, Width - 48), 48);
	}

	private void OnDragEnter(object sender, DragEventArgs e)
	{
		if (e.Data != null && e.Data.GetDataPresent(DataFormats.FileDrop))
		{
			string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
			e.Effect = files.Any(f => f.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) || f.EndsWith(".rar", StringComparison.OrdinalIgnoreCase)) ? DragDropEffects.Copy : DragDropEffects.None;
		}
	}

	private void OnDragDrop(object sender, DragEventArgs e)
	{
		if (e.Data == null || !e.Data.GetDataPresent(DataFormats.FileDrop)) return;
		foreach (string file in (string[])e.Data.GetData(DataFormats.FileDrop))
			if (file.EndsWith(".zip", StringComparison.OrdinalIgnoreCase) || file.EndsWith(".rar", StringComparison.OrdinalIgnoreCase)) InstallArchive(file);
	}

	private void ChooseGameFolder()
	{
		using (FolderBrowserDialog dialog = new FolderBrowserDialog())
		{
			dialog.Description = "Choose the Minecraft Dungeons II Paks folder or game folder.";
			if (dialog.ShowDialog(this) != DialogResult.OK) return;
			paksPath = ModArchiveService.NormalizePaksPath(dialog.SelectedPath);
			if (string.IsNullOrEmpty(paksPath)) { MessageBox.Show(this, "I couldn't find Dungeons\\Content\\Paks inside that folder. Choose the Paks folder itself or the game folder.", "Game folder not found", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
			pathLabel.Text = paksPath;
			SavePath();
			RefreshMods();
		}
	}

	private void ChooseArchive()
	{
		using (OpenFileDialog dialog = new OpenFileDialog())
		{
			dialog.Filter = "Mod archives (*.zip;*.rar)|*.zip;*.rar";
			dialog.Multiselect = true;
			if (dialog.ShowDialog(this) != DialogResult.OK) return;
			foreach (string file in dialog.FileNames) InstallArchive(file);
		}
	}

	private void InstallArchive(string archive)
	{
		if (string.IsNullOrEmpty(paksPath) || !Directory.Exists(paksPath)) { MessageBox.Show(this, "Choose the game's Paks folder first.", "Mods", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
		if (Process.GetProcessesByName("Dungeons_Win64_Shipping").Length > 0 || Process.GetProcessesByName("Dungeons-Win64-Shipping").Length > 0) { MessageBox.Show(this, "Close Minecraft Dungeons II before installing mods, then try again.", "Game is running", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
		try { ModArchiveService.Install(archive, paksPath); RefreshMods(); MessageBox.Show(this, "Installed or updated " + System.IO.Path.GetFileName(archive) + " in the game's ~mods folder.", "Mod ready", MessageBoxButtons.OK, MessageBoxIcon.Information); }
		catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not install mod", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
	}

	private void RefreshMods()
	{
		mods.BeginUpdate();
		mods.Items.Clear();
		if (!string.IsNullOrEmpty(paksPath)) foreach (InstalledMod mod in ModArchiveService.Scan(paksPath)) mods.Items.Add(mod);
		mods.EndUpdate();
		if (mods.Items.Count == 0) mods.Items.Add("No mods found in the game's ~mods or mods folder.");
	}

	private void OpenModsFolder()
	{
		if (string.IsNullOrEmpty(paksPath)) { MessageBox.Show(this, "Choose the game's Paks folder first.", "Mods", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
		string folder = ModsFolder;
		Directory.CreateDirectory(folder);
		try { Process.Start(new ProcessStartInfo("explorer.exe", "\"" + folder + "\"") { UseShellExecute = false }); } catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not open folder", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
	}

	private void RemoveSelected()
	{
		InstalledMod mod = mods.SelectedItem as InstalledMod;
		if (mod == null) { MessageBox.Show(this, "Select an installed mod first.", "Mods", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
		if (MessageBox.Show(this, "Permanently remove " + mod.Name + " from the game's mod folder?", "Remove mod", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes) return;
		try { ModArchiveService.Remove(mod, paksPath); RefreshMods(); }
		catch (Exception ex) { MessageBox.Show(this, ex.Message, "Could not remove mod", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
	}
}
