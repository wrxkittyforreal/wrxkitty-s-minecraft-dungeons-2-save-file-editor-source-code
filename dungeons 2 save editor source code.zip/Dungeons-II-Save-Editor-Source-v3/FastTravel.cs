using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public sealed class FastTravelDefinition { public string Id; public string Name; public string Tag; }
public sealed class FastTravelChoice {
 public FastTravelDefinition Definition; public bool Unlocked;
 public override string ToString(){return Definition.Name+(Unlocked?"   ·   UNLOCKED":"   ·   LOCKED");}
}
public static class SaveFastTravel {
 static readonly List<FastTravelDefinition> definitions=ReadCatalog();
 static List<FastTravelDefinition> ReadCatalog(){using(Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("FastTravelCatalog.json")){if(stream==null)throw new InvalidDataException("Missing game fast-travel catalog.");using(var reader=new StreamReader(stream)){var list=new JavaScriptSerializer().Deserialize<List<FastTravelDefinition>>(reader.ReadToEnd());if(list==null||list.Count!=28||list.Any(x=>string.IsNullOrEmpty(x.Tag)||string.IsNullOrEmpty(x.Name))||list.Select(x=>x.Tag).Distinct(StringComparer.OrdinalIgnoreCase).Count()!=list.Count)throw new InvalidDataException("The game fast-travel catalog is incomplete.");return list;}}}
 static J Stations(SaveDocument document){J character=document.Root["CharacterSaveV1"];if(!character.Has("WorldExploration")||character["WorldExploration"].Kind!='o')throw new FormatException("This save does not contain world exploration progress.");J world=character["WorldExploration"];if(!world.Has("DiscoveredMinecartStationTags")||world["DiscoveredMinecartStationTags"].Kind!='a')throw new FormatException("This save does not contain discovered fast-travel stations.");return world["DiscoveredMinecartStationTags"];}
 public static List<FastTravelChoice> Choices(SaveDocument document){var discovered=new HashSet<string>(Stations(document).Values.Select(x=>x.Text),StringComparer.OrdinalIgnoreCase);return definitions.Select(x=>new FastTravelChoice(){Definition=x,Unlocked=discovered.Contains(x.Tag)}).ToList();}
 public static bool SetUnlocked(SaveDocument document,FastTravelDefinition definition,bool unlocked){J stations=Stations(document);J existing=stations.Values.FirstOrDefault(x=>x.Text.Equals(definition.Tag,StringComparison.OrdinalIgnoreCase));if(unlocked){if(existing!=null)return false;stations.Add(J.Str(definition.Tag));return true;}if(existing==null)return false;stations.Remove(existing);return true;}
 public static bool SetAll(SaveDocument document,bool unlocked){bool changed=false;foreach(var definition in definitions)changed=SetUnlocked(document,definition,unlocked)||changed;return changed;}
}
public sealed class FastTravelPage : UserControl {
 readonly SaveDocument document;readonly Action<bool,string> changed;readonly CheckedListBox list=new CheckedListBox();readonly List<FastTravelChoice> choices;readonly Label note;bool bulk;
 public int ItemCount {get{return list.Items.Count;}}
 public FastTravelPage(SaveDocument document,Action<bool,string> changed){this.document=document;this.changed=changed;BackColor=ProgressPageStyle.Background;choices=SaveFastTravel.Choices(document);
  ProgressPageStyle.Label("STATION LOCATIONS",new System.Drawing.Point(24,18),new System.Drawing.Size(520,32),this,18,System.Drawing.Color.White);
  ProgressPageStyle.Label("Choose which discovered minecart stations are unlocked on the world map.",new System.Drawing.Point(24,56),new System.Drawing.Size(820,24),this,9);
  ProgressPageStyle.Button("Unlock all",new System.Drawing.Point(24,96),new System.Drawing.Size(116,36),this,(s,e)=>SetAll(true));
  ProgressPageStyle.Button("Lock all",new System.Drawing.Point(150,96),new System.Drawing.Size(116,36),this,(s,e)=>SetAll(false));
  list.Location=new System.Drawing.Point(24,148);list.Size=new System.Drawing.Size(500,250);list.BorderStyle=BorderStyle.None;list.BackColor=ProgressPageStyle.Surface;list.ForeColor=System.Drawing.Color.White;list.Font=new System.Drawing.Font("Segoe UI",10);list.CheckOnClick=true;list.IntegralHeight=false;foreach(var choice in choices)list.Items.Add(choice,choice.Unlocked);list.ItemCheck+=(s,e)=>{if(bulk)return;bool unlocked=e.NewValue==CheckState.Checked;var choice=choices[e.Index];if(SaveFastTravel.SetUnlocked(document,choice.Definition,unlocked)){choice.Unlocked=unlocked;changed(true,"Fast-travel locations");}};Controls.Add(list);
  note=ProgressPageStyle.Label("Changes are stored in this character save. Export the .sav when you're done.",new System.Drawing.Point(24,0),new System.Drawing.Size(650,24),this,9);Resize+=(s,e)=>LayoutPage();LayoutPage();
 }
 void LayoutPage(){list.SetBounds(24,148,Math.Max(360,Width-48),Math.Max(200,Height-220));note.SetBounds(24,Height-48,Math.Max(400,Width-48),24);}
 void SetAll(bool unlocked){bulk=true;for(int i=0;i<list.Items.Count;i++)list.SetItemChecked(i,unlocked);bulk=false;foreach(var choice in choices)choice.Unlocked=unlocked;bool any=SaveFastTravel.SetAll(document,unlocked);list.Refresh();if(any)changed(true,"Fast-travel locations");}
}
