﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;

public sealed class EffectDefinition {
 public string Template {get;set;} public string Tag {get;set;} public string Name {get;set;} public string Group {get;set;} public string Batch {get;set;} public string Tier {get;set;}
 public decimal Intensity {get;set;} public bool Fixed {get;set;} public decimal Minimum {get;set;} public decimal Maximum {get;set;}
 public string Description {get;set;} public string AppliesTo {get;set;} public string Icon {get;set;} public string Source {get;set;}
 public string ApplicabilityLabel {get{string value=(AppliesTo??"").Trim();if(value.Equals("Equipment",StringComparison.OrdinalIgnoreCase))return "All gear";if(value.Equals("Weapon",StringComparison.OrdinalIgnoreCase))return "Melee, Bow";if(value.Equals("Armor",StringComparison.OrdinalIgnoreCase))return "Armor · all slots";if(value.Equals("Artifact",StringComparison.OrdinalIgnoreCase))return "Artifact";if(value.Equals("Talisman",StringComparison.OrdinalIgnoreCase))return "Talisman";string[] parts=value.Split(',').Select(x=>x.Trim()).ToArray();if(parts.Length>0&&parts.All(x=>new[]{"Boots","Chest","Helmet","Leggings"}.Contains(x,StringComparer.OrdinalIgnoreCase)))return "Armor · "+string.Join(", ",new[]{"Helmet","Chest","Leggings","Boots"}.Where(slot=>parts.Contains(slot,StringComparer.OrdinalIgnoreCase)));return string.Join(", ",parts.Select(x=>x.Equals("MeleeWeapon",StringComparison.OrdinalIgnoreCase)?"Melee":x.Equals("RangedWeapon",StringComparison.OrdinalIgnoreCase)?"Bow":x));}}
 public override string ToString(){return Name+" · "+Tier+" · "+Group;}
 public J CreateBatch(){J batch=J.Parse("{\"TypeTag\":\"\",\"EffectsInThisBatch\":[]}");batch["TypeTag"]=J.Str(Batch);J effect=J.Parse("{\"TypeTag\":\"\",\"Intensity\":0,\"Quality\":0,\"EnchantmentPointsInvested\":0,\"GeneratorData\":{\"GeneratorParentTemplate\":\"\",\"Locked\":false}}");effect["TypeTag"]=J.Str(Tag);effect["Intensity"]=J.Num(Intensity);effect["GeneratorData"]["GeneratorParentTemplate"]=J.Str(Template);batch["EffectsInThisBatch"].Add(effect);return batch;}
}
public static class EffectCatalog {
 public static readonly List<EffectDefinition> All=Load();
 static List<EffectDefinition> Load(){using(var stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("EffectCatalog.json"))using(var reader=new StreamReader(stream)){var rows=new JavaScriptSerializer(){MaxJsonLength=4000000}.Deserialize<List<EffectDefinition>>(reader.ReadToEnd());if(rows==null||rows.Count==0||rows.Select(x=>x.Batch+"|"+x.Template).Distinct().Count()!=rows.Count)throw new InvalidDataException("Invalid effect catalog.");return rows;}}
 public static EffectDefinition Find(string template,string batch=null){return All.FirstOrDefault(x=>x.Template==template&&(batch==null||x.Batch==batch));}
}
