using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Script.Serialization;
using System.Windows.Forms;

public sealed class AchievementDefinition {
 public string Tag {get;set;} public string Name {get;set;} public string Group {get;set;}
 public int RequiredCount {get;set;} public string[] RequiredTags {get;set;}
}
public sealed class AchievementChoice {
 public AchievementDefinition Definition; public J State; public string Label;
 public bool IsComplete {get{return SaveProgression.IsComplete(Definition,State);}}
 public override string ToString(){return Label;}
}
public sealed class AchievementEdit {public AchievementDefinition Definition;public bool Completed;}
public static class AchievementCatalog {
 public static readonly List<AchievementDefinition> All=Load();
 static List<AchievementDefinition> Load(){using(Stream stream=Assembly.GetExecutingAssembly().GetManifestResourceStream("AchievementCatalog.json"))using(var reader=new StreamReader(stream)){var rows=new JavaScriptSerializer().Deserialize<List<AchievementDefinition>>(reader.ReadToEnd());if(rows==null||rows.Count!=32||rows.Select(x=>x.Tag).Distinct().Count()!=rows.Count)throw new InvalidDataException("Invalid achievement catalog.");return rows;}}
}
public static class SaveProgression {
 static J FindAttribute(SaveDocument document,string name){J found=document.Root["CharacterSaveV1"]["Ability"]["Attributes"].Values.FirstOrDefault(x=>x["AttributeName"].Text==name);if(found==null)throw new FormatException("The character save is missing the "+name+" value.");return found;}
 public static decimal Emeralds(SaveDocument document){return FindAttribute(document,"Emeralds")["CurrentValue"].Number;}
 public static decimal SpringStone(SaveDocument document){return FindAttribute(document,"SpringStone")["CurrentValue"].Number;}
 public static decimal Level(SaveDocument document){return document.Root["CharacterSaveV1"]["MetaData"]["Level"].Number;}
 public static bool SetEmeralds(SaveDocument document,decimal value){J node=FindAttribute(document,"Emeralds")["CurrentValue"];if(node.Number==value)return false;FindAttribute(document,"Emeralds")["CurrentValue"]=J.Num(value);return true;}
 public static bool SetSpringStone(SaveDocument document,decimal value){J node=FindAttribute(document,"SpringStone")["CurrentValue"];if(node.Number==value)return false;FindAttribute(document,"SpringStone")["CurrentValue"]=J.Num(value);return true;}
 public static bool SetLevel(SaveDocument document,decimal value){J character=document.Root["CharacterSaveV1"];J meta=character["MetaData"]["Level"];J ability=FindAttribute(document,"Level")["CurrentValue"];bool changed=meta.Number!=value||ability.Number!=value;if(!changed)return false;character["MetaData"]["Level"]=J.Num(value);FindAttribute(document,"Level")["CurrentValue"]=J.Num(value);return true;}
 public static List<AchievementChoice> Choices(SaveDocument document){J achievements=document.Root["CharacterSaveV1"]["Achievements"];var result=new List<AchievementChoice>();foreach(var definition in AchievementCatalog.All){J section=achievements[definition.Group];if(!section.Has(definition.Tag))throw new FormatException("The character save is missing achievement "+definition.Tag+".");J state=section[definition.Tag];string label=definition.Name;if(definition.Group=="CountAchievements")label+="  ("+state["Count"].Raw+" / "+definition.RequiredCount+")";else if(definition.Group=="CollectionAchievements")label+="  ("+state["CollectedTags"].Values.Count+" / "+definition.RequiredTags.Length+")";result.Add(new AchievementChoice(){Definition=definition,State=state,Label=label});}return result;}
 public static bool IsComplete(AchievementDefinition definition,J state){if(definition.Group=="QuestAchievements"||definition.Group=="BoolAchievements")return state["bCompleted"].Raw=="true";if(definition.Group=="CountAchievements")return state["Count"].Number>=definition.RequiredCount;var tags=new HashSet<string>(state["CollectedTags"].Values.Select(x=>x.Text),StringComparer.Ordinal);return definition.RequiredTags.All(tags.Contains);}
 public static bool SetComplete(SaveDocument document,AchievementDefinition definition,bool completed){J state=document.Root["CharacterSaveV1"]["Achievements"][definition.Group][definition.Tag];if(definition.Group=="QuestAchievements"||definition.Group=="BoolAchievements"){bool old=state["bCompleted"].Raw=="true";if(old==completed)return false;state["bCompleted"]=J.Bool(completed);return true;}if(definition.Group=="CountAchievements"){decimal value=completed?definition.RequiredCount:0;if(state["Count"].Number==value)return false;state["Count"]=J.Num(value);return true;}J collection=state["CollectedTags"];var current=collection.Values.Select(x=>x.Text).ToList();var target=completed?definition.RequiredTags.ToList():new List<string>();if(current.SequenceEqual(target,StringComparer.Ordinal))return false;collection.Values.Clear();collection.Changed=true;foreach(string tag in target)collection.Add(J.Str(tag));return true;}
}
public sealed class CharacterProgressDialog : Form {
 readonly Color bg=Color.FromArgb(18,23,30),surface=Color.FromArgb(29,37,48),muted=Color.FromArgb(167,185,204),mint=Color.FromArgb(111,230,190);
 readonly CheckedListBox achievements=new CheckedListBox();readonly List<AchievementChoice> choices;readonly HashSet<AchievementDefinition> touched=new HashSet<AchievementDefinition>();
 public IEnumerable<AchievementEdit> AchievementEdits {get{return touched.Select(definition=>new AchievementEdit(){Definition=definition,Completed=Enumerable.Range(0,achievements.Items.Count).Where(i=>((AchievementChoice)achievements.Items[i]).Definition==definition).Any(i=>achievements.GetItemChecked(i))});}}
 Label Label(string text,int x,int y,int w,int h,Control parent,int size=10){var l=new Label(){Text=text,Location=new Point(x,y),Size=new Size(w,h),ForeColor=muted,Font=new Font("Segoe UI",size)};parent.Controls.Add(l);return l;}
 Button Button(string text,int x,int y,int w,Control parent,EventHandler click){var b=new Button(){Text=text,Location=new Point(x,y),Size=new Size(w,36),BackColor=surface,ForeColor=Color.White,FlatStyle=FlatStyle.Flat};b.FlatAppearance.BorderColor=Color.FromArgb(62,79,95);b.Click+=click;parent.Controls.Add(b);return b;}
 public CharacterProgressDialog(SaveDocument document){Text="Achievements";ClientSize=new Size(700,675);MinimumSize=new Size(716,714);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;BackColor=bg;ForeColor=Color.White;Font=new Font("Segoe UI",10);
  Label("ACHIEVEMENTS",24,18,480,32,this,18).ForeColor=Color.White;Label("Check to complete an achievement; uncheck to clear its progress.",24,56,480,24,this,9);
  choices=SaveProgression.Choices(document);Button("Unlock all",560,47,116,this,(s,e)=>{for(int i=0;i<achievements.Items.Count;i++)achievements.SetItemChecked(i,true);});
  achievements.Location=new Point(24,92);achievements.Size=new Size(652,500);achievements.BorderStyle=BorderStyle.None;achievements.BackColor=surface;achievements.ForeColor=Color.White;achievements.Font=new Font("Segoe UI",10);achievements.CheckOnClick=true;achievements.IntegralHeight=false;
  foreach(var choice in choices)achievements.Items.Add(choice,choice.IsComplete);achievements.ItemCheck+=(s,e)=>{touched.Add(((AchievementChoice)achievements.Items[e.Index]).Definition);};Controls.Add(achievements);
  Label("Export this character .sav, then load it in the game to refresh its progress.",24,602,650,24,this,9);
  Button("Save changes",452,630,110,this,(s,e)=>{DialogResult=DialogResult.OK;Close();});Button("Cancel",568,630,108,this,(s,e)=>{DialogResult=DialogResult.Cancel;Close();});
 }
}
