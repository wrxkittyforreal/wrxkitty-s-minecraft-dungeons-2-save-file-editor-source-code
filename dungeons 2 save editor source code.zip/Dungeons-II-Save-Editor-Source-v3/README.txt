DUNGEONS II SAVE EDITOR

This version edits a character save in the editor and writes changes through Menu > Export .sav. Export can overwrite the loaded source file or save to another path. There is no Apply to game or Check game save action.

DUNGEONS II SAVE EDITOR — FULL EQUIPMENT AND EFFECT CATALOGS

TALISMANS AND INLINE ICONS UPDATE
The catalog now contains 296 items: the original 272 equipment definitions
plus all 24 talismans from the installed game's talisman table. Talismans are
available in Create item and the main inventory, with their own Talisman filter.
They begin at level 1 with the game's starting effects, all three upgrade-level
definitions, and companion-level tags where applicable. Their native rarity is
None and their native item power is -1, as in the supplied talisman save entry.
Enchantment/effect icons now appear immediately to the right of each name in
both the add-effect picker and the item's current effect list, before clicking.
The earlier missing-item problem remains unresolved pending AfterGame.sav.
This game only kept one copy when the same Soul Chip tag was added again in
the supplied post-load check. Create item now marks a talisman you already own
and disables adding a second copy of that same talisman type. Other talisman
types remain creatable. Talisman item power is native to the game and stays at
-1; its editor control is disabled so it cannot be changed to an invalid value.
The main editor, item picker, and enchantment picker now use 90% opacity.

Run DungeonsIISaveEditor.exe. No installation is required.
The catalog and pictures are embedded in the executable.

STATION LOCATIONS
The Station Locations tab in the top bar edits all 28 minecart fast-travel
stations found in the game's world-exploration table. Check or uncheck a station
to change its discovered state in the loaded character save. Export the .sav when finished. Test-only and fake stations are omitted.

CREATE ITEMS YOU DO NOT OWN
Create item now uses 272 equipment definitions extracted from the user's
installed Steam game: 152 armor pieces, 58 melee weapons, 22 bows, 40 artifacts.
The catalog includes separate Unique variants with their actual game TypeTags.
Every catalog entry has a matching game picture. The catalog is available even
when the loaded character has no inventory items.

1. Open your character .sav file.
2. Click Create item, search or filter, select an item, and click Create item.
3. Edit power, rarity, or effects in the main window as needed.
4. Close the game, then export the edited character .sav to your chosen path.
5. Start the game and load that character.

Export writes the edited character .sav to the path you choose. Close the game before overwriting a save it may currently be using.
You can continue editing the same character by opening the exported .sav file.

New entries are constructed independently using the observed save schema.
They begin unequipped, at the character's power level, with no rolled effects.
They do not borrow enchantments, progression, or merchant flags from owned gear.
Unique catalog entries use the unique item's TypeTag and Unique rarity together.
Changing an existing base item's rarity alone does not change its TypeTag.
Names are derived from game identifiers; Unique entries are labeled (Unique).

FILTERS AND ARMOR LABELS
Armor uses H (helmet), C (chestplate), L (leggings), B (boots).
Create item's Filters button opens the side panel. Choose Artifact, Bow, Melee,
Armor, or an armor slot. One type is active at a time. Click the active type
again to return to all items, clearing search too. Close the panel to restore
its large item preview. The main inventory also has a Filters popup.

EFFECTS
The complete concrete item-effect templates from the installed game are included:
106 enchantment variants, 262 gear effect variants, and 57 talisman variants.
These 425 choices include their tier variants. All choices have game pictures.
Enemy/world soul-enchantment modifiers are not equipment effects.
Use Add enchantment / effect, search by name, and select a tier. Filter by
enchantments, gear, armor, talisman, or learned save effects. 70 gear templates
are explicitly marked for armor. Learn effects from save adds observed choices.
Selecting another tier of the same effect replaces it within its effect group.
Other effects in the group remain. New items have no randomly rolled effects.
Intensity, Quality, and EnchantmentPointsInvested can be edited. Catalog choices
start with zero points invested and do not spend character points. Six variable
enchantment templates default to maximum table intensity, which can be edited.
Talisman effects may not work on equipment. Slot hints are shown where defined;
cross-item compatibility and in-game acceptance still need verification.

SAVES AND TESTING
Supports the observed JSON FCharacterSaveV1, SoftVersion 5 format.
Unknown fields and untouched numeric tokens are preserved exactly.
Unchanged export is byte-identical. Export writes directly to the chosen path without creating a .bak file.
Checks passed for all 272 equipment entries and 425 effect choices, export/reload,
preservation of unrelated data, pictures, filters, and effect-tier replacement.
Applying to temporary test saves adds items, keeps exact backups, and rejects
mismatched characters. These are file tests, not an in-game test.

The reported missing-item issue has not yet been reproduced inside the game.
The earlier export contains the five added items. This build adds the missing
installation workflow so edits can be applied directly to the chosen game save.
Game acceptance of the generated items and enchantments still needs verification.

The game save is only replaced when you choose its path in Export. No character saves or extraction tools are included in this package.

SOURCE
Editor.cs: main UI and editing.
EffectCatalog.cs / EffectCatalog.json: game effect templates and their values.
EffectPicker.cs: searchable enchantment/effect picker with category filters.
GameSaveInstaller.cs: applying changes with character checks and backups.
ItemPicker.cs: pictured picker, filter panel, armor-slot labels.
EquipmentCatalog.cs / EquipmentCatalog.json: independent equipment definitions
and new inventory-entry construction, with source-asset provenance per item.
SaveFormat.cs: lossless JSON representation and save adapter.
Tests.cs: round-trip, preservation, full-catalog creation, and UI checks.
Build.ps1: rebuild using Windows .NET Framework C# compiler.
Icons/: PNG resources used when rebuilding; already embedded in the EXE.

EXPERIMENTAL UI BUILD
DungeonsIISaveEditor-ExperimentalUI.exe is a separate build; the existing
editor executable is unchanged. Settings offer eight color themes, text and
window sizing, four included Dungeons II loading paintings, a darkness control
for the painting layer, and an optional custom picture. The artwork is behind
the editor; the interactive panels and fields stay opaque.
The app creates a "UI Config" folder beside the executable and stores its
appearance choices in DungeonsIISaveEditor.UI.txt there.
