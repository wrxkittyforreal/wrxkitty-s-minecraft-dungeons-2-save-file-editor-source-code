﻿using System;
using System.Drawing;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Windows.Forms;

public sealed class EffectPicker : Form {
 readonly Color surface=Color.FromArgb(29,37,48),muted=Color.FromArgb(167,185,204);
 TextBox search=new TextBox();ComboBox group=new ComboBox();InventoryListBox list=new InventoryListBox();Label info=new Label(),count=new Label();Button add=new Button();
 public EffectDefinition SelectedDefinition {get{return list.SelectedItem as EffectDefinition;}}
 readonly List<EffectChoice> observed;
 public J SelectedBatch {get{var row=SelectedDefinition;if(row!=null)return row.CreateBatch();var saved=list.SelectedItem as EffectChoice;if(saved==null)return null;var batch=saved.Batch.Copy();batch["EffectsInThisBatch"]=J.Parse("[]");batch["EffectsInThisBatch"].Add(saved.Effect.Copy());return batch;}}
 public int VisibleCount {get{return list.Items.Count;}}
 public EffectPicker(IEnumerable<EffectChoice> saved=null){observed=saved==null?new List<EffectChoice>():saved.ToList();Text="Add enchantment or effect";ClientSize=new Size(980,610);Opacity=.90;BackColor=Color.FromArgb(18,23,30);ForeColor=Color.White;Font=new Font("Segoe UI",10);StartPosition=FormStartPosition.CenterParent;FormBorderStyle=FormBorderStyle.FixedDialog;MaximizeBox=false;MinimizeBox=false;
  Controls.Add(new Label(){Text="ENCHANTMENTS & EFFECTS",ForeColor=Color.FromArgb(111,230,190),Location=new Point(24,20),Size=new Size(800,30),Font=new Font(Font.FontFamily,16)});
  search.SetBounds(24,65,500,30);search.BackColor=surface;search.ForeColor=Color.White;Controls.Add(search);
  group.SetBounds(540,65,415,30);group.DropDownStyle=ComboBoxStyle.DropDownList;group.BackColor=surface;group.ForeColor=Color.White;group.DrawMode=DrawMode.OwnerDrawFixed;group.DrawItem+=(sender,e)=>{using(var brush=new SolidBrush(surface))e.Graphics.FillRectangle(brush,e.Bounds);if(e.Index>=0)TextRenderer.DrawText(e.Graphics,group.Items[e.Index].ToString(),Font,e.Bounds,Color.White,TextFormatFlags.Left|TextFormatFlags.VerticalCenter);e.DrawFocusRectangle();};group.Items.AddRange(new object[]{"All","Enchantments","Gear effects","Talisman effects","Armor effects","Learned from saves"});Controls.Add(group);
  list.SetBounds(24,112,500,421);list.BackColor=surface;list.ForeColor=Color.White;list.BorderStyle=BorderStyle.None;list.DrawMode=DrawMode.OwnerDrawFixed;list.ItemHeight=49;list.IntegralHeight=false;list.DrawItem+=(s,e)=>EffectArt.DrawRow(list,e);Controls.Add(list);
  info.SetBounds(545,122,407,410);info.ForeColor=muted;Controls.Add(info);
  count.SetBounds(24,550,500,42);count.ForeColor=muted;Controls.Add(count);
  add.Text="Add selected";add.SetBounds(760,552,195,36);add.BackColor=surface;add.FlatStyle=FlatStyle.Flat;HoverGrow.Attach(add);Controls.Add(add);add.Click+=(s,e)=>{if(list.SelectedItem!=null)DialogResult=DialogResult.OK;};list.DoubleClick+=(s,e)=>{if(list.SelectedItem!=null)DialogResult=DialogResult.OK;};
  search.TextChanged+=(s,e)=>RefreshList();group.SelectedIndexChanged+=(s,e)=>RefreshList();list.SelectedIndexChanged+=(s,e)=>ShowSelected();group.SelectedIndex=0;
 }
 public void Filter(string category,string query){group.SelectedItem=category;search.Text=query;RefreshList();}
 void RefreshList(){list.BeginUpdate();list.Items.Clear();string category=group.SelectedItem as string??"All",query=search.Text.Trim();if(category=="Learned from saves"){foreach(var row in observed)if(row.Label.IndexOf(query,StringComparison.OrdinalIgnoreCase)>=0)list.Items.Add(row);}else foreach(var row in EffectCatalog.All){if(category=="Armor effects"?row.Group!="Gear effects"||row.AppliesTo.IndexOf("Armor",StringComparison.OrdinalIgnoreCase)<0:category!="All"&&row.Group!=category)continue;if((row.Name+" "+row.Template+" "+row.AppliesTo).IndexOf(query,StringComparison.OrdinalIgnoreCase)<0)continue;list.Items.Add(row);}list.EndUpdate();if(list.Items.Count>0)list.SelectedIndex=0;else ShowSelected();count.Text=list.Items.Count+" choices · includes tier variants";}
 void ShowSelected(){var row=SelectedDefinition;add.Enabled=list.SelectedItem!=null;if(list.SelectedItem is EffectChoice){var saved=(EffectChoice)list.SelectedItem;var savedDefinition=EffectCatalog.Find(saved.Effect["GeneratorData"]["GeneratorParentTemplate"].Text,saved.Batch["TypeTag"].Text);info.Text="Learned from a save\n\n"+saved.Label+"\n\nApplies to: "+(savedDefinition==null?"Unknown":savedDefinition.ApplicabilityLabel)+"\n\nCopies the saved values exactly. Compatibility with other item types is unverified.";return;}if(row==null){info.Text="No matching effects. Try another search or category.";return;}info.Text=row.Name+" · "+row.Tier+"\n"+row.Group+"\nApplies to: "+row.ApplicabilityLabel+"\n\n"+row.Description+"\n\nIntensity: "+row.Intensity+(row.Fixed?" (game default)":" (maximum game roll; editable)")+"\n\n"+(row.Group=="Talisman effects"?"Talisman effects may not work on equipment.\n":"")+"Game definitions loaded. In-game behavior is not yet verified.";}
}
