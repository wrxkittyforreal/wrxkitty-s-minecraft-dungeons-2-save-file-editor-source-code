﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;

public static class GameSaveInstaller {
 public static string DefaultFolder {get{return Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"Dungeons2","Saved","SaveGames");}}
 public static bool IsGameRunning(){foreach(var process in Process.GetProcesses()){using(process){try{if(process.ProcessName.Equals("Dungeons-Win64-Shipping",StringComparison.OrdinalIgnoreCase)||process.ProcessName.Equals("Dungeons",StringComparison.OrdinalIgnoreCase))return true;}catch(InvalidOperationException){}}}return false;}
 public static string CharacterId(SaveDocument document){return document.Root["CharacterSaveV1"]["MetaData"]["CharacterId"].Text;}
 public static string DefaultTarget(SaveDocument document){return Path.Combine(DefaultFolder,"Character"+CharacterId(document)+".sav");}
 public static void Apply(SaveDocument document,string target){
  if(IsGameRunning())throw new IOException("Close Dungeons II before applying changes. A running game can overwrite the edited save.");
  target=Path.GetFullPath(target);if(!File.Exists(target)||!string.Equals(Path.GetExtension(target),".sav",StringComparison.OrdinalIgnoreCase))throw new IOException("Select the existing character .sav in the game's SaveGames folder.");
  byte[] before=File.ReadAllBytes(target);var existing=SaveDocument.Load(target);if(CharacterId(existing)!=CharacterId(document))throw new IOException("This is a different character. Select the matching character save.");
  string temp=target+"."+Guid.NewGuid().ToString("N")+".tmp";
  try{byte[] bytes=document.Bytes();File.WriteAllBytes(temp,bytes);var verified=SaveDocument.Load(temp);if(verified.Entries.Values.Count!=document.Entries.Values.Count)throw new IOException("Inventory verification failed.");if(IsGameRunning()||!File.ReadAllBytes(target).SequenceEqual(before))throw new IOException("The game or save changed during this operation. Close the game and try again.");File.Replace(temp,target,null);SaveVerification.VerifyBytes(target,bytes);}finally{if(File.Exists(temp))File.Delete(temp);}
 }
}
